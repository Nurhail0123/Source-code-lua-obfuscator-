# IronBrew 2 JS

IronBrew 2 JS compiles Lua 5.1 source to a virtual-machine wrapper. The
existing CLI remains available, and `server.js` adds a small upload-and-download
web layer on top of it.

## Run locally

The compiler must be available as `luac` (Lua 5.1):

```sh
node run.js input.lua output.lua
npm start
```

The web UI is served at `http://localhost:3000`. The Docker image installs the
Lua 5.1 compiler and is the recommended deployment path:

```sh
docker build -t ironbrew2 .
docker run --rm -p 3000:3000 ironbrew2
```

## Presets

- **weak**: low overhead, bytecode wrapper, per-build encoding, compression,
  constant-pool shuffle, and integrity check.
- **medium**: balanced control-flow transforms, opcode mutations, super
  operators, and the same binary payload pipeline.
- **strong** (default): medium features with string encryption, higher transform
  budgets, and important-string encryption.

### CFG control-flow flattening

The medium and strong presets enable the first CFG-based CFF pass. It runs
after bytecode deserialization and before VM generation:

```text
Lua 5.1 bytecode → basic-block CFG → state transitions → conditional dispatcher
```

The pass preserves the existing register-based bytecode and fails closed for
constructs that are not yet covered safely (closures, generic iterators, and
compiler skip-boolean forms). Those chunks continue through the legacy
control-flow pass rather than receiving a potentially invalid rewrite.

Useful CLI controls:

```sh
node run.js input.lua output.lua --cff-level 1 --cff-min-blocks 4
node run.js input.lua output.lua --cff-level 0
```

The implementation now also supports encoded transitions, per-function
decode keys, hierarchical/hybrid dispatch, optional state aliases, safe
unreachable decoy entries, statement-level block splitting, numeric loop
back-edges, and fail-closed generated-reference validation. A table-of-closure
dispatcher remains disabled because moving register-based Lua 5.1 blocks into
closures would change lexical/upvalue and multiple-return semantics.

The payload pipeline is intentionally layered:

```text
serialized binary bytecode → LZSS compression → Base91 encoding
```

Base91 is only an encoding layer, not encryption. The serializer also applies
per-build byte whitening and an instruction-indexed opcode mask; the runtime
reverses these before parsing the existing IR format.

## API

`POST /api/obfuscate` accepts JSON:

```json
{"source":"print('hello')","preset":"medium","preserveLines":false,"minify":true}
```

The service does not persist submitted source. Requests are limited to 512 KB
and the compiler process is time-bounded. Put authentication/rate limiting in
front of the service before exposing it to an untrusted public audience.