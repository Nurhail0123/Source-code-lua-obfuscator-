'use strict';

const assert = require('assert');
const Chunk = require('../ir/Chunk');
const Constant = require('../ir/Constant');
const Instruction = require('../ir/Instruction');
const Opcode = require('../ir/Opcode');
const Generator = require('../obfuscator/vmgen/Generator');
const ObfuscationContext = require('../obfuscator/ObfuscationContext');
const ObfuscationSettings = require('../obfuscator/ObfuscationSettings');
const Deserializer = require('../bytecode/Deserializer');
const VanillaSerializer = require('../bytecode/VanillaSerializer');
const {
  base85Encode,
  base91Encode,
  lzssCompress,
  payloadHash,
  BASE85_ALPHABET,
  BASE91_ALPHABET,
} = require('../obfuscator/vmgen/codec');
const { buildCFG, validateCFG } = require('../obfuscator/cflow/CFG');
const AdvancedCFF = require('../obfuscator/cflow/AdvancedCFF');

function base85Decode(text) {
  const output = [];
  for (let i = 0; i < text.length; i += 5) {
    let value = 0;
    for (let j = 0; j < 5; j++)
      value = value * 85 + BASE85_ALPHABET.indexOf(text[i + j]);
    output.push((value >>> 24) & 255, (value >>> 16) & 255, (value >>> 8) & 255, value & 255);
  }
  return Buffer.from(output);
}

function lzssDecompress(data) {
  const expected = data.readUInt32LE(0);
  let position = 4;
  const out = [];
  while (out.length < expected) {
    const flags = data[position++];
    for (let bit = 0; bit < 8 && out.length < expected; bit++) {
      if (flags & (1 << bit)) {
        out.push(data[position++]);
      } else {
        const lo = data[position++];
        const hi = data[position++];
        const distance = lo + ((hi >> 4) << 8) + 1;
        const count = (hi & 15) + 3;
        for (let i = 0; i < count && out.length < expected; i++)
          out.push(out[out.length - distance]);
      }
    }
  }
  return Buffer.from(out);
}

function base91Decode(text) {
  const lookup = new Map([...BASE91_ALPHABET].map((char, index) => [char, index]));
  const output = [];
  let counter = 0;
  let numBits = 0;
  let entry = -1;

  for (const char of text) {
    const value = lookup.get(char);
    if (value === undefined) continue;
    if (entry < 0) {
      entry = value;
    } else {
      entry += value * 91;
      counter += entry * (2 ** numBits);
      numBits += entry % 8192 > 88 ? 13 : 14;
      while (numBits > 7) {
        output.push(counter % 256);
        counter = Math.floor(counter / 256);
        numBits -= 8;
      }
      entry = -1;
    }
  }

  if (entry >= 0)
    output.push((counter + entry * (2 ** numBits)) % 256);
  return Buffer.from(output);
}

function testCodec() {
  const source = Buffer.from(Array.from({ length: 8192 }, (_, i) => (i * 17) % 29));
  const compressed = lzssCompress(source);
  const encoded = base85Encode(compressed);
  assert.strictEqual(encoded.length % 5, 0);
  assert.deepStrictEqual(lzssDecompress(base85Decode(encoded)), source);
  assert.strictEqual(payloadHash(source), payloadHash(Buffer.from(source)));
  assert.strictEqual(BASE85_ALPHABET.length, 85);
  const base91 = base91Encode(source);
  assert.deepStrictEqual(base91Decode(base91), source);
  assert.strictEqual(BASE91_ALPHABET.length, 91);
  assert(!/['"\\\r\n]/.test(BASE85_ALPHABET));
  assert(!base91.includes("'"));
}

function testGeneratorPayload() {
  const settings = new ObfuscationSettings({ preset: 'weak' });
  const chunk = new Chunk();
  const string = new Constant();
  string.type = 3;
  string.data = 'hello';
  const load = new Instruction(chunk, Opcode.LoadConst, string);
  const ret = new Instruction(chunk, Opcode.Return);
  ret.A = 0;
  ret.B = 1;
  ret.C = 0;
  chunk.constants.push(string);
  chunk.instructions.push(load, ret);
  chunk.updateMappings();

  const context = new ObfuscationContext(chunk, settings);
  const output = new Generator(context).generateVM(settings);
  assert(output.startsWith('return setmetatable'));
  assert(output.includes('Base91Decode'));
  assert(output.includes('LZSSDecompress'));
  assert(output.includes("error('x4')"));
  assert(!output.includes('IRONBREW'));
  assert(!output.includes('math.floor'));
  assert(!output.includes('OPCODE_SALT'));
  assert(!output.includes('BYTE_KEY_1'));
}

function testCfgAndFlattening() {
  const chunk = new Chunk();
  chunk.stackSize = 2;

  const condition = new Instruction(chunk, Opcode.Test);
  condition.A = 0;
  condition.C = 0;
  const branch = new Instruction(chunk, Opcode.Jmp);
  const trueBlock = new Instruction(chunk, Opcode.LoadNil);
  trueBlock.A = 0;
  const join = new Instruction(chunk, Opcode.LoadNil);
  join.A = 1;
  const ret = new Instruction(chunk, Opcode.Return);
  ret.A = 0;
  ret.B = 1;

  chunk.instructions.push(condition, branch, trueBlock, join, ret);
  branch.refOperands[0] = trueBlock;
  chunk.updateMappings();

  const cfg = buildCFG(chunk);
  assert(cfg.supported);
  assert.strictEqual(validateCFG(cfg).valid, true);
  assert(cfg.blocks.length >= 2);

  const result = AdvancedCFF.transformChunk(chunk, {
    cffEnabled: true,
    cffLevel: 1,
    cffMinimumBlocks: 2,
    cffDispatcher: 'conditional',
  });
  assert.strictEqual(result.transformed, true);
  assert(chunk.instructions.some((instruction) => instruction.opCode === Opcode.Eq));
  assert(chunk.stackSize >= 3);
  assert(chunk.instructions.length > 5);

  // The rewritten IR must survive the same serializer/deserializer boundary
  // used by the production VM payload pipeline.
  const roundTripped = new Deserializer(new VanillaSerializer(chunk).serialize()).decodeFile();
  assert.strictEqual(roundTripped.instructions.length, chunk.instructions.length);
  assert(roundTripped.instructions.some((instruction) => instruction.opCode === Opcode.Eq));
}

function testAggressiveDispatch() {
  const chunk = new Chunk();
  chunk.stackSize = 2;
  const condition = new Instruction(chunk, Opcode.Test);
  condition.A = 0;
  condition.C = 0;
  const branch = new Instruction(chunk, Opcode.Jmp);
  const trueBlock = new Instruction(chunk, Opcode.LoadNil);
  trueBlock.A = 0;
  const join = new Instruction(chunk, Opcode.LoadNil);
  join.A = 1;
  const ret = new Instruction(chunk, Opcode.Return);
  ret.A = 0;
  ret.B = 1;
  chunk.instructions.push(condition, branch, trueBlock, join, ret);
  branch.refOperands[0] = trueBlock;
  chunk.updateMappings();

  const result = AdvancedCFF.transformChunk(chunk, {
    cffEnabled: true,
    cffLevel: 3,
    cffMinimumBlocks: 2,
    cffMaximumBlocks: 32,
    cffDispatcher: 'hybrid',
    cffStateEncoding: true,
    cffStateAliases: true,
    cffDecoyStates: true,
    cffBlockSplitting: true,
    cffGroupSize: 2,
  });
  assert.strictEqual(result.transformed, true);
  assert.strictEqual(result.encoded, true);
  assert(result.aliases >= 2);
  assert(result.decoys >= 1);
  const serialized = new VanillaSerializer(chunk).serialize();
  const roundTripped = new Deserializer(serialized).decodeFile();
  assert.strictEqual(roundTripped.instructions.length, chunk.instructions.length);
}

testCodec();
testGeneratorPayload();
testCfgAndFlattening();
testAggressiveDispatch();
assert.strictEqual(new ObfuscationSettings({ preset: 'strong' }).encryptStrings, true);
assert.strictEqual(new ObfuscationSettings({ preset: 'weak' }).controlFlow, false);
assert.strictEqual(new ObfuscationSettings().preset, 'strong');
console.log('core tests passed');