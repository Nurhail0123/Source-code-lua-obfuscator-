const source = document.querySelector('#source');
const file = document.querySelector('#file');
const size = document.querySelector('#size');
const fileName = document.querySelector('#file-name');
const result = document.querySelector('#result');
const output = document.querySelector('#output');
const stats = document.querySelector('#stats');
const errorBox = document.querySelector('#error');
const button = document.querySelector('#obfuscate');
let outputName = 'obfuscated.lua';

function formatBytes(n) {
  return n < 1024 ? `${n} B` : `${(n / 1024).toFixed(1)} KB`;
}
function updateSize() {
  size.textContent = `${formatBytes(new Blob([source.value]).size)} / 512 KB`;
}
source.addEventListener('input', updateSize);
file.addEventListener('change', async () => {
  const picked = file.files[0];
  if (!picked) return;
  source.value = await picked.text();
  fileName.textContent = picked.name;
  updateSize();
});

button.addEventListener('click', async () => {
  errorBox.classList.add('hidden');
  result.classList.add('hidden');
  button.disabled = true;
  button.firstChild.textContent = 'WORKING ';
  try {
    const response = await fetch('/api/obfuscate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: source.value,
        preset: document.querySelector('#preset').value,
        preserveLines: document.querySelector('#lines').checked,
        minify: document.querySelector('#minify').checked,
      }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Request failed.');
    output.textContent = data.code;
    outputName = data.filename;
    stats.textContent = `${data.preset.toUpperCase()} · ${formatBytes(data.inputBytes)} → ${formatBytes(data.outputBytes)} · ${data.elapsedMs} ms`;
    result.classList.remove('hidden');
  } catch (err) {
    errorBox.textContent = err.message;
    errorBox.classList.remove('hidden');
  } finally {
    button.disabled = false;
    button.firstChild.textContent = 'OBFUSCATE ';
  }
});

document.querySelector('#download').addEventListener('click', () => {
  const blob = new Blob([output.textContent], { type: 'text/plain;charset=latin1' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = outputName;
  link.click();
  URL.revokeObjectURL(link.href);
});
updateSize();