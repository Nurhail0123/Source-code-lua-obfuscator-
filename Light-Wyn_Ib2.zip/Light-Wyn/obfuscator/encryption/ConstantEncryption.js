'use strict';

class Decryptor {
  constructor(name, maxLen) {
    this.name = name;
    this.table = [];
    for (let i = 0; i < Math.max(1, maxLen); i++)
      this.table.push(Math.floor(Math.random() * 256));
  }

  encrypt(bytes) {
    const encrypted = [];
    const length = this.table.length;
    for (let i = 0; i < bytes.length; i++)
      encrypted.push((bytes[i] + this.table[i % length]) & 0xff);

    const tableStr = this.table.map((value) => '\\' + value).join('');
    const encryptedStr = encrypted.map((value) => '\\' + value).join('');
    return `((function(b)local c="";local e=string.byte;local h=string.char;local f="${tableStr}";for g=1,#b do local x=(g-1)%${length}+1;c=c..h((e(b,g)-e(f,x))%256);end;return c;end)("${encryptedStr}"))`;
  }
}

class ConstantEncryption {
  constructor(settings, source) {
    this._settings = settings;
    this._src = source;
  }

  static unescapeLuaString(str) {
    const bytes = [];
    let i = 0;
    while (i < str.length) {
      const current = str.charCodeAt(i++);
      if (current !== 92) {
        bytes.push(current & 0xff);
        continue;
      }
      if (i >= str.length) break;
      const next = str.charCodeAt(i++);
      switch (next) {
        case 97: bytes.push(7); break;
        case 98: bytes.push(8); break;
        case 102: bytes.push(12); break;
        case 110: bytes.push(10); break;
        case 114: bytes.push(13); break;
        case 116: bytes.push(9); break;
        case 118: bytes.push(11); break;
        case 10: break;
        case 13:
          if (str.charCodeAt(i) === 10) i++;
          break;
        default:
          if (next >= 48 && next <= 57) {
            let digits = String.fromCharCode(next);
            for (let j = 0; j < 2 && i < str.length; j++) {
              const code = str.charCodeAt(i);
              if (code < 48 || code > 57) break;
              digits += String.fromCharCode(code);
              i++;
            }
            bytes.push(parseInt(digits, 10) & 0xff);
          } else {
            bytes.push(next & 0xff);
          }
      }
    }
    return bytes;
  }

  static _longBracketEnd(source, start) {
    const match = source.slice(start).match(/^\[(=*)\[/);
    if (!match) return null;
    const close = ']' + match[1] + ']';
    const end = source.indexOf(close, start + match[0].length);
    return { openLength: match[0].length, closeLength: close.length, end: end < 0 ? source.length : end };
  }

  static scanLiterals(source) {
    const matches = [];
    let i = 0;
    while (i < source.length) {
      const ch = source[i];
      if (ch === '-' && source[i + 1] === '-') {
        const block = ConstantEncryption._longBracketEnd(source, i + 2);
        if (block) {
          i = block.end + block.closeLength;
        } else {
          i += 2;
          while (i < source.length && source[i] !== '\n') i++;
        }
        continue;
      }
      if (ch === '[') {
        const block = ConstantEncryption._longBracketEnd(source, i);
        if (block) {
          matches.push({
            start: i,
            end: block.end + block.closeLength,
            contentStart: i + block.openLength,
            contentEnd: block.end < 0 ? source.length : block.end,
            quoted: false,
          });
          i = block.end + block.closeLength;
          continue;
        }
      }
      if (ch !== '"' && ch !== "'") {
        i++;
        continue;
      }
      const quote = ch;
      const start = i++;
      const contentStart = i;
      while (i < source.length) {
        if (source[i] === '\\') {
          i += 2;
        } else if (source[i] === quote) {
          matches.push({ start, end: i + 1, contentStart, contentEnd: i, quoted: true });
          i++;
          break;
        } else {
          i++;
        }
      }
    }
    return matches;
  }

  _bytesFor(match, source) {
    const content = source.slice(match.contentStart, match.contentEnd);
    if (content.startsWith('[STR_ENCRYPT]'))
      return Buffer.from(content.slice(13), 'latin1');
    return Buffer.from(match.quoted ? ConstantEncryption.unescapeLuaString(content) : content, 'latin1');
  }

  _replace(matches, source, name, predicate) {
    const selected = matches.filter((match) => {
      const content = source.slice(match.contentStart, match.contentEnd);
      return predicate(content, match);
    });
    if (selected.length === 0) return source;
    const maxLength = Math.min(
      this._settings.decryptTableLen || 500,
      Math.max(1, ...selected.map((match) => this._bytesFor(match, source).length)),
    );
    const decryptor = new Decryptor(name, maxLength);
    let result = source;
    // Reverse replacement preserves the offsets from the single lexical scan.
    for (let i = selected.length - 1; i >= 0; i--) {
      const match = selected[i];
      const replacement = decryptor.encrypt(this._bytesFor(match, source));
      result = result.slice(0, match.start) + replacement + result.slice(match.end);
    }
    return result;
  }

  encryptStrings() {
    const original = this._src;
    const matches = ConstantEncryption.scanLiterals(original);
    const isInternal = (content) => content.startsWith('IB_');

    if (this._settings.encryptStrings) {
      this._src = this._replace(
        matches,
        this._src,
        'IRONBREW_STR_DEC_GENERIC',
        (content) => !isInternal(content),
      );
    } else {
      this._src = this._replace(
        matches,
        this._src,
        'IRONBREW_STR_ENCRYPT',
        (content) => content.startsWith('[STR_ENCRYPT]'),
      );
    }

    // Important strings are selected from the original source, not from
    // generated decryptor code, so encryption never recursively reprocesses
    // its own implementation.
    if (this._settings.encryptImportantStrings && !this._settings.encryptStrings) {
      this._src = this._replace(
        matches,
        this._src,
        'IRONBREW_STR_ENCRYPT_IMPORTANT',
        (content) => !isInternal(content) && ['http', 'function', 'metatable', 'local'].some(
          (term) => content.toLowerCase().includes(term),
        ),
      );
    }
    return this._src;
  }
}

module.exports = ConstantEncryption;