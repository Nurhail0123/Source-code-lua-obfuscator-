const Opcode = require('../../ir/Opcode');
const Constant = require('../../ir/Constant');
const Instruction = require('../../ir/Instruction');
const TestFlip = require('./TestFlip');
const TestSpam = require('./TestSpam');
const Bounce = require('./Bounce');
const Inlining = require('./Inlining');
const AdvancedCFF = require('./AdvancedCFF');

class CFContext {
  constructor(lChunk, settings) {
    this.lChunk = lChunk;
    this.settings = settings || {};
    this.transformedChunks = 0;
    this.skippedChunks = [];
  }

  doChunk(c) {
    let chunkHasCflow = false;
    let CBegin = null;
    const Instructs = [...c.instructions];

    for (let index = 0; index < Instructs.length - 1; index++) {
      const instr = Instructs[index];
      if (instr.opCode === Opcode.GetGlobal && Instructs[index + 1].opCode === Opcode.Call) {
        const str = instr.refOperands[0] ? instr.refOperands[0].data.toString() : '';
        let do_ = false;

        switch (str) {
          case 'IB_MAX_CFLOW_START':
            CBegin = instr;
            do_ = true;
            chunkHasCflow = true;
            break;
          case 'IB_MAX_CFLOW_END':
            do_ = true;
            if (CBegin) {
              let cBegin = c.instructionMap.get(CBegin);
              let cEnd = c.instructionMap.get(instr);
              let nIns = c.instructions.slice(cBegin, cEnd);

              TestSpam.doInstructions(c, nIns);
              cBegin = c.instructionMap.get(CBegin);
              cEnd = c.instructionMap.get(instr);
              nIns = c.instructions.slice(cBegin, cEnd);

              Bounce.doInstructions(c, nIns);
            }
            break;
        }

        if (do_) {
          instr.opCode = Opcode.Move;
          instr.A = 0;
          instr.B = 0;
          const call = Instructs[index + 1];
          call.opCode = Opcode.Move;
          call.A = 0;
          call.B = 0;
        }
      }
    }

    const result = AdvancedCFF.transformChunk(c, this.settings);
    if (result.transformed) {
      this.transformedChunks++;
    } else {
      this.skippedChunks.push({ chunk: c.name || '<anonymous>', reason: result.reason });
      // Keep the original lightweight pass as a fallback for bytecode chunks
      // that the correctness-first CFG pass intentionally declines.
      TestFlip.doInstructions(c, [...c.instructions]);
    }

    if (chunkHasCflow && !result.transformed)
      c.instructions.unshift(new Instruction(c, Opcode.NewStack));

    for (const _c of c.functions)
      this.doChunk(_c);
  }

  doChunks() {
    new Inlining(this.lChunk).doChunks();
    this.doChunk(this.lChunk);
    const rounds = Math.max(1, Math.min(3, this.settings.controlFlowRounds || 1));
    for (let round = 1; round < rounds; round++)
      this.flipChunks(this.lChunk);
  }

  flipChunks(c) {
    if (!c.__advancedCFF)
      TestFlip.doInstructions(c, [...c.instructions]);
    for (const child of c.functions)
      this.flipChunks(child);
  }
}

module.exports = CFContext;
