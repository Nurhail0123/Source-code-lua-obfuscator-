module.exports = {
  CFContext: require('./CFContext'),
  CFGenerator: require('./CFGenerator'),
  TestFlip: require('./TestFlip'),
  TestSpam: require('./TestSpam'),
  Bounce: require('./Bounce'),
  TestPreserve: require('./TestPreserve'),
  Inlining: require('./Inlining'),
  AdvancedCFF: require('./AdvancedCFF'),
  CFG: require('./CFG')
};
