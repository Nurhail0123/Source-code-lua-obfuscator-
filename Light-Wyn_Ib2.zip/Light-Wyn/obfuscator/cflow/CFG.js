'use strict';

const Opcode = require('../../ir/Opcode');

class BasicBlock {
  constructor(id, start, end, instructions) {
    this.id = id;
    this.start = start;
    this.end = end;
    this.instructions = instructions;
    this.predecessors = new Set();
    this.successors = [];
    this.terminator = null;
    this.entryInstruction = null;
    this.stateValue = null;
  }
}

function isConditional(opCode) {
  return opCode === Opcode.Eq ||
    opCode === Opcode.Lt ||
    opCode === Opcode.Le ||
    opCode === Opcode.Test ||
    opCode === Opcode.TestSet ||
    opCode === Opcode.TForLoop;
}

function isTerminal(opCode) {
  return opCode === Opcode.Return || opCode === Opcode.TailCall;
}

function targetIndex(chunk, instruction) {
  if (!instruction) return null;
  if (instruction.refOperands && instruction.refOperands[0]) {
    const target = chunk.instructionMap.get(instruction.refOperands[0]);
    if (target !== undefined) return target;
  }
  if (instruction.opCode === Opcode.Jmp ||
      instruction.opCode === Opcode.ForLoop ||
      instruction.opCode === Opcode.ForPrep) {
    const index = chunk.instructionMap.get(instruction);
    if (index !== undefined && Number.isInteger(instruction.B))
      return index + instruction.B + 1;
  }
  return null;
}

function addStart(starts, value, length) {
  if (Number.isInteger(value) && value >= 0 && value < length)
    starts.add(value);
}

/**
 * Build a bytecode-level CFG. The IR already contains resolved instruction
 * references, so this pass deliberately works below the source-language AST.
 * That keeps register allocation, upvalues, and multiple-return instructions
 * intact while allowing safe block-level rewriting.
 */
function buildCFG(chunk, options) {
  options = options || {};
  chunk.updateMappings();
  const instructions = chunk.instructions;
  const length = instructions.length;
  if (!length) throw new Error('Cannot build a CFG for an empty chunk.');

  const starts = new Set([0]);
  const unsupported = [];

  for (let index = 0; index < length; index++) {
    const instruction = instructions[index];
    const next = instructions[index + 1];

    if (instruction.instructionType === 4) {
      // SetList data words are not executable and must stay with SetList.
      continue;
    }

    if (instruction.opCode === Opcode.Closure) unsupported.push('closure');
    if (instruction.opCode === Opcode.LoadBool && instruction.C !== 0)
      unsupported.push('loadbool-skip');

    if (isTerminal(instruction.opCode))
      addStart(starts, index + 1, length);

    if (instruction.opCode === Opcode.Jmp ||
        instruction.opCode === Opcode.ForLoop ||
        instruction.opCode === Opcode.ForPrep) {
      addStart(starts, targetIndex(chunk, instruction), length);
      addStart(starts, index + 1, length);
      continue;
    }

    if (isConditional(instruction.opCode)) {
      // Lua emits <test>, <jump> for the common if/else shape. The jump is
      // part of the conditional terminator rather than a separate block.
      if (next && next.opCode === Opcode.Jmp) {
        addStart(starts, targetIndex(chunk, next), length);
        addStart(starts, index + 2, length);
      } else {
        addStart(starts, index + 1, length);
        addStart(starts, index + 2, length);
      }
    }

    // Aggressive mode may split at statement boundaries. Never split a
    // SetList/data pair or the test+jump pair that forms one terminator.
    if (options.splitStatements &&
        instruction.instructionType !== 4 &&
        instruction.opCode !== Opcode.SetList &&
        !isConditional(instruction.opCode) &&
        instruction.opCode !== Opcode.Jmp &&
        instruction.opCode !== Opcode.ForLoop &&
        instruction.opCode !== Opcode.ForPrep &&
        !isTerminal(instruction.opCode)) {
      addStart(starts, index + 1, length);
    }
  }

  if (unsupported.length) {
    return {
      supported: false,
      reason: `unsupported bytecode feature: ${[...new Set(unsupported)].join(', ')}`,
      blocks: [],
      blockByStart: new Map(),
    };
  }

  const orderedStarts = [...starts].sort((a, b) => a - b);
  const blocks = [];
  const blockByStart = new Map();
  for (let i = 0; i < orderedStarts.length; i++) {
    const start = orderedStarts[i];
    const end = i + 1 < orderedStarts.length ? orderedStarts[i + 1] : length;
    const block = new BasicBlock(i, start, end, instructions.slice(start, end));
    blocks.push(block);
    blockByStart.set(start, block);
  }

  const blockFor = (index) => blockByStart.get(index) || null;
  for (const block of blocks) {
    const last = instructions[block.end - 1];
    const previous = instructions[block.end - 2];
    let terminator;

    if (last && last.opCode === Opcode.Jmp &&
        previous && isConditional(previous.opCode)) {
      // The condition executes the adjacent jump when its predicate matches;
      // otherwise Lua skips that jump and continues at block.end.
      const trueTarget = targetIndex(chunk, last);
      const falseTarget = block.end;
      terminator = {
        kind: 'conditional',
        instruction: previous,
        trueTarget,
        falseTarget,
        statements: block.instructions.slice(0, -1),
      };
    } else if (last && isConditional(last.opCode)) {
      terminator = {
        kind: 'conditional',
        instruction: last,
        trueTarget: block.end,
        falseTarget: block.end + 1,
        statements: block.instructions,
      };
    } else if (last && last.opCode === Opcode.ForLoop) {
      terminator = {
        kind: 'for-loop',
        instruction: last,
        trueTarget: targetIndex(chunk, last),
        falseTarget: block.end,
        statements: block.instructions,
      };
    } else if (last && last.opCode === Opcode.ForPrep) {
      terminator = {
        kind: 'for-prep',
        instruction: last,
        trueTarget: targetIndex(chunk, last),
        statements: block.instructions,
      };
    } else if (last && isTerminal(last.opCode)) {
      terminator = { kind: 'terminal', instruction: last, statements: block.instructions };
    } else {
      terminator = {
        kind: 'fallthrough',
        trueTarget: block.end,
        statements: block.instructions,
      };
    }

    block.terminator = terminator;
    const successorIndexes = terminator.kind === 'conditional' ||
      terminator.kind === 'for-loop'
      ? [terminator.trueTarget, terminator.falseTarget]
      : terminator.kind === 'for-prep' || terminator.kind === 'fallthrough'
        ? [terminator.trueTarget]
        : terminator.kind === 'terminal'
          ? []
          : [targetIndex(chunk, terminator.instruction)];

    for (const successorIndex of successorIndexes) {
      const successor = blockFor(successorIndex);
      if (!successor) {
        return {
          supported: false,
          reason: `invalid CFG edge from instruction ${block.start} to ${successorIndex}`,
          blocks: [],
          blockByStart,
        };
      }
      block.successors.push(successor);
      successor.predecessors.add(block);
    }
  }

  const reachable = new Set();
  const visit = (block) => {
    if (!block || reachable.has(block)) return;
    reachable.add(block);
    for (const successor of block.successors) visit(successor);
  };
  visit(blocks[0]);

  if (reachable.size !== blocks.length) {
    return {
      supported: false,
      reason: 'unreachable bytecode block',
      blocks,
      blockByStart,
    };
  }

  return { supported: true, blocks, blockByStart, reachable };
}

function validateCFG(cfg) {
  if (!cfg || !cfg.supported || !cfg.blocks.length)
    return { valid: false, reason: 'CFG is not transformable' };

  const blockSet = new Set(cfg.blocks);
  for (const block of cfg.blocks) {
    for (const successor of block.successors) {
      if (!blockSet.has(successor))
        return { valid: false, reason: `missing successor for block ${block.id}` };
      if (!successor.predecessors.has(block))
        return { valid: false, reason: `missing predecessor for block ${successor.id}` };
    }
    if (block.terminator.kind !== 'terminal' && block.successors.length === 0)
      return { valid: false, reason: `non-terminal block ${block.id} has no successor` };
  }

  if (!cfg.reachable || cfg.reachable.size !== cfg.blocks.length)
    return { valid: false, reason: 'CFG reachability validation failed' };

  return { valid: true };
}

module.exports = {
  BasicBlock,
  buildCFG,
  validateCFG,
  isConditional,
};