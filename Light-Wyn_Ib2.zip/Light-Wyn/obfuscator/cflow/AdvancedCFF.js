'use strict';

const Constant = require('../../ir/Constant');
const Instruction = require('../../ir/Instruction');
const Opcode = require('../../ir/Opcode');
const { ConstantType } = require('../../ir/Enums');
const { buildCFG, validateCFG } = require('./CFG');
const { randInt, shuffle } = require('../../utils');

const STATE_MODULUS = 65521;

function addNumberConstant(chunk, value) {
  const existing = chunk.constants.find((constant) =>
    constant.type === ConstantType.Number && constant.data === value);
  if (existing) return existing;

  const constant = new Constant();
  constant.type = ConstantType.Number;
  constant.data = value;
  constant.backReferences = [];
  chunk.constants.push(constant);
  return constant;
}

function gcd(a, b) {
  while (b !== 0) [a, b] = [b, a % b];
  return Math.abs(a);
}

function modularInverse(value, modulus) {
  let a = value;
  let b = modulus;
  let x0 = 1;
  let x1 = 0;
  while (b !== 0) {
    const quotient = Math.floor(a / b);
    [a, b] = [b, a - quotient * b];
    [x0, x1] = [x1, x0 - quotient * x1];
  }
  return ((x0 % modulus) + modulus) % modulus;
}

function uniqueValues(count, min, max) {
  const values = new Set();
  while (values.size < count) values.add(randInt(min, max));
  return [...values];
}

function jumpTo(chunk, target) {
  return new Instruction(chunk, Opcode.Jmp, target);
}

function loadConstant(chunk, register, constant) {
  const instruction = new Instruction(chunk, Opcode.LoadConst, constant);
  instruction.A = register;
  return instruction;
}

function arithmetic(chunk, opcode, targetRegister, leftRegister, rightConstant) {
  const instruction = new Instruction(chunk, opcode);
  instruction.A = targetRegister;
  instruction.B = leftRegister;
  instruction.refOperands[1] = rightConstant;
  return instruction;
}

function compareState(chunk, decodedRegister, logicalConstant, target) {
  const test = new Instruction(chunk, Opcode.Eq);
  test.A = 1;
  test.B = decodedRegister;
  test.refOperands[1] = logicalConstant;
  return [test, jumpTo(chunk, target)];
}

function snapshotChunk(chunk) {
  return {
    instructions: chunk.instructions,
    constants: chunk.constants,
    stackSize: chunk.stackSize,
    advanced: chunk.__advancedCFF,
    refs: new Map(chunk.instructions.map((instruction) => [
      instruction,
      [...instruction.refOperands],
    ])),
  };
}

function restoreChunk(chunk, snapshot) {
  chunk.instructions = snapshot.instructions;
  chunk.constants = snapshot.constants;
  chunk.stackSize = snapshot.stackSize;
  chunk.__advancedCFF = snapshot.advanced;
  for (const [instruction, refs] of snapshot.refs)
    instruction.refOperands = refs;
  chunk.updateMappings();
}

function validateGeneratedInstructions(chunk) {
  const instructionSet = new Set(chunk.instructions);
  for (const instruction of chunk.instructions) {
    for (const operand of instruction.refOperands || []) {
      if (operand instanceof Instruction && !instructionSet.has(operand))
        return { valid: false, reason: 'generated reference points outside chunk' };
    }
    if (instruction.opCode === Opcode.Jmp && !instruction.refOperands[0])
      return { valid: false, reason: 'generated jump has no target' };
  }
  return { valid: true };
}

function chooseEncoding(level, settings) {
  return settings.cffStateEncoding !== false && level >= 1;
}

function makeEncoding(chunk, blockCount, enabled) {
  if (!enabled) return null;
  let key;
  do key = randInt(3, STATE_MODULUS - 1);
  while (gcd(key, STATE_MODULUS) !== 1);

  return {
    modulus: addNumberConstant(chunk, STATE_MODULUS),
    key: addNumberConstant(chunk, key),
    inverse: addNumberConstant(chunk, modularInverse(key, STATE_MODULUS)),
    offset: addNumberConstant(chunk, randInt(97, 20000)),
    logicalIds: uniqueValues(blockCount, 101, STATE_MODULUS - 2),
  };
}

function configureBlocks(chunk, blocks, encoding, stateConstants) {
  if (encoding) {
    blocks.forEach((block, index) => {
      block.logicalId = encoding.logicalIds[index];
      block.logicalConstant = addNumberConstant(chunk, block.logicalId);
    });
  } else {
    const values = uniqueValues(blocks.length, 10000, 0x3fffffff);
    blocks.forEach((block, index) => {
      block.stateValue = values[index];
      block.stateConstant = stateConstants[index] || addNumberConstant(chunk, values[index]);
      block.logicalConstant = block.stateConstant;
    });
  }
}

function assignGroups(chunk, blocks, strategy, groupSize) {
  if (strategy !== 'hierarchical' && strategy !== 'hybrid') return [];
  const size = Math.max(2, Number(groupSize) || 4);
  const groupCount = Math.max(1, Math.ceil(blocks.length / size));
  const groupIds = uniqueValues(groupCount, 17, 60000);
  const groups = groupIds.map((id, index) => ({
    id,
    constant: addNumberConstant(chunk, id),
    blocks: [],
    index,
  }));
  blocks.forEach((block, index) => {
    const group = groups[index % groups.length];
    block.group = group;
    group.blocks.push(block);
  });
  return groups;
}

function decodePrefix(chunk, encoding, stateRegister, decodedRegister) {
  if (!encoding) return [];
  return [
    arithmetic(chunk, Opcode.Sub, decodedRegister, stateRegister, encoding.offset),
    arithmetic(chunk, Opcode.Mul, decodedRegister, decodedRegister, encoding.inverse),
    arithmetic(chunk, Opcode.Mod, decodedRegister, decodedRegister, encoding.modulus),
  ];
}

function makeTransition(chunk, target, context, aliasIndex) {
  const output = [];
  if (context.groups.length)
    output.push(loadConstant(chunk, context.groupRegister, target.group.constant));

  if (context.encoding) {
    output.push(loadConstant(chunk, context.logicalRegister, target.logicalConstant));
    output.push(arithmetic(chunk, Opcode.Mul, context.stateRegister,
      context.logicalRegister, context.encoding.key));
    output.push(arithmetic(chunk, Opcode.Add, context.stateRegister,
      context.stateRegister, context.encoding.offset));
    output.push(arithmetic(chunk, Opcode.Mod, context.stateRegister,
      context.stateRegister, context.encoding.modulus));
    if (aliasIndex > 0) {
      const aliasOffset = addNumberConstant(
        chunk,
        aliasIndex * STATE_MODULUS,
      );
      output.push(arithmetic(chunk, Opcode.Add, context.stateRegister,
        context.stateRegister, aliasOffset));
    }
  } else {
    output.push(loadConstant(chunk, context.stateRegister, target.stateConstant));
  }
  output.push(jumpTo(chunk, context.dispatchStart));
  return output;
}

function makeDispatcher(chunk, entries, context) {
  const output = decodePrefix(
    chunk,
    context.encoding,
    context.stateRegister,
    context.decodedRegister,
  );
  const decodedRegister = context.encoding
    ? context.decodedRegister
    : context.stateRegister;

  if (!context.groups.length) {
    for (const entry of entries)
      output.push(...compareState(chunk, decodedRegister, entry.logicalConstant, entry.entry));
    const fallback = new Instruction(chunk, Opcode.Return);
    fallback.A = 0;
    fallback.B = 1;
    output.push(fallback);
    return output;
  }

  const groupJumps = [];
  for (const group of context.dispatchGroups) {
    const groupTest = new Instruction(chunk, Opcode.Eq);
    groupTest.A = 1;
    groupTest.B = context.groupRegister;
    groupTest.refOperands[1] = group.constant;
    const groupJump = jumpTo(chunk, null);
    groupJumps.push({ group, groupJump });
    output.push(groupTest, groupJump);
  }
  const topFallback = new Instruction(chunk, Opcode.Return);
  topFallback.A = 0;
  topFallback.B = 1;
  output.push(topFallback);

  for (const { group, groupJump } of groupJumps) {
    const groupEntries = entries.filter((entry) => entry.group === group);
    const segment = [];
    for (const entry of groupEntries)
      segment.push(...compareState(chunk, decodedRegister, entry.logicalConstant, entry.entry));
    const groupFallback = new Instruction(chunk, Opcode.Return);
    groupFallback.A = 0;
    groupFallback.B = 1;
    segment.push(groupFallback);
    groupJump.refOperands[0] = segment[0] || topFallback;
    output.push(...segment);
  }
  return output;
}

function transformChunk(chunk, settings) {
  settings = settings || {};
  const level = Number(settings.cffLevel || 0);
  if (!settings.cffEnabled || level <= 0)
    return { transformed: false, reason: 'CFF disabled' };

  const probability = Math.max(0, Math.min(1, Number(settings.cffFlattenProbability ?? 1)));
  if (probability < 1 && Math.random() > probability)
    return { transformed: false, reason: 'flatten probability declined' };

  const dispatcher = String(settings.cffDispatcher || 'conditional').toLowerCase();
  if (!['conditional', 'hierarchical', 'hybrid'].includes(dispatcher))
    return { transformed: false, reason: `dispatcher strategy not implemented safely: ${dispatcher}` };

  const splitStatements = Boolean(settings.cffBlockSplitting) || level >= 3;
  const cfg = buildCFG(chunk, { splitStatements });
  const validation = validateCFG(cfg);
  if (!validation.valid)
    return { transformed: false, reason: validation.reason, cfg };

  const minimumBlocks = Math.max(2, Number(settings.cffMinimumBlocks || 4));
  const maximumBlocks = Math.max(minimumBlocks, Number(settings.cffMaximumBlocks || 128));
  if (cfg.blocks.length < minimumBlocks)
    return { transformed: false, reason: `fewer than ${minimumBlocks} basic blocks`, cfg };
  if (cfg.blocks.length > maximumBlocks)
    return { transformed: false, reason: `more than ${maximumBlocks} basic blocks`, cfg };

  const snapshot = snapshotChunk(chunk);
  const originalInstructions = [...chunk.instructions];
  const fail = (reason) => {
    restoreChunk(chunk, snapshot);
    return { transformed: false, reason, cfg };
  };

  const usesEncoding = chooseEncoding(level, settings);
  const aliasCount = settings.cffStateAliases === false
    ? 1
    : level >= 3 ? 3 : level >= 2 ? 2 : 1;
  const baseRegister = chunk.stackSize;
  const registerCount = usesEncoding
    ? (dispatcher === 'conditional' ? 3 : 4)
    : (dispatcher === 'conditional' ? 1 : 2);
  if (baseRegister + registerCount >= 250)
    return fail('no safe state registers available');
  chunk.stackSize += registerCount;

  const encoding = makeEncoding(chunk, cfg.blocks.length, usesEncoding);
  const directStateConstants = usesEncoding
    ? []
    : uniqueValues(cfg.blocks.length, 10000, 0x3fffffff)
      .map((value) => addNumberConstant(chunk, value));
  configureBlocks(chunk, cfg.blocks, encoding, directStateConstants);

  const groups = assignGroups(
    chunk,
    cfg.blocks,
    dispatcher,
    settings.cffGroupSize,
  );
  const orderedBlocks = [...cfg.blocks];
  if (orderedBlocks.length > 2) shuffle(orderedBlocks);
  const entryBlock = cfg.blocks[0];

  const context = {
    encoding,
    groups,
    dispatchGroups: [...groups],
    stateRegister: baseRegister,
    decodedRegister: baseRegister + 1,
    logicalRegister: baseRegister + 2,
    groupRegister: baseRegister + (usesEncoding ? 3 : 1),
    dispatchStart: null,
    aliasCursor: 0,
  };
  if (groups.length) shuffle(context.dispatchGroups);

  const blockOutput = new Map();
  for (const block of cfg.blocks) {
    const terminator = block.terminator;
    const output = [...terminator.statements];
    const transition = (target) => {
      const alias = context.aliasCursor++ % aliasCount;
      return makeTransition(chunk, target, context, alias);
    };

    if (terminator.kind === 'terminal') {
      // Keep direct return/tail-call instructions to preserve varargs and
      // multiple-return behavior.
    } else if (terminator.kind === 'conditional') {
      const trueBlock = cfg.blockByStart.get(terminator.trueTarget);
      const falseBlock = cfg.blockByStart.get(terminator.falseTarget);
      if (!trueBlock || !falseBlock)
        return fail(`invalid conditional target in block ${block.id}`);
      const trueJump = jumpTo(chunk, null);
      output.push(trueJump);
      const falseTransition = transition(falseBlock);
      const trueTransition = transition(trueBlock);
      output.push(...falseTransition, ...trueTransition);
      trueJump.refOperands[0] = trueTransition[0];
    } else if (terminator.kind === 'for-loop') {
      const trueBlock = cfg.blockByStart.get(terminator.trueTarget);
      const falseBlock = cfg.blockByStart.get(terminator.falseTarget);
      if (!trueBlock || !falseBlock)
        return fail(`invalid for-loop target in block ${block.id}`);
      const falseTransition = transition(falseBlock);
      const trueTransition = transition(trueBlock);
      terminator.instruction.refOperands[0] = trueTransition[0];
      output.push(...falseTransition, ...trueTransition);
    } else if (terminator.kind === 'for-prep') {
      const target = cfg.blockByStart.get(terminator.trueTarget);
      if (!target) return fail(`invalid for-prep target in block ${block.id}`);
      const next = transition(target);
      terminator.instruction.refOperands[0] = next[0];
      output.push(...next);
    } else {
      const target = cfg.blockByStart.get(terminator.trueTarget);
      if (!target) return fail(`invalid fallthrough in block ${block.id}`);
      output.push(...transition(target));
    }

    if (!output[0]) return fail(`empty transformed block ${block.id}`);
    blockOutput.set(block, output);
    block.entryInstruction = output[0];
  }

  const entries = cfg.blocks.map((block) => ({
    block,
    entry: block.entryInstruction,
    logicalConstant: block.logicalConstant,
    group: block.group || null,
  }));

  const decoyEntries = [];
  const decoyCount = settings.cffDecoyStates === false
    ? 0
    : level >= 3 ? Math.min(3, Math.ceil(cfg.blocks.length / 4)) : 0;
  if (decoyCount) {
    const decoyIds = uniqueValues(decoyCount, 30001, STATE_MODULUS - 3);
    for (let i = 0; i < decoyCount; i++) {
      const decoy = {
        logicalConstant: addNumberConstant(chunk, decoyIds[i]),
        group: groups.length ? groups[i % groups.length] : null,
        entry: null,
      };
      const decoyTarget = makeTransition(chunk, entryBlock, context, 0);
      decoy.entry = decoyTarget[0];
      decoyEntries.push({ ...decoy, output: decoyTarget });
    }
  }

  const allEntries = [...entries, ...decoyEntries];
  const dispatcherInstructions = makeDispatcher(chunk, allEntries, context);
  context.dispatchStart = dispatcherInstructions[0];

  const initialTransition = makeTransition(chunk, entryBlock, context, 0);
  const finalInstructions = [...initialTransition, ...dispatcherInstructions];
  for (const block of orderedBlocks) finalInstructions.push(...blockOutput.get(block));
  for (const decoy of decoyEntries) finalInstructions.push(...decoy.output);

  // Every placeholder transition jumps to the same dispatcher start.
  for (const instruction of finalInstructions) {
    if (instruction.opCode === Opcode.Jmp && instruction.refOperands[0] === null)
      instruction.refOperands[0] = context.dispatchStart;
  }

  chunk.instructions = finalInstructions;
  chunk.updateMappings();
  for (const instruction of chunk.instructions) instruction.updateRegisters();
  const generatedValidation = validateGeneratedInstructions(chunk);
  if (!generatedValidation.valid)
    return fail(generatedValidation.reason);

  const stateValues = new Set(cfg.blocks.map((block) =>
    encoding ? block.logicalId : block.stateValue));
  if (stateValues.size !== cfg.blocks.length)
    return fail('state identifiers are not unique');
  if (new Set(entries.map((entry) => entry.entry)).size !== entries.length)
    return fail('dispatcher entries are not unique');

  chunk.__advancedCFF = true;
  return {
    transformed: true,
    cfg,
    blocks: cfg.blocks.length,
    stateRegister: context.stateRegister,
    dispatcher,
    encoded: usesEncoding,
    aliases: aliasCount,
    decoys: decoyEntries.length,
    splitStatements,
  };
}

module.exports = {
  transformChunk,
  addNumberConstant,
  STATE_MODULUS,
  modularInverse,
};