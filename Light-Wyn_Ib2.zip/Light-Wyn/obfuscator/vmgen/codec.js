'use strict';

/*
 * The payload format deliberately has separate, inspectable layers:
 *
 *   serialized VM bytecode -> LZSS -> Base91
 *
 * Base91 is only an ASCII transport encoding. It does not provide secrecy.
 * The serializer applies its per-build byte whitening before this module is
 * called, so this module remains a general-purpose binary codec.
 */

const BASE85_ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-:+=^!/*?&<>()[]{}@%$#';
const BASE91_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&()*+,./:;<=>?@[]^_`{|}~"';

function base85Encode(input) {
  const bytes = Buffer.from(input);
  let result = '';
  for (let i = 0; i < bytes.length; i += 4) {
    const remaining = Math.min(4, bytes.length - i);
    let value = 0;
    for (let j = 0; j < 4; j++)
      value = value * 256 + (j < remaining ? bytes[i + j] : 0);

    const chars = new Array(5);
    for (let j = 4; j >= 0; j--) {
      chars[j] = BASE85_ALPHABET[value % 85];
      value = Math.floor(value / 85);
    }
    result += chars.join('');
  }
  return result;
}

function base91Encode(input) {
  const bytes = Buffer.from(input);
  let result = '';
  let counter = 0;
  let numBits = 0;

  for (const byte of bytes) {
    counter |= byte << numBits;
    numBits += 8;
    if (numBits > 13) {
      let entry = counter & 8191;
      if (entry > 88) {
        counter >>>= 13;
        numBits -= 13;
      } else {
        entry = counter & 16383;
        counter >>>= 14;
        numBits -= 14;
      }
      result += BASE91_ALPHABET[entry % 91] + BASE91_ALPHABET[Math.floor(entry / 91)];
    }
  }

  if (numBits > 0) {
    result += BASE91_ALPHABET[counter % 91];
    if (numBits > 7 || counter > 90)
      result += BASE91_ALPHABET[Math.floor(counter / 91)];
  }
  return result;
}

function lzssCompress(input) {
  const source = Buffer.from(input);
  const output = [];
  const length = Buffer.allocUnsafe(4);
  length.writeUInt32LE(source.length, 0);
  for (const byte of length) output.push(byte);

  let position = 0;
  while (position < source.length) {
    const flagIndex = output.length;
    output.push(0);
    let flags = 0;

    for (let bit = 0; bit < 8 && position < source.length; bit++) {
      const windowStart = Math.max(0, position - 4096);
      let bestLength = 0;
      let bestOffset = 0;

      // A bounded backwards search keeps the compressor dependency-free and
      // predictable for web requests while still compressing VM bytecode well.
      for (let candidate = position - 1; candidate >= windowStart; candidate--) {
        if (source[candidate] !== source[position]) continue;
        let lengthFound = 1;
        while (
          lengthFound < 18 &&
          position + lengthFound < source.length &&
          source[candidate + lengthFound] === source[position + lengthFound]
        ) {
          lengthFound++;
          // Overlapping matches are valid in LZSS and are intentionally kept.
          if (candidate + lengthFound >= position)
            break;
        }
        if (lengthFound >= 3 && lengthFound > bestLength) {
          bestLength = lengthFound;
          bestOffset = position - candidate;
          if (bestLength === 18) break;
        }
      }

      if (bestLength >= 3) {
        const distance = bestOffset - 1;
        output.push(distance & 0xff);
        output.push(((distance >> 8) << 4) | (bestLength - 3));
        position += bestLength;
      } else {
        flags |= 1 << bit;
        output.push(source[position]);
        position++;
      }
    }
    output[flagIndex] = flags;
  }
  return Buffer.from(output);
}

function payloadHash(input) {
  let hash = 5381;
  for (const byte of input)
    hash = (hash * 33 + byte) % 4294967291;
  return hash >>> 0;
}

module.exports = {
  BASE85_ALPHABET,
  BASE91_ALPHABET,
  base85Encode,
  base91Encode,
  lzssCompress,
  payloadHash,
};