class ObfuscationSettings {
  constructor(opts) {
    opts = opts || {};
    const preset = String(opts.preset || 'strong').toLowerCase();
    const presetValues = ObfuscationSettings.presets[preset] || ObfuscationSettings.presets.strong;
    const value = (name) => opts[name] !== undefined ? opts[name] : presetValues[name];

    this.preset = ObfuscationSettings.presets[preset] ? preset : 'strong';
    this.encryptStrings = value('encryptStrings');
    this.encryptImportantStrings = value('encryptImportantStrings');
    this.controlFlow = value('controlFlow');
    this.bytecodeCompress = value('bytecodeCompress');
    this.lzssBase91 = opts.lzssBase91 !== undefined
      ? opts.lzssBase91
      : (opts.lzssBase85 !== undefined ? opts.lzssBase85 : presetValues.lzssBase91);
    this.decryptTableLen = value('decryptTableLen');
    this.preserveLineInfo = value('preserveLineInfo');
    this.mutate = value('mutate');
    this.superOperators = value('superOperators');
    this.maxMegaSuperOperators = value('maxMegaSuperOperators');
    this.maxMiniSuperOperators = value('maxMiniSuperOperators');
    this.maxMutations = value('maxMutations');
    this.minify = value('minify');
    this.integrity = value('integrity');
    this.constantPoolShuffle = value('constantPoolShuffle');
    this.opcodeEncoding = value('opcodeEncoding');
    this.controlFlowRounds = value('controlFlowRounds');
    this.cffEnabled = value('cffEnabled');
    this.cffLevel = value('cffLevel');
    this.cffMinimumBlocks = value('cffMinimumBlocks');
    this.cffFlattenProbability = value('cffFlattenProbability');
    this.cffDispatcher = value('cffDispatcher');
    this.cffStateEncoding = value('cffStateEncoding');
    this.cffStateAliases = value('cffStateAliases');
    this.cffBlockSplitting = value('cffBlockSplitting');
    this.cffDecoyStates = value('cffDecoyStates');
    this.cffMaximumBlocks = value('cffMaximumBlocks');
    this.cffGroupSize = value('cffGroupSize');
  }
}

ObfuscationSettings.presets = {
  weak: {
    encryptStrings: false,
    encryptImportantStrings: false,
    controlFlow: false,
    bytecodeCompress: true,
    lzssBase91: true,
    decryptTableLen: 128,
    preserveLineInfo: false,
    mutate: false,
    superOperators: false,
    maxMegaSuperOperators: 0,
    maxMiniSuperOperators: 0,
    maxMutations: 0,
    minify: true,
    integrity: true,
    constantPoolShuffle: true,
    opcodeEncoding: true,
    controlFlowRounds: 0,
    cffEnabled: false,
    cffLevel: 0,
    cffMinimumBlocks: 4,
    cffFlattenProbability: 1,
    cffDispatcher: 'conditional',
    cffStateEncoding: false,
    cffStateAliases: false,
    cffBlockSplitting: false,
    cffDecoyStates: false,
    cffMaximumBlocks: 128,
    cffGroupSize: 4,
  },
  medium: {
    encryptStrings: false,
    encryptImportantStrings: false,
    controlFlow: true,
    bytecodeCompress: true,
    lzssBase91: true,
    decryptTableLen: 500,
    preserveLineInfo: false,
    mutate: true,
    superOperators: true,
    maxMegaSuperOperators: 80,
    maxMiniSuperOperators: 80,
    maxMutations: 160,
    minify: true,
    integrity: true,
    constantPoolShuffle: true,
    opcodeEncoding: true,
    controlFlowRounds: 1,
    cffEnabled: true,
    cffLevel: 1,
    cffMinimumBlocks: 4,
    cffFlattenProbability: 1,
    cffDispatcher: 'conditional',
    cffStateEncoding: true,
    cffStateAliases: false,
    cffBlockSplitting: false,
    cffDecoyStates: false,
    cffMaximumBlocks: 128,
    cffGroupSize: 4,
  },
  strong: {
    encryptStrings: true,
    encryptImportantStrings: true,
    controlFlow: true,
    bytecodeCompress: true,
    lzssBase91: true,
    decryptTableLen: 700,
    preserveLineInfo: false,
    mutate: true,
    superOperators: true,
    maxMegaSuperOperators: 120,
    maxMiniSuperOperators: 120,
    maxMutations: 220,
    minify: true,
    integrity: true,
    constantPoolShuffle: true,
    opcodeEncoding: true,
    controlFlowRounds: 2,
    cffEnabled: true,
    cffLevel: 3,
    cffMinimumBlocks: 3,
    cffFlattenProbability: 1,
    cffDispatcher: 'hybrid',
    cffStateEncoding: true,
    cffStateAliases: true,
    cffBlockSplitting: true,
    cffDecoyStates: true,
    cffMaximumBlocks: 128,
    cffGroupSize: 4,
  },
};

module.exports = ObfuscationSettings;
