const { shuffle, randInt } = require('../utils');

class ObfuscationContext {
  constructor(chunk, settings) {
    this.headChunk = chunk;
    this.settings = settings || {};

    this.chunkSteps = [0, 1, 2, 3, 4];
    shuffle(this.chunkSteps);

    this.instructionSteps1 = [0, 1, 2, 3];
    shuffle(this.instructionSteps1);

    this.instructionSteps2 = [0, 1, 2];
    shuffle(this.instructionSteps2);

    this.constantMapping = [0, 1, 2, 3];
    shuffle(this.constantMapping);

    this.primaryXorKey = randInt(1, 255);
    this.iXorKey1 = randInt(1, 255);
    this.iXorKey2 = randInt(1, 255);
    this.opcodeSalt = randInt(1, 65534);
    this.opcodeStride = randInt(17, 251);
    this.byteStride = randInt(11, 97);
    this.buildNonce = randInt(0, 0x7fffffff);

    this.instructionMapping = new Map();

    if (!this.settings || this.settings.constantPoolShuffle !== false)
      this.shuffleConstantPools(this.headChunk);
  }

  shuffleConstantPools(chunk) {
    shuffle(chunk.constants);
    chunk.updateMappings();
    for (const child of chunk.functions)
      this.shuffleConstantPools(child);
  }
}

ObfuscationContext.ChunkStep = {
  ParameterCount: 0,
  StringTable: 1,
  Instructions: 2,
  Functions: 3,
  LineInfo: 4,
  StepCount: 5
};

module.exports = ObfuscationContext;
