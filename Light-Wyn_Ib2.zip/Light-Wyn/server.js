'use strict';

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const MAX_SOURCE_BYTES = 512 * 1024;
const PORT = Number(process.env.PORT || 3000);

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
  });
  res.end(payload);
}

function sendFile(res, filePath, type) {
  if (!fs.existsSync(filePath)) {
    res.writeHead(404);
    res.end('Not found');
    return;
  }
  res.writeHead(200, {
    'Content-Type': type,
    'Content-Length': fs.statSync(filePath).size,
    'Cache-Control': 'no-cache',
    'X-Content-Type-Options': 'nosniff',
  });
  fs.createReadStream(filePath).pipe(res);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_SOURCE_BYTES + 32 * 1024) {
        reject(Object.assign(new Error('Request too large'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function runObfuscator(source, preset, options) {
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'ironbrew-web-'));
  const input = path.join(work, 'input.lua');
  const output = path.join(work, 'output.lua');
  try {
    fs.writeFileSync(input, source, 'utf8');
    const args = ['run.js', input, output, '--preset', preset];
    if (options && options.preserveLines) args.push('--preserve-lines');
    if (options && options.minify === false) args.push('--no-minify');
    const result = spawnSync(process.execPath, args, {
      cwd: ROOT,
      encoding: 'utf8',
      timeout: 120000,
      maxBuffer: 2 * 1024 * 1024,
    });
    if (result.error)
      throw result.error;
    if (result.status !== 0) {
      const message = (result.stderr || result.stdout || 'Obfuscation failed').trim();
      throw new Error(message.slice(-4000));
    }
    if (!fs.existsSync(output))
      throw new Error('The obfuscator did not produce an output file.');
    return fs.readFileSync(output, 'latin1');
  } finally {
    fs.rmSync(work, { recursive: true, force: true });
  }
}

function contentType(filePath) {
  if (filePath.endsWith('.css')) return 'text/css; charset=utf-8';
  if (filePath.endsWith('.js')) return 'text/javascript; charset=utf-8';
  return 'text/html; charset=utf-8';
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'GET' && req.url === '/api/health') {
      sendJson(res, 200, { ok: true, service: 'ironbrew-web' });
      return;
    }

    if (req.method === 'POST' && req.url === '/api/obfuscate') {
      const raw = await readBody(req);
      let body;
      try {
        body = JSON.parse(raw);
      } catch {
        sendJson(res, 400, { error: 'Expected a JSON request.' });
        return;
      }
      const source = typeof body.source === 'string' ? body.source : '';
      const bytes = Buffer.byteLength(source, 'utf8');
      if (!source.trim()) {
        sendJson(res, 400, { error: 'Lua source is required.' });
        return;
      }
      if (bytes > MAX_SOURCE_BYTES) {
        sendJson(res, 413, { error: 'Lua source must be 512 KB or smaller.' });
        return;
      }
      const preset = ['weak', 'medium', 'strong'].includes(body.preset) ? body.preset : 'strong';
      const started = Date.now();
      const code = runObfuscator(source, preset, {
        preserveLines: body.preserveLines === true,
        minify: body.minify !== false,
      });
      sendJson(res, 200, {
        ok: true,
        preset,
        filename: `obfuscated-${crypto.randomBytes(4).toString('hex')}.lua`,
        code,
        inputBytes: bytes,
        outputBytes: Buffer.byteLength(code, 'latin1'),
        elapsedMs: Date.now() - started,
      });
      return;
    }

    if (req.method === 'GET') {
      const requested = req.url === '/' ? '/index.html' : req.url.split('?')[0];
      const safePath = path.normalize(requested).replace(/^(\.\.[/\\])+/, '');
      const filePath = path.join(PUBLIC, safePath);
      if (!filePath.startsWith(PUBLIC)) {
        res.writeHead(403);
        res.end('Forbidden');
        return;
      }
      sendFile(res, filePath, contentType(filePath));
      return;
    }

    sendJson(res, 405, { error: 'Method not allowed.' });
  } catch (error) {
    const status = error.statusCode || 500;
    console.error(error);
    sendJson(res, status, { error: status === 500 ? 'Obfuscation service failed.' : error.message });
  }
});

if (require.main === module) {
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`IronBrew web server listening on http://0.0.0.0:${PORT}`);
  });
}

module.exports = { server, runObfuscator };