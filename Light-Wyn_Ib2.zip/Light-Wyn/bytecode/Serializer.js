'use strict';

const { InstructionType } = require('../ir/Enums');
const ObfuscationContext = require('../obfuscator/ObfuscationContext');

/*
 * Serializes the existing IR format, but keeps the byte stream binary until
 * the VM generator applies its transport codec. Every build gets a different
 * byte whitening stream and instruction opcode encoding.
 */
class Serializer {
  constructor(context, settings) {
    this._context = context;
    this._settings = settings || {};
  }

  serializeLChunk(chunk, factorXor) {
    if (factorXor === undefined) factorXor = true;
    const raw = [];
    const ctx = this._context;

    const writeByte = (b) => raw.push(b & 0xff);
    const write = (bytes) => {
      for (const byte of bytes) writeByte(byte);
    };
    const writeInt32 = (value) => {
      const b = Buffer.allocUnsafe(4);
      b.writeInt32LE(value | 0, 0);
      write(b);
    };
    const writeUInt16 = (value) => {
      const b = Buffer.allocUnsafe(2);
      b.writeUInt16LE(value & 0xffff, 0);
      write(b);
    };
    const writeNumber = (value) => {
      const b = Buffer.allocUnsafe(8);
      b.writeDoubleLE(value, 0);
      write(b);
    };
    const writeString = (value) => {
      const text = Buffer.from(String(value), 'latin1');
      writeInt32(text.length);
      write(text);
    };

    const serializeInstruction = (inst, index) => {
      if (inst.instructionType === InstructionType.Data) {
        writeByte(1);
        return;
      }

      inst.updateRegisters();
      const cData = inst.customData;
      let opCode = inst.opCode;
      if (cData) {
        const virtualOpcode = cData.opcode;
        opCode = cData.writtenOpcode ? cData.writtenOpcode.VIndex : virtualOpcode.VIndex;
        if (virtualOpcode && virtualOpcode.mutate) virtualOpcode.mutate(inst);
      }

      // The parser reverses this build-specific affine mask using the local
      // instruction index. It is encoding, not encryption.
      if (this._settings.opcodeEncoding !== false) {
        opCode = (opCode ^ ctx.opcodeSalt ^ ((index + 1) * ctx.opcodeStride)) & 0xffff;
      }

      const type = inst.instructionType;
      const mask = inst.constantMask;
      writeByte((type << 1) | (mask << 3));
      writeUInt16(opCode);
      writeUInt16(inst.A);

      switch (type) {
        case InstructionType.AsBx:
          writeInt32(inst.B + (1 << 16));
          break;
        case InstructionType.AsBxC:
          writeInt32(inst.B + (1 << 16));
          writeUInt16(inst.C);
          break;
        case InstructionType.ABC:
          writeUInt16(inst.B);
          writeUInt16(inst.C);
          break;
        case InstructionType.ABx:
          writeInt32(inst.B);
          break;
        default:
          throw new Error('Unsupported instruction type: ' + type);
      }
    };

    chunk.updateMappings();
    writeInt32(chunk.constants.length);
    for (const constant of chunk.constants) {
      // Internal constant tags are intentionally remapped per build.
      writeByte(ctx.constantMapping[constant.type]);
      switch (constant.type) {
        case 1:
          writeByte(constant.data ? 1 : 0);
          break;
        case 2:
          writeNumber(constant.data);
          break;
        case 3:
          writeString(constant.data);
          break;
      }
    }

    const ChunkStep = ObfuscationContext.ChunkStep;
    for (let step = 0; step < ChunkStep.StepCount; step++) {
      switch (ctx.chunkSteps[step]) {
        case ChunkStep.ParameterCount:
          writeByte(chunk.parameterCount);
          break;
        case ChunkStep.Instructions:
          writeInt32(chunk.instructions.length);
          for (let i = 0; i < chunk.instructions.length; i++)
            serializeInstruction(chunk.instructions[i], i);
          break;
        case ChunkStep.Functions:
          writeInt32(chunk.functions.length);
          for (const child of chunk.functions)
            write(this.serializeLChunk(child, false));
          break;
        case ChunkStep.LineInfo:
          if (this._settings.preserveLineInfo) {
            writeInt32(chunk.instructions.length);
            for (const instruction of chunk.instructions)
              writeInt32(instruction.line);
          }
          break;
      }
    }

    const result = Buffer.from(raw);
    if (!factorXor) return result;

    const whitened = Buffer.allocUnsafe(result.length);
    for (let i = 0; i < result.length; i++) {
      const rolling = (ctx.iXorKey1 + i * ctx.byteStride + (i >>> 3) * ctx.iXorKey2) & 0xff;
      whitened[i] = result[i] ^ ctx.primaryXorKey ^ rolling;
    }
    return whitened;
  }
}

module.exports = Serializer;