# IronBrew2 (Original Version v2.7.0) — Full Luau & Path2D JavaScript Obfuscator

> **Watermark mặc định**: `-- Ironbrew 1 https://discord.gg/BPwXUwAMbF`
> **Kiến trúc**: Zero-Dependency Node.js CLI & API (không phụ thuộc C#, `.NET`, hay `luac` bên ngoài)
> **Mã nguồn gốc tham chiếu**: [IronBrew2 (Original Version)](https://github.com/Obfuscator-Collections/IronBrew2/tree/master/Original%20version)

## 1. Tổng quan toàn bộ tính năng (Full Feature Matrix)

| Nhóm tính năng | Chi tiết kỹ thuật | Trạng thái |
| :--- | :--- | :--- |
| **Biên dịch Luau & Lua 5.1 thuần JS** | Lexer, Parser, Luau-to-Lua 5.1 AST Transpiler, Bytecode Compiler, Serializer, Deserializer | Hoàn chỉnh (Full) |
| **82 Virtual Opcodes (IronBrew2 VM)** | Toàn bộ 38 Lua 5.1 opcodes + 4 custom VM opcodes (`SetTop`, `PushStack`, `NewStack`, `SetFenv`) và các biến thể thanh ghi/hằng số | Hoàn chỉnh (82/82) |
| **Đột biến & Gộp lệnh (Mutations & Super-Operators)** | `OpMutated` (xáo trộn thứ tự thanh ghi) + `OpSuperOperator` (gộp chuỗi lệnh Mega 60–80 lệnh & Mini 5–10 lệnh) | Hoàn chỉnh (Full) |
| **Làm rối luồng điều khiển (Control-Flow)** | `TestSpam`, `Bounce`, `TestPreserve`, `EQMutate`, `TestFlip`, `Inlining` (`IB_INLINING_START`, `IB_MAX_CFLOW_START/END`) | Hoàn chỉnh (Full) |
| **Mã hóa hằng chuỗi (Constant Encryption)** | Mã hóa toàn bộ chuỗi (`--encrypt-strings`), chuỗi nhạy cảm (`--encrypt-important-strings`), hoặc theo tag `[STR_ENCRYPT]` | Hoàn chỉnh (Full) |
| **5 Chế độ Giải mã Runtime (Roblox & Chuẩn)** | `lzw`, `encoding-service`, `http-service`, `hybrid`, `roblox-only`, và `path2d` | Hoàn chỉnh (Full) |
| **Lớp Mã hóa Cuối cùng Path2D 1024-Byte** | 32 phép đo hình học IEEE-754 float32/uint32 từ [Path2D](https://create.roblox.com/docs/reference/engine/classes/Path2D) trên `Frame (237x290)` + 4 vòng khuếch tán ARX tạo vòng khóa xoay 1024-byte + kiểm tra toàn vẹn O(1) 4-byte | Hoàn chỉnh (Full) |
| **Custom Buffer API (`_CBuf`)** | Wrapper tùy biến quanh Luau [buffer](https://create.roblox.com/docs/reference/engine/libraries/buffer) (`alloc`, `fromstr`, `tostr`, `len`, `ru8`, `wu8`, `ru32`, `wu32`, `wf32`, `rf32`, `push_f32`, `xor_ring`) | Hoàn chỉnh (Full) |
| **Custom Table API (`_CTbl`)** | Wrapper tùy biến quanh Luau [table](https://create.roblox.com/docs/reference/engine/libraries/table) (`alloc`, `push`, `join`, `rotl8`, `slice`, `wipe` xóa sạch khóa sau giải mã) | Hoàn chỉnh (Full) |
| **Khóa môi trường Game / Place** | `--place-lock <PlaceId>` và `--game-lock <GameId>` trộn trực tiếp vào đầu vào SHA-256 KDF | Hoàn chỉnh (Full) |
| **Output Thẩm mỹ & 100% Không Số (Numberless Obfuscation)** | Thay thế `return function(i,...)local` bằng `return setmetatable({[H] = function() end }, ...)`, loại bỏ **100% chữ số (`0-9`)** khỏi toàn bộ code đã obfuscate (mã hóa số qua bảng hằng `H.aaa..H.zzz` Base-26 và chuỗi qua `_S_DEC` Base-16 `'A'..'P'`) | Hoàn chỉnh (Full) |
| **100% No `loadstring` / `load`** | Toàn bộ chế độ (kể cả `--vm-compress` và `--wrap-compress`) giải mã trực tiếp vào VM bytecode, tuyệt đối không dùng `loadstring` hay `load` | Hoàn chỉnh (Full) |
| **Trình thu gọn mã (Lua Minifier & LZW Wrap)** | Đổi tên biến cục bộ entropy thấp kiểu `luasrcdiet` + tùy chọn bọc nén LZW toàn VM (`--wrap-compress`) | Hoàn chỉnh (Full) |

## 2. Hỗ trợ đầy đủ cú pháp Roblox Luau ([Luau Syntax](https://luau.org/syntax))

Trình biên dịch tích hợp trong `cli/main.js` tự động xử lý và hạ cấp chính xác toàn bộ cú pháp [Luau](https://luau.org/syntax) về tập lệnh VM:

1. **Type Annotations & Type System**:
   - Tự động lược bỏ khai báo kiểu trên biến cục bộ (`local x: number = 10`), tham số hàm (`function f<T>(a: T, b: string?): boolean`), kiểu hàm (`(number, string) -> boolean`), kiểu bảng (`{ [string]: any, x: number }`), union (`A | B`), intersection (`A & B`), `typeof(...)`.
   - Hỗ trợ `type Alias<T> = ...`, `export type Alias = ...`, và phép ép kiểu `expr :: Type` ở mọi ngữ cảnh biểu thức.
2. **Toán tử gán ghép (Compound Assignments)**:
   - Hỗ trợ `+=`, `-=`, `*=`, `/=`, `//=`, `%=`, `^=`, `..=`.
   - Đánh giá biểu thức vế trái (`tbl[idx] += val`) đúng 1 lần duy nhất qua thanh ghi tạm khi chỉ số là biểu thức phức tạp, tránh lỗi lặp side-effect.
3. **Phép chia lấy phần nguyên (Floor Division `//` & `//=`)**:
   - Tự động hạ cấp `a // b` thành `math.floor((a) / (b))` theo đúng ngữ nghĩa số học Luau.
4. **Câu lệnh `continue` trong mọi vòng lặp**:
   - Hỗ trợ `continue` bên trong `for` số học, `for ... in` tổng quát, `while`, và `repeat ... until` (kể cả khi lồng nhau nhiều tầng).
5. **Biểu thức điều kiện `if <cond> then <expr> elseif <cond> then <expr> else <expr>`**:
   - Biên dịch trực tiếp thành nhảy điều kiện trên thanh ghi đích, hỗ trợ chuỗi `elseif` không giới hạn.
6. **Nội suy chuỗi (Backtick String Interpolation `` `Hello {name}!` ``)**:
   - Tự động chuyển đổi các biểu thức `{expr}` bên trong chuỗi backtick thành chuỗi nối với `tostring(expr)`, hỗ trợ các ký tự thoát `\{`, `\}`, `` \` ``, `\u{...}`, `\xXX`, `\z`.
7. **Hằng số nhị phân & dấu phân cách số (`0b1010_0101`, `1_000_000`, `0xFF_AA`)**:
   - Hỗ trợ đầy đủ số nhị phân `0b...`, số thập lục phân `0x...`, và ký tự gạch dưới `_` phân tách chữ số.
8. **Vòng lặp tổng quát (Generalized Iteration `for k, v in tbl do`)**:
   - Tự động kiểm tra nếu đối tượng là hàm iterator, có metamethod `__iter`, hoặc là bảng thuần túy (`next, tbl, nil`) để chạy tương thích cả trên Roblox Luau lẫn Lua 5.1 VM.

## 3. Lớp Mã hóa Cuối cùng dùng Path2D (1024-Byte Rotating Key Layer)

Khi bật cờ `--path2d-layer` (hoặc `--path2d`), trình tạo mã thực hiện quy trình bảo vệ 5 tầng gắn chặt với engine đồ họa C++ của Roblox:

1. **Dựng cây giao diện hình học tại Runtime**:
   - Khởi tạo `ScreenGui` -> `Frame` kích thước `UDim2.new(0, 237, 0, 290)` -> [Path2D](https://create.roblox.com/docs/reference/engine/classes/Path2D) với đúng 4 điểm điều khiển `Path2DControlPoint` cố định.
2. **Trích xuất 32 phép đo phần cứng (128 Bytes Seed)**:
   - Gộp 25 phép đo gốc (`GetLength()`, `GetPositionOnCurve(7/8, 4/11, 4/5, 6/13, 1/13)`, `GetPositionOnCurveArcLength(0.75, 0.8, 7/12)`, `GetTangentOnCurve(4/5, 3/7, 1/6)`, `GetTangentOnCurveArcLength(0.5, 1/3)`) với 7 phép đo mở rộng (`GetBoundingRect().Min/Max`, `GetControlPoints()[1..4]`, `Frame.AbsoluteSize`) thông qua `buffer.writef32` / `buffer.readu8` theo cờ Little-Endian (`60`) và Big-Endian (`81`).
3. **Khuếch tán ARX 4 vòng thành Vòng khóa xoay 1024-Byte (256 Words)**:
   - Kết hợp 128 byte hình học [Path2D](https://create.roblox.com/docs/reference/engine/classes/Path2D) với khóa băm 32-byte `SHA-256` từ [EncodingService](https://create.roblox.com/docs/reference/engine/classes/EncodingService) qua 4 vòng biến đổi Add-Rotate-XOR (`bit32.bxor`, `bit32.lrotate`, nhân modulo 32-bit) để sinh bảng khóa `_KeyRing` 1024 byte.
4. **Custom Buffer API (`_CBuf`) & Custom Table API (`_CTbl`)**:
   - Thực hiện giải mã luồng XOR xoay vòng trên `_CBuf` (`xor_ring`), kiểm tra chữ ký toàn vẹn 4-byte ở thời gian `O(1)` (nếu bất kỳ tọa độ `Path2D` nào bị làm giả hoặc hook sai lệch dù chỉ 1 bit, script dừng ngay lập tức với lỗi `Path2D Geometry Key Mismatch`), sau đó gọi `_CTbl.wipe` xóa trắng toàn bộ khóa trong bộ nhớ trước khi chạy VM.

## 4. Hướng dẫn sử dụng CLI (Command Line Interface)

```bash
# 1. Chế độ bảo vệ tối đa cho Roblox (Full Luau + Roblox-Only + Path2D 1024-Byte Key + Encrypt Strings)
node cli/main.js examples/demo_luau.luau -o out.lua --roblox-only --path2d-layer --encrypt-strings

# 2. Khóa script vào đúng PlaceId / GameId của bạn trên Roblox
node cli/main.js examples/demo_luau.luau -o out.lua --path2d-layer --place-lock 123456789 --game-lock 987654321

# 3. Chế độ Hybrid (tương thích cả Roblox Engine lẫn môi trường kiểm thử Lua 5.1)
node cli/main.js examples/demo_luau.luau -o out.lua --runtime-decode hybrid --encrypt-strings

# 4. Chế độ IronBrew2 truyền thống (LZW Base36)
node cli/main.js examples/demo_luau.luau -o out.lua --vm-compress --encrypt-strings --control-flow
```

### Bảng tùy chọn CLI đầy đủ

| Tùy chọn CLI | Mô tả | Mặc định |
| :--- | :--- | :--- |
| `-o, --out <file>` | Đường dẫn file Lua đầu ra | `out.lua` |
| `--path2d-layer`, `--path2d` | Bật lớp mã hóa cuối cùng [Path2D](https://create.roblox.com/docs/reference/engine/classes/Path2D) 1024-byte + `_CBuf` + `_CTbl` | `false` |
| `--roblox-only` | Bật giải mã 4 tầng độc quyền Roblox (`HttpService` + `EncodingService` Base64 + Zstd + SHA-256 KDF) | `false` |
| `--runtime-decode <mode>` | Chọn chế độ giải mã payload: `lzw`, `encoding-service`, `http-service`, `hybrid`, `roblox-only`, `path2d` | `lzw` |
| `--roblox-strict` | Bắt buộc sử dụng dịch vụ C++ thật của Roblox (chống chạy giả lập Lua 5.1 bên ngoài) | `false` |
| `--place-lock <PlaceId>` | Khóa dẫn xuất SHA-256 KDF vào đúng `game.PlaceId` chỉ định | Không khóa |
| `--game-lock <GameId>` | Khóa dẫn xuất SHA-256 KDF vào đúng `game.GameId` chỉ định | Không khóa |
| `--vm-compress` / `--no-vm-compress` | Bật/tắt nén bytecode LZW Base36 ở chế độ tiêu chuẩn | `true` |
| `--wrap-compress` | Bọc toàn bộ VM đầu ra trong một tầng nén LZW thứ hai (`Lua/compress.lua`) | `false` |
| `--encrypt-strings` | Mã hóa toàn bộ hằng chuỗi bằng hàm giải mã XOR nội tuyến | `false` |
| `--encrypt-important-strings` | Chỉ mã hóa các chuỗi nhạy cảm chứa `http`, `function`, `metatable`, `local` | `false` |
| `--decrypt-table-len <n>` | Độ dài tối đa bảng khóa XOR cho trình giải mã chuỗi | `500` |
| `--control-flow` / `--no-control-flow` | Bật/tắt làm rối luồng điều khiển và inlining | `true` |
| `--mutate` / `--no-mutate` | Bật/tắt đột biến thanh ghi ảo (`OpMutated`) | `true` |
| `--max-mutations <n>` | Số lượng đột biến opcode tối đa | `300` |
| `--super-operators` / `--no-super-operators` | Bật/tắt gộp lệnh Mega & Mini Super-Operators | `true` |
| `--max-mega <n>` / `--max-mini <n>` | Giới hạn số lượng Mega (mặc định `200`) và Mini Super-Operators (mặc định `150`) | `200` / `150` |
| `--preserve-line-info` | Giữ thông tin dòng mã nguồn để báo lỗi chi tiết khi debug | `false` |
| `--no-minify` | Tắt bộ thu gọn tên biến và khoảng trắng đầu ra | `false` |

## 5. Sử dụng qua JavaScript / Node.js API

```javascript
const { IB2, ObfuscationSettings } = require('./cli/main.js');

const settings = new ObfuscationSettings();
settings.RuntimeDecodeMode = 'path2d';
settings.Path2DLayer = true;
settings.RobloxStrict = true;
settings.EncryptStrings = true;
settings.ControlFlow = true;
settings.Mutate = true;
settings.SuperOperators = true;
settings.PlaceLock = 123456789; // Tùy chọn khóa PlaceId

const sourceLuau = `
  type Vec2 = { x: number, y: number }
  local p: Vec2 = { x = 10, y = 25 }
  p.x += 5
  local tag = if p.x > 10 then \`Pos({p.x}, {p.y})\` else "origin"
  print(tag, p.y // 4)
`;

const obfuscatedLua = IB2.ObfuscateSource(sourceLuau, settings);
console.log(obfuscatedLua);
```

## 6. Chạy bộ kiểm thử tự động (Automated Tests)

Dự án đi kèm 3 bộ test kiểm tra toàn diện từ trình biên dịch [Luau](https://luau.org/syntax), các dịch vụ [EncodingService](https://create.roblox.com/docs/reference/engine/classes/EncodingService) / [HttpService](https://create.roblox.com/docs/reference/engine/classes/HttpService), cho đến lớp khóa hình học [Path2D](https://create.roblox.com/docs/reference/engine/classes/Path2D):

```bash
npm test
# Hoặc chạy riêng từng bộ test:
node tests/test_full_luau.js
node tests/test_roblox_only.js
node tests/test_path2d_e2e.js
```
