
-- OBF STABILITY TEST SUITE v5.0  —  Unified Module
-- Tác giả: ENI  |  Target: Luau executor / Custom VM
-- Nâng cấp bởi: Tranthien
--
-- Cách dùng:
--   local Suite = require(script.OBFTest)   -- ModuleScript
--   Suite.run()                    -- chạy tất cả test
--   Suite.runGroup("STRING")       -- chạy một nhóm
--   Suite.runTags("fast", "core")  -- chạy theo tag
--   Suite.only("Tên","GRP",fn)     -- debug: chỉ chạy test này
--   Suite.addTest("Tên","GRP",fn)  -- mở rộng test (tags tuỳ chọn)
--   Suite.skipTest("Tên","GRP","Lý do")
--   Suite.reset()                  -- xoá toàn bộ registry
--   Suite.export(summary)          -- xuất kết quả dạng JSON
--
-- Nâng cấp v5.0:
--   + retryCount    : tự retry test fail (mặc định 1 lần)
--   + showProgress  : hiện [N/M] counter khi chạy
--   + showSlow      : báo cáo test chạy chậm
--   + slowThresholdMs: ngưỡng chậm (ms)
--   + only()        : debug mode — chỉ chạy test được đánh dấu
--   + runTags()     : lọc test theo tag
--   + beforeAll/afterAll: hook toàn cục
--   + reset()       : xoá registry (dùng nhiều suite)
--   + export()      : xuất JSON result
--   + assertXxx()   : assert helpers có thông báo rõ ràng
--   + tableDeepEq() : so sánh deep table (nested)
--   + trimErr()     : bỏ prefix path:line trong lỗi
--   + Retry badge   : hiện ↺N khi test pass sau retry
--   + Slow badge    : hiện 🐢 khi vượt slowThresholdMs
--   + Pass rate %   : hiện % pass trong tổng kết
--   + Tổng thời gian toàn bộ suite
--   + Danh sách test chậm nhất (top N)
--   + Nhóm mới: CLOSURE, ITERATOR
-- ============================================================

local OBFTest = {}
OBFTest.__index = OBFTest

-- ─── VERSION ────────────────────────────────────────────────
OBFTest.VERSION = "5.0"

-- ─── CONFIG ─────────────────────────────────────────────────
OBFTest.config = {
    verbose          = true,   -- in từng test khi chạy
    stopOnFail       = false,  -- dừng ngay khi fail đầu tiên
    timeTests        = true,   -- đo thời gian từng test (ms)
    showWarns        = true,   -- hiện WARN trong report cuối
    retryCount       = 1,      -- số lần retry khi test fail (0 = không retry)
    showProgress     = true,   -- hiện [N/M] counter
    showSlow         = true,   -- hiện danh sách test chậm
    slowThresholdMs  = 50,     -- ngưỡng "chậm" (ms)
    maxSlowListed    = 5,      -- số test chậm in ra tối đa
}

-- ─── INTERNAL STATE ─────────────────────────────────────────
local _registry  = {}  -- {name, group, fn, skip, reason, tags, only}
local _warns     = {}
local _beforeAll = nil
local _afterAll  = nil
local _onlyMode  = false

-- Thứ tự nhóm in ra report
local GROUP_ORDER = {
    "STRING", "SYNTAX", "OPCODE", "EXEC", "SCOPE", "MATH",
    "TABLE", "FUNCTION", "METATABLES", "ROBLOX", "CONTROL", "TYPE", "ENV",
    "CLOSURE", "ITERATOR", "TABFUNC", "BENCHMARK", "UNC",
}

-- ─── HELPERS ────────────────────────────────────────────────

--- So sánh float với epsilon
local function nearEq(a, b, eps)
    eps = eps or 1e-9
    return math.abs(a - b) < eps
end

--- Deep equal hỗ trợ nested tables (thay thế flat tableEq cũ)
local function tableDeepEq(t1, t2, _depth)
    _depth = _depth or 0
    if _depth > 32 then return true end         -- tránh infinite recursion
    if type(t1) ~= type(t2) then return false end
    if type(t1) ~= "table"  then return t1 == t2 end
    for k, v in pairs(t1) do
        if not tableDeepEq(v, t2[k], _depth + 1) then return false end
    end
    for k, v in pairs(t2) do
        if not tableDeepEq(t1[k], v, _depth + 1) then return false end
    end
    return true
end

--- Flat equal (giữ nguyên cho backward compat)
local function tableEq(t1, t2)
    for k, v in pairs(t1) do if t2[k] ~= v then return false end end
    for k, v in pairs(t2) do if t1[k] ~= v then return false end end
    return true
end

--- Rút gọn error message — bỏ prefix "path:line: "
local function trimErr(e)
    if type(e) ~= "string" then return tostring(e) end
    return e:match(":%d+: (.+)$") or e
end

-- ─── ASSERT HELPERS ─────────────────────────────────────────
-- Các hàm assert có thông báo chi tiết hơn assert() thuần

--- assertEqual(a, b [, msg])
function OBFTest.assertEqual(a, b, msg)
    if a ~= b then
        error((msg or "assertEqual") ..
              " | expected=" .. tostring(b) ..
              "  got="       .. tostring(a), 2)
    end
end

--- assertNear(a, b [, eps [, msg]])
function OBFTest.assertNear(a, b, eps, msg)
    if not nearEq(a, b, eps) then
        error((msg or "assertNear") ..
              " | diff=" .. string.format("%.2e", math.abs(a - b)) ..
              "  eps="   .. tostring(eps or 1e-9), 2)
    end
end

--- assertType(value, expectedType [, msg])
function OBFTest.assertType(v, t, msg)
    if type(v) ~= t then
        error((msg or "assertType") ..
              " | expected=" .. t ..
              "  got="       .. type(v), 2)
    end
end

--- assertError(fn [, msg])  — hàm fn phải raise lỗi
function OBFTest.assertError(fn, msg)
    local ok = pcall(fn)
    if ok then
        error((msg or "assertError: hàm không raise lỗi như kỳ vọng"), 2)
    end
end

--- assertTableEq(t1, t2 [, msg])  — so sánh deep equal
function OBFTest.assertTableEq(t1, t2, msg)
    if not tableDeepEq(t1, t2) then
        error((msg or "assertTableEq: hai table không bằng nhau (deep)"), 2)
    end
end

-- ─── REGISTRATION API ───────────────────────────────────────

--- addTest(name, group, fn [, tags])
--- tags: array of strings, dùng cho runTags()
function OBFTest.addTest(name, group, fn, tags)
    assert(type(name)  == "string",   "addTest: name phải là string")
    assert(type(group) == "string",   "addTest: group phải là string")
    assert(type(fn)    == "function", "addTest: fn phải là function")
    table.insert(_registry, {
        name  = name,
        group = group,
        fn    = fn,
        skip  = false,
        only  = false,
        tags  = tags or {},
    })
end

--- only(name, group, fn [, tags])
--- Kích hoạt "only mode": chỉ các test được đánh dấu .only() mới chạy
function OBFTest.only(name, group, fn, tags)
    _onlyMode = true
    assert(type(name)  == "string",   "only: name phải là string")
    assert(type(group) == "string",   "only: group phải là string")
    assert(type(fn)    == "function", "only: fn phải là function")
    table.insert(_registry, {
        name  = name,
        group = group,
        fn    = fn,
        skip  = false,
        only  = true,
        tags  = tags or {},
    })
end

--- skipTest(name, group [, reason])
function OBFTest.skipTest(name, group, reason)
    table.insert(_registry, {
        name   = name,
        group  = group,
        fn     = nil,
        skip   = true,
        only   = false,
        reason = reason or "no reason given",
        tags   = {},
    })
end

--- warn(msg) — thêm cảnh báo vào report
function OBFTest.warn(msg)
    table.insert(_warns, "⚠️  WARN | " .. tostring(msg))
end

--- beforeAll(fn) — chạy một lần trước toàn bộ test suite
function OBFTest.beforeAll(fn) _beforeAll = fn end

--- afterAll(fn) — chạy một lần sau toàn bộ test suite
function OBFTest.afterAll(fn)  _afterAll  = fn  end

--- reset() — xoá toàn bộ registry (hữu ích khi chạy nhiều suite)
function OBFTest.reset()
    _registry  = {}
    _warns     = {}
    _onlyMode  = false
    _beforeAll = nil
    _afterAll  = nil
end

-- ─── RUNNER ─────────────────────────────────────────────────

local function runOne(entry)
    if entry.skip then
        return {
            name    = entry.name,
            group   = entry.group,
            status  = "SKIP",
            err     = entry.reason,
            time    = 0,
            retries = 0,
        }
    end

    local cfg      = OBFTest.config
    local maxRetry = cfg.retryCount or 0
    local tries    = 0
    local ok, err, elapsed

    repeat
        tries   = tries + 1
        local t0 = cfg.timeTests and os.clock() or 0
        ok, err  = pcall(entry.fn)
        elapsed  = cfg.timeTests and ((os.clock() - t0) * 1000) or 0
    until ok or tries > maxRetry

    return {
        name    = entry.name,
        group   = entry.group,
        status  = ok and "PASS" or "FAIL",
        err     = ok and nil or trimErr(tostring(err)),
        time    = elapsed,
        retries = tries - 1,
    }
end

--- run([groupFilter [, tagFilter]])
--- groupFilter: string tên nhóm, hoặc nil để chạy tất cả
--- tagFilter: array of string tags; chỉ chạy test có ít nhất 1 tag khớp
function OBFTest.run(groupFilter, tagFilter)
    local cfg = OBFTest.config
    print(string.format(
        "\n▶  OBF TEST SUITE v%s  |  Registry: %d tests",
        OBFTest.VERSION, #_registry
    ))

    _warns = {}
    local results   = {}
    local pass, fail, skip = 0, 0, 0
    local totalTime = 0

    -- beforeAll hook
    if _beforeAll then
        local ok, err = pcall(_beforeAll)
        if not ok then
            OBFTest.warn("beforeAll hook lỗi: " .. tostring(err))
        end
    end

    -- Xây queue theo filter
    local queue = {}
    for _, entry in ipairs(_registry) do
        -- Group filter
        local groupOk = (groupFilter == nil or entry.group == groupFilter)
        -- Tag filter
        local tagOk = true
        if tagFilter and #tagFilter > 0 then
            tagOk = false
            for _, ft in ipairs(tagFilter) do
                for _, et in ipairs(entry.tags or {}) do
                    if et == ft then tagOk = true; break end
                end
                if tagOk then break end
            end
        end
        -- Only mode
        local onlyOk = not _onlyMode or entry.only
        if groupOk and tagOk and onlyOk then
            queue[#queue+1] = entry
        end
    end

    local total = #queue

    for idx, entry in ipairs(queue) do
        local progress = cfg.showProgress
            and string.format("[%d/%d] ", idx, total) or ""

        if cfg.verbose then
            local tag = entry.skip and "⏭  SKIP" or "▶  RUN "
            print(progress .. tag .. " | [" .. entry.group .. "] " .. entry.name)
        end

        local r = runOne(entry)
        table.insert(results, r)
        totalTime = totalTime + (r.time or 0)

        if r.status == "PASS" then
            pass = pass + 1
            if cfg.verbose then
                local t     = cfg.timeTests
                    and string.format(" (%.2fms)", r.time) or ""
                local retry = (r.retries and r.retries > 0)
                    and string.format(" ↺%d", r.retries) or ""
                local slow  = (cfg.timeTests and r.time >= cfg.slowThresholdMs)
                    and " 🐢" or ""
                print("  ✅ PASS" .. t .. slow .. retry)
            end
        elseif r.status == "FAIL" then
            fail = fail + 1
            if cfg.verbose then
                print("  ❌ FAIL >> " .. (r.err or "unknown"))
            end
            if cfg.stopOnFail then break end
        else
            skip = skip + 1
            if cfg.verbose then
                print("  ⏭  SKIP >> " .. (r.err or ""))
            end
        end
    end

    -- afterAll hook
    if _afterAll then
        local ok, err = pcall(_afterAll)
        if not ok then
            OBFTest.warn("afterAll hook lỗi: " .. tostring(err))
        end
    end

    local summary = {
        pass      = pass,
        fail      = fail,
        skip      = skip,
        warns     = #_warns,
        results   = results,
        warnList  = _warns,
        totalTime = totalTime,
        total     = total,
    }
    OBFTest.printReport(summary)
    return summary
end

function OBFTest.runGroup(group)    return OBFTest.run(group, nil) end
function OBFTest.runAll()           return OBFTest.run(nil,   nil) end

--- runTags(...) — chạy test có ít nhất 1 trong các tag được cung cấp
function OBFTest.runTags(...)
    local tags = {...}
    return OBFTest.run(nil, tags)
end

-- ─── EXPORT ─────────────────────────────────────────────────

--- export(summary) → JSON string
--- Dùng để lưu hoặc gửi kết quả ra ngoài
function OBFTest.export(summary)
    local parts = {}
    parts[#parts+1] = string.format('{"version":%q,"pass":%d,"fail":%d,"skip":%d,',
        OBFTest.VERSION, summary.pass, summary.fail, summary.skip)
    parts[#parts+1] = string.format('"total":%d,"totalTimeMs":%.3f,"results":[',
        summary.total, summary.totalTime)
    for i, r in ipairs(summary.results) do
        parts[#parts+1] = string.format(
            '{"name":%q,"group":%q,"status":%q,"timeMs":%.3f,"retries":%d}',
            r.name, r.group, r.status, r.time or 0, r.retries or 0)
        if i < #summary.results then parts[#parts+1] = "," end
    end
    parts[#parts+1] = ']}'
    return table.concat(parts)
end

-- ─── REPORT ─────────────────────────────────────────────────

function OBFTest.printReport(summary)
    local SEP  = string.rep("═", 66)
    local sep2 = string.rep("─", 66)
    local cfg  = OBFTest.config

    print("\n" .. SEP)
    print(string.format("  OBF STABILITY REPORT  v%s", OBFTest.VERSION))
    print(SEP)

    -- Nhóm kết quả theo group
    local byGroup = {}
    for _, r in ipairs(summary.results) do
        if not byGroup[r.group] then
            byGroup[r.group] = { pass=0, fail=0, skip=0, items={} }
        end
        local g = byGroup[r.group]
        g.items[#g.items+1] = r
        if     r.status == "PASS" then g.pass = g.pass + 1
        elseif r.status == "FAIL" then g.fail = g.fail + 1
        else                           g.skip = g.skip + 1
        end
    end

    -- In các group theo thứ tự định sẵn
    for _, gname in ipairs(GROUP_ORDER) do
        local g = byGroup[gname]
        if g then
            local icon = g.fail > 0 and "❌" or (g.skip > 0 and "⚠️ " or "✅")
            print(string.format("\n  %s  %-14s  %dP / %dF / %dS",
                icon, gname, g.pass, g.fail, g.skip))
            print(sep2)
            for _, r in ipairs(g.items) do
                local icon2  = r.status == "PASS" and "✅"
                            or r.status == "FAIL" and "❌" or "⏭ "
                local timing = (cfg.timeTests and r.time > 0)
                    and string.format("[%.2fms]", r.time) or ""
                local slowBadge  = (cfg.timeTests and r.time >= cfg.slowThresholdMs)
                    and " 🐢" or ""
                local retryBadge = (r.retries and r.retries > 0)
                    and string.format(" ↺%d", r.retries) or ""
                print(string.format("    %s  %-42s %s%s%s",
                    icon2, r.name, timing, slowBadge, retryBadge))
                if r.status == "FAIL" then
                    print("        >> " .. (r.err or ""))
                end
            end
        end
    end

    -- Custom groups không trong GROUP_ORDER
    local knownGroups = {}
    for _, g in ipairs(GROUP_ORDER) do knownGroups[g] = true end
    local hasOther = false
    for gname, g in pairs(byGroup) do
        if not knownGroups[gname] then
            if not hasOther then
                print("\n  📦  CUSTOM")
                print(sep2)
                hasOther = true
            end
            for _, r in ipairs(g.items) do
                local icon2 = r.status=="PASS" and "✅"
                           or r.status=="FAIL" and "❌" or "⏭ "
                print(string.format("    %s  [%s] %s", icon2, gname, r.name))
                if r.status == "FAIL" then
                    print("        >> " .. (r.err or ""))
                end
            end
        end
    end

    -- WARN list
    if cfg.showWarns and #summary.warnList > 0 then
        print("\n" .. sep2)
        print("  ⚠️   WARNINGS:")
        for _, w in ipairs(summary.warnList) do print("  " .. w) end
    end

    -- Slow test list
    if cfg.showSlow and cfg.timeTests then
        local slowList = {}
        for _, r in ipairs(summary.results) do
            if (r.time or 0) >= (cfg.slowThresholdMs or 50) then
                slowList[#slowList+1] = r
            end
        end
        if #slowList > 0 then
            table.sort(slowList, function(a, b) return a.time > b.time end)
            print("\n" .. sep2)
            print(string.format("  🐢  SLOWEST (≥%.0fms):", cfg.slowThresholdMs))
            local limit = math.min(#slowList, cfg.maxSlowListed or 5)
            for i = 1, limit do
                local r = slowList[i]
                print(string.format("      %d. [%s] %-36s %.2fms",
                    i, r.group, r.name, r.time))
            end
        end
    end

    -- Tổng kết
    print("\n" .. SEP)
    local ran  = summary.total - summary.skip
    local rate = ran > 0
        and string.format("%.1f%%", (summary.pass / ran) * 100) or "N/A"
    print(string.format(
        "  TỔNG KẾT  %d PASS  |  %d FAIL  |  %d SKIP  |  %d WARN  |  Pass Rate: %s",
        summary.pass, summary.fail, summary.skip, summary.warns, rate))
    print(string.format(
        "  ⏱  Thời gian tổng: %.3f ms  |  Số test: %d",
        summary.totalTime, summary.total))
    print(SEP)

    if summary.fail == 0 then
        print("  🎉  Obfuscator của bạn ổn định hoàn toàn!")
    elseif summary.fail <= 3 then
        print("  ⚠️   Có vài vấn đề nhỏ cần xem lại.")
    else
        print("  ❌  Nhiều test fail — VM/obf cần debug nghiêm túc.")
    end
    print(SEP .. "\n")
end

-- ─── GROUP: STRING ──────────────────────────────────────────

OBFTest.addTest("String literal basic ASCII", "STRING", function()
    local s = "Hello, World!"
    assert(s == "Hello, World!", "Mismatch: " .. s)
end)

OBFTest.addTest("Ký tự đặc biệt (tab, newline, backslash)", "STRING", function()
    local s = "Tab:\t Newline:\n Quote:\" Backslash:\\"
    assert(#s > 10, "String bị truncate sau obf")
end)

OBFTest.addTest("UTF-8 / Unicode (tiếng Việt)", "STRING", function()
    local s = "Xin chào thế giới"
    assert(s:find("ch") ~= nil, "UTF-8 bị corrupt: " .. s)
end)

OBFTest.addTest("String rỗng", "STRING", function()
    local s = ""
    assert(s == "" and #s == 0, "Empty string bị biến thành: '" .. s .. "'")
end)

OBFTest.addTest("String dài (1000 ký tự)", "STRING", function()
    local s = string.rep("abcdefghij", 100)
    assert(#s == 1000, "Long string bị cắt, length = " .. #s)
end)

OBFTest.addTest("Escape sequence numeric (\\65\\66\\67 → ABC)", "STRING", function()
    local s = "\65\66\67"
    assert(s == "ABC", "Escape sai: " .. tostring(s))
end)

OBFTest.addTest("String concatenation (..) sau obf", "STRING", function()
    local a, b = "foo", "bar"
    assert(a .. b == "foobar", "Concat sai: " .. (a .. b))
end)

OBFTest.addTest("String equality (== operator)", "STRING", function()
    local s1, s2 = "test_string", "test_string"
    assert(s1 == s2, "Equality bị break")
end)

OBFTest.addTest("tostring() cho number, bool, nil", "STRING", function()
    assert(tostring(12345) == "12345", "tostring số sai")
    assert(tostring(true)  == "true",  "tostring bool sai")
    assert(tostring(nil)   == "nil",   "tostring nil sai")
end)

OBFTest.addTest("string.format cơ bản", "STRING", function()
    local s = string.format("x=%d y=%.2f s=%s", 7, 3.14, "hi")
    assert(s == "x=7 y=3.14 s=hi", "string.format sai: " .. s)
end)

OBFTest.addTest("string.sub, string.len, string.upper", "STRING", function()
    local s = "abcdef"
    assert(s:sub(2, 4) == "bcd",  "sub sai")
    assert(#s == 6,                "len sai")
    assert(s:upper() == "ABCDEF", "upper sai")
end)

OBFTest.addTest("string.lower và string.rep", "STRING", function()
    assert(string.lower("HELLO") == "hello", "lower sai")
    assert(string.rep("ab", 3)   == "ababab", "rep sai")
end)

OBFTest.addTest("string.reverse", "STRING", function()
    assert(string.reverse("Lua") == "auL", "reverse sai")
end)

OBFTest.addTest("string.byte và string.char", "STRING", function()
    assert(string.byte("A")    == 65,  "byte sai")
    assert(string.char(65, 66) == "AB","char sai")
end)

OBFTest.addTest("string.find cơ bản", "STRING", function()
    local s = "hello world"
    local i, j = string.find(s, "world")
    assert(i == 7 and j == 11, "find sai: i=" .. tostring(i) .. " j=" .. tostring(j))
end)

OBFTest.addTest("string.find với pattern", "STRING", function()
    local s = "abc123def"
    local i = string.find(s, "%d+")
    assert(i == 4, "pattern find sai: i=" .. tostring(i))
end)

OBFTest.addTest("string.match capture", "STRING", function()
    local date = "2025-06-30"
    local y, m, d = string.match(date, "(%d+)-(%d+)-(%d+)")
    assert(y=="2025" and m=="06" and d=="30", "match capture sai")
end)

OBFTest.addTest("string.gmatch iteration", "STRING", function()
    local s = "one two three"
    local words = {}
    for w in string.gmatch(s, "%a+") do
        words[#words+1] = w
    end
    assert(#words == 3 and words[2] == "two", "gmatch sai")
end)

OBFTest.addTest("string.gsub replace", "STRING", function()
    local result, n = string.gsub("aaa bbb aaa", "aaa", "xxx")
    assert(result == "xxx bbb xxx", "gsub result sai: " .. result)
    assert(n == 2, "gsub count sai: " .. tostring(n))
end)

OBFTest.addTest("Multiline string [[ ]]", "STRING", function()
    local s = [[
line1
line2]]
    assert(s:find("line1") ~= nil, "multiline string sai")
    assert(s:find("line2") ~= nil, "multiline line2 mất")
end)

OBFTest.addTest("String chứa null byte (\\0)", "STRING", function()
    local s = "abc\0def"
    -- Lua tính đúng length kể cả null byte
    assert(#s == 7, "Null byte làm length sai: " .. #s)
end)

OBFTest.addTest("Numeric string comparison (tonumber)", "STRING", function()
    local n = tonumber("42")
    assert(n == 42 and type(n) == "number", "tonumber sai")
    assert(tonumber("0xFF") == 255, "tonumber hex sai")
    assert(tonumber("abc") == nil,  "tonumber invalid không trả nil")
end)

-- ─── GROUP: EXEC ────────────────────────────────────────────

OBFTest.addTest("loadstring basic exec (return 1+1)", "EXEC", function()
    if not loadstring then return end
    local fn, err = loadstring("return 1 + 1")
    assert(fn ~= nil, "loadstring → nil: " .. tostring(err))
    assert(fn() == 2, "loadstring exec sai")
end)

OBFTest.addTest("loadstring với string op (:upper)", "EXEC", function()
    if not loadstring then return end
    local fn = loadstring("local x = 'hello' return x:upper()")
    assert(fn and fn() == "HELLO", "loadstring string op sai")
end)

OBFTest.addTest("loadstring invalid code → nil + err string", "EXEC", function()
    if not loadstring then return end
    local fn, err = loadstring("this is === not lua")
    assert(fn == nil,             "loadstring invalid không trả nil")
    assert(type(err) == "string", "error message không phải string")
end)

OBFTest.addTest("pcall catch error cơ bản", "EXEC", function()
    local ok, err = pcall(function() error("test error") end)
    assert(ok == false,           "pcall không catch")
    assert(type(err) == "string", "pcall err không phải string")
end)

OBFTest.addTest("pcall với error object (table)", "EXEC", function()
    local ok, obj = pcall(function()
        error({ code = 404, msg = "not found" })
    end)
    assert(ok == false,             "pcall không catch table error")
    assert(type(obj) == "table",    "pcall err obj không phải table")
    assert(obj.code == 404,         "table error field sai")
end)

OBFTest.addTest("Nested pcall không crash VM", "EXEC", function()
    local ok1 = pcall(function()
        local ok2 = pcall(function() error("inner") end)
        assert(ok2 == false)
        error("outer")
    end)
    assert(ok1 == false, "Nested pcall crash")
end)

OBFTest.addTest("coroutine yield / resume cơ bản", "EXEC", function()
    local co = coroutine.create(function() coroutine.yield(42) end)
    local ok, val = coroutine.resume(co)
    assert(ok  == true, "coroutine resume failed")
    assert(val == 42,   "coroutine yield sai: " .. tostring(val))
end)

OBFTest.addTest("coroutine multi-yield", "EXEC", function()
    local co = coroutine.create(function()
        coroutine.yield(1); coroutine.yield(2); coroutine.yield(3)
    end)
    local vals = {}
    for _ = 1, 3 do
        local ok, v = coroutine.resume(co)
        assert(ok, "coroutine resume fail")
        vals[#vals+1] = v
    end
    assert(vals[1]==1 and vals[2]==2 and vals[3]==3, "multi-yield sai")
end)

OBFTest.addTest("coroutine status transitions", "EXEC", function()
    local co = coroutine.create(function()
        coroutine.yield()
    end)
    assert(coroutine.status(co) == "suspended", "status ban đầu sai")
    coroutine.resume(co)
    assert(coroutine.status(co) == "suspended", "status sau yield sai")
    coroutine.resume(co)
    assert(coroutine.status(co) == "dead",      "status sau kết thúc sai")
end)

OBFTest.addTest("coroutine.wrap", "EXEC", function()
    local gen = coroutine.wrap(function()
        for i = 1, 3 do coroutine.yield(i) end
    end)
    assert(gen() == 1 and gen() == 2 and gen() == 3, "coroutine.wrap sai")
end)

OBFTest.addTest("xpcall với message handler", "EXEC", function()
      local handled = false
      local ok = xpcall(function()
          error("xpcall test")
      end, function(msg)
          handled = true
          return msg
      end)
      assert(ok == false, "xpcall khong catch")
      assert(handled, "message handler khong duoc goi")
  end)

OBFTest.addTest("error() với level 0 (no location prefix)", "EXEC", function()
    local ok, msg = pcall(function()
        error("raw_error", 0)
    end)
    assert(ok == false,         "pcall không catch")
    assert(msg == "raw_error",  "error level 0 sai: " .. tostring(msg))
end)

-- ─── GROUP: SCOPE ───────────────────────────────────────────

OBFTest.addTest("Local variable scope isolation", "SCOPE", function()
    local x = 100
    do
        local x = 200
        assert(x == 200, "Inner scope sai")
    end
    assert(x == 100, "Outer scope bị ảnh hưởng")
end)

OBFTest.addTest("Upvalue capture trong closure", "SCOPE", function()
    local function makeCounter()
        local n = 0
        return function() n = n + 1; return n end
    end
    local counter = makeCounter()
    assert(counter() == 1, "Upvalue #1 sai")
    assert(counter() == 2, "Upvalue #2 sai")
    assert(counter() == 3, "Upvalue #3 sai")
end)

OBFTest.addTest("Shared upvalue giữa hai closures", "SCOPE", function()
    local function makePair()
        local val = 0
        local function get() return val end
        local function set(v) val = v end
        return get, set
    end
    local get, set = makePair()
    set(99)
    assert(get() == 99, "Shared upvalue sai: " .. tostring(get()))
end)

OBFTest.addTest("Upvalue modify từ nhiều tầng lồng", "SCOPE", function()
    local x = 0
    local function outer()
        local function inner()
            x = x + 10
        end
        inner()
    end
    outer(); outer()
    assert(x == 20, "Deep upvalue modify sai: " .. x)
end)

OBFTest.addTest("Closure không share upvalue độc lập", "SCOPE", function()
    local function makeCounter()
        local n = 0
        return function() n = n + 1; return n end
    end
    local c1 = makeCounter()
    local c2 = makeCounter()
    c1(); c1(); c1()
    c2()
    assert(c1() == 4, "c1 counter sai")
    assert(c2() == 2, "c2 counter sai (không được share c1's upvalue)")
end)

-- ─── GROUP: MATH ────────────────────────────────────────────

OBFTest.addTest("Integer arithmetic cơ bản", "MATH", function()
    assert(1 + 1   == 2,   "+")
    assert(10 - 3  == 7,   "-")
    assert(4 * 5   == 20,  "*")
    assert(10 / 2  == 5,   "/")
    assert(10 % 3  == 1,   "%")
    assert(2 ^ 8   == 256, "^")
end)

OBFTest.addTest("Integer floor division (//)", "MATH", function()
    -- Luau hỗ trợ // từ 0.536+
    local ok, result = pcall(function()
        return (load or loadstring)("return 10 // 3")()
    end)
    if ok then
        assert(result == 3, "// floor div sai: " .. tostring(result))
    else
        OBFTest.warn("// operator không available (Lua version cũ)")
    end
end)

OBFTest.addTest("Unary minus operator", "MATH", function()
    local x = 5
    assert(-x == -5, "Unary minus sai")
    assert(-(- x) == 5, "Double unary minus sai")
end)

OBFTest.addTest("Float precision (0.1 + 0.2)", "MATH", function()
    local r = 0.1 + 0.2
    assert(nearEq(r, 0.3, 1e-10), "Float precision: " .. r)
end)

OBFTest.addTest("math.floor, math.ceil, math.abs", "MATH", function()
    assert(math.floor(3.9)   == 3, "floor")
    assert(math.floor(-3.1)  == -4,"floor negative")
    assert(math.ceil(3.1)    == 4, "ceil")
    assert(math.ceil(-3.9)   == -3,"ceil negative")
    assert(math.abs(-7)      == 7, "abs")
end)

OBFTest.addTest("math.max, math.min", "MATH", function()
    assert(math.max(1, 5, 3, 9, 2) == 9, "max")
    assert(math.min(1, 5, 3, 9, 2) == 1, "min")
end)

OBFTest.addTest("math.sqrt, math.huge, math.pi", "MATH", function()
    assert(nearEq(math.sqrt(9), 3),         "sqrt")
    assert(math.huge > 1e300,               "huge")
    assert(nearEq(math.pi, 3.14159, 1e-4),  "pi")
end)

OBFTest.addTest("math.sin, math.cos, math.tan", "MATH", function()
    assert(nearEq(math.sin(0),         0),   "sin(0)")
    assert(nearEq(math.cos(0),         1),   "cos(0)")
    assert(nearEq(math.sin(math.pi/2), 1),   "sin(pi/2)")
    assert(nearEq(math.cos(math.pi),  -1),   "cos(pi)")
end)

OBFTest.addTest("math.exp và math.log", "MATH", function()
    assert(nearEq(math.exp(0), 1),             "exp(0)")
    assert(nearEq(math.exp(1), 2.71828, 1e-4), "exp(1) ≈ e")
    assert(nearEq(math.log(1), 0),             "log(1)")
    assert(nearEq(math.log(math.exp(1)), 1),   "log(e)")
end)

OBFTest.addTest("math.random seed + range", "MATH", function()
    math.randomseed(42)
    local r = math.random(1, 100)
    assert(r >= 1 and r <= 100, "random out of range: " .. r)
    -- Test determinism với seed
    math.randomseed(42)
    local r2 = math.random(1, 100)
    assert(r == r2, "random không deterministic với cùng seed")
end)

OBFTest.addTest("math.modf (integer + fraction)", "MATH", function()
    local int, frac = math.modf(5.7)
    assert(int == 5,              "modf int sai: " .. int)
    assert(nearEq(frac, 0.7),     "modf frac sai: " .. frac)
end)

OBFTest.addTest("Overflow / large number", "MATH", function()
    local big = 2^53
    assert(big == 9007199254740992, "2^53 sai: " .. big)
    assert(math.huge == math.huge,  "huge == itself")
    assert(math.huge ~= math.huge * -1, "huge vs -huge")
end)

OBFTest.addTest("NaN behavior", "MATH", function()
    local nan = 0/0
    -- NaN không equal chính nó
    assert(nan ~= nan, "NaN self-equality sai (phải ~= nan)")
    assert(not (nan < 1),  "NaN < 1 phải false")
    assert(not (nan > 1),  "NaN > 1 phải false")
end)

OBFTest.addTest("Bitwise ops (bit32)", "MATH", function()
    if not bit32 then
        OBFTest.warn("bit32 không available")
        return
    end
    assert(bit32.band(0xFF, 0x0F) == 0x0F, "band")
    assert(bit32.bor(0xF0, 0x0F)  == 0xFF, "bor")
    assert(bit32.bxor(0xFF, 0x0F) == 0xF0, "bxor")
    assert(bit32.lshift(1, 4)     == 16,   "lshift")
    assert(bit32.rshift(16, 4)    == 1,    "rshift")
    assert(bit32.bnot(0) == 0xFFFFFFFF,    "bnot(0)")
end)

-- ─── GROUP: TABLE ───────────────────────────────────────────

OBFTest.addTest("Array cơ bản (#, index)", "TABLE", function()
    local t = {10, 20, 30, 40, 50}
    assert(#t   == 5,  "length")
    assert(t[1] == 10, "t[1]")
    assert(t[3] == 30, "t[3]")
    assert(t[5] == 50, "t[5]")
end)

OBFTest.addTest("Dictionary (string key)", "TABLE", function()
    local t = {name = "test", value = 42, flag = true}
    assert(t.name  == "test", "name")
    assert(t.value == 42,     "value")
    assert(t.flag  == true,   "flag")
end)

OBFTest.addTest("Nested table access", "TABLE", function()
    local t = {a = {b = {c = "deep"}}}
    assert(t.a.b.c == "deep", "Nested access sai")
end)

OBFTest.addTest("table.insert / table.remove", "TABLE", function()
    local t = {1, 2, 3}
    table.insert(t, 4)
    assert(#t == 4 and t[4] == 4, "insert sai")
    table.remove(t, 1)
    assert(#t == 3 and t[1] == 2, "remove sai")
end)

OBFTest.addTest("table.insert tại vị trí cụ thể", "TABLE", function()
    local t = {1, 2, 3}
    table.insert(t, 2, 99)
    assert(t[2] == 99 and t[3] == 2 and #t == 4, "insert at pos sai")
end)

OBFTest.addTest("table.sort", "TABLE", function()
    local t = {5, 3, 1, 4, 2}
    table.sort(t)
    assert(t[1]==1 and t[3]==3 and t[5]==5, "sort sai")
end)

OBFTest.addTest("table.sort với custom comparator", "TABLE", function()
    local t = {5, 3, 1, 4, 2}
    table.sort(t, function(a, b) return a > b end)  -- descending
    assert(t[1]==5 and t[3]==3 and t[5]==1, "sort custom sai")
end)

OBFTest.addTest("table.concat", "TABLE", function()
    local t = {"a", "b", "c", "d"}
    assert(table.concat(t, "-") == "a-b-c-d", "concat sai")
end)

OBFTest.addTest("table.concat với range", "TABLE", function()
    local t = {"a", "b", "c", "d", "e"}
    assert(table.concat(t, ",", 2, 4) == "b,c,d", "concat range sai")
end)

OBFTest.addTest("ipairs iteration toàn bộ array", "TABLE", function()
    local t = {10, 20, 30}
    local sum = 0
    for _, v in ipairs(t) do sum = sum + v end
    assert(sum == 60, "ipairs sum sai: " .. sum)
end)

OBFTest.addTest("pairs iteration dict", "TABLE", function()
    local t = {x=1, y=2, z=3}
    local count = 0
    for _ in pairs(t) do count = count + 1 end
    assert(count == 3, "pairs count sai: " .. count)
end)

OBFTest.addTest("next() để duyệt table thủ công", "TABLE", function()
    local t = {a=1, b=2}
    local count = 0
    local k = nil
    repeat
        k = next(t, k)
        if k ~= nil then count = count + 1 end
    until k == nil
    assert(count == 2, "next() count sai: " .. count)
end)

OBFTest.addTest("Table reuse (clear + refill)", "TABLE", function()
    local t = {1, 2, 3}
    for i = #t, 1, -1 do t[i] = nil end
    assert(#t == 0, "Clear sai: #t = " .. #t)
    for i = 1, 5 do t[i] = i * 2 end
    assert(#t == 5 and t[5] == 10, "Refill sai")
end)

OBFTest.addTest("rawequal để so sánh reference", "TABLE", function()
    local a = {}
    local b = a
    local c = {}
    assert(rawequal(a, b) == true,  "rawequal same ref sai")
    assert(rawequal(a, c) == false, "rawequal diff ref sai")
end)

-- ─── GROUP: FUNCTION ────────────────────────────────────────

OBFTest.addTest("Multiple return values", "FUNCTION", function()
    local function multi() return 1, "two", true end
    local a, b, c = multi()
    assert(a == 1 and b == "two" and c == true, "Multiple return sai")
end)

OBFTest.addTest("Multiple return truncation", "FUNCTION", function()
    local function multi() return 1, 2, 3 end
    local a = multi()  -- chỉ lấy 1 giá trị
    assert(a == 1, "Truncation sai: " .. tostring(a))
end)

OBFTest.addTest("Variadic function (...)", "FUNCTION", function()
    local function sum(...)
        local t, n = {...}, 0
        for _, v in ipairs(t) do n = n + v end
        return n
    end
    assert(sum(1,2,3,4,5) == 15, "Variadic sum sai")
end)

OBFTest.addTest("select('#', ...) count varargs", "FUNCTION", function()
    local function countArgs(...)
        return select('#', ...)
    end
    assert(countArgs(1, nil, 3) == 3, "select('#') sai với nil gaps")
end)

OBFTest.addTest("select(n, ...) get nth arg", "FUNCTION", function()
    local function getThird(...)
        return select(3, ...)
    end
    local v = getThird(10, 20, 30, 40)
    assert(v == 30, "select(3,...) sai: " .. tostring(v))
end)

OBFTest.addTest("Recursive function (Fibonacci 10)", "FUNCTION", function()
    local function fib(n)
        if n <= 1 then return n end
        return fib(n-1) + fib(n-2)
    end
    assert(fib(10) == 55, "Fib(10) sai: " .. tostring(fib(10)))
end)

OBFTest.addTest("Tail-call style (factorial)", "FUNCTION", function()
    local function fact(n, acc)
        acc = acc or 1
        if n <= 1 then return acc end
        return fact(n - 1, n * acc)
    end
    assert(fact(10) == 3628800, "Factorial sai: " .. tostring(fact(10)))
end)

OBFTest.addTest("First-class function / callback pattern", "FUNCTION", function()
    local function applyTwice(f, x) return f(f(x)) end
    local result = applyTwice(function(n) return n * 2 end, 3)
    assert(result == 12, "Callback sai: " .. tostring(result))
end)

OBFTest.addTest("Function as table value", "FUNCTION", function()
    local ops = {
        add = function(a, b) return a + b end,
        mul = function(a, b) return a * b end,
    }
    assert(ops.add(3, 4) == 7,  "ops.add sai")
    assert(ops.mul(3, 4) == 12, "ops.mul sai")
end)

OBFTest.addTest("Memoization pattern", "FUNCTION", function()
    local cache = {}
    local callCount = 0
    local function memoFib(n)
        if cache[n] then return cache[n] end
        callCount = callCount + 1
        local r = n <= 1 and n or memoFib(n-1) + memoFib(n-2)
        cache[n] = r
        return r
    end
    assert(memoFib(10) == 55, "Memo fib sai")
    assert(callCount <= 11,   "Memoization không hoạt động (callCount=" .. callCount .. ")")
end)

OBFTest.addTest("Mutual recursion A↔B", "FUNCTION", function()
    local isEven, isOdd
    isEven = function(n) return n == 0 or isOdd(n - 1) end
    isOdd  = function(n) return n ~= 0 and isEven(n - 1) end
    assert(isEven(4) == true,  "isEven(4) sai")
    assert(isOdd(5)  == true,  "isOdd(5) sai")
    assert(isEven(7) == false, "isEven(7) sai")
end)

-- ─── GROUP: METATABLES ──────────────────────────────────────

OBFTest.addTest("__index fallback table", "METATABLES", function()
    local defaults = {x = 0, y = 0}
    local obj = setmetatable({x = 5}, {__index = defaults})
    assert(obj.x == 5, "__index override sai")
    assert(obj.y == 0, "__index fallback sai")
end)

OBFTest.addTest("__index function", "METATABLES", function()
    local obj = setmetatable({}, {
        __index = function(_, k) return "key:" .. k end
    })
    assert(obj.foo == "key:foo", "__index fn sai")
end)

OBFTest.addTest("__newindex intercept", "METATABLES", function()
    local log = {}
    local t = setmetatable({}, {
        __newindex = function(tbl, k, v)
            log[k] = v
            rawset(tbl, k, v)
        end
    })
    t.foo = "bar"
    assert(log.foo == "bar", "__newindex không được gọi")
    assert(t.foo   == "bar", "rawset không work")
end)

OBFTest.addTest("__tostring metamethod", "METATABLES", function()
    local obj = setmetatable({}, {__tostring = function() return "MyObj" end})
    assert(tostring(obj) == "MyObj", "__tostring sai")
end)

OBFTest.addTest("__len metamethod (#obj)", "METATABLES", function()
    local obj
    if type(newproxy) == "function" then
        obj = newproxy(true)
        getmetatable(obj).__len = function() return 42 end
    else
        obj = setmetatable({}, {__len = function() return 42 end})
    end
    local success, res = pcall(function() return #obj end)
    if success then
        assert(res == 42, "__len sai: " .. tostring(res))
    end
end)

OBFTest.addTest("__add metamethod", "METATABLES", function()
    local mt = {__add = function(a, b) return {val = a.val + b.val} end}
    local a = setmetatable({val = 10}, mt)
    local b = setmetatable({val = 32}, mt)
    local c = a + b
    assert(c.val == 42, "__add sai: " .. tostring(c.val))
end)

OBFTest.addTest("__sub, __mul, __div metamethods", "METATABLES", function()
    local mt = {}
    mt.__sub = function(a, b) return setmetatable({v = a.v - b.v}, mt) end
    mt.__mul = function(a, b) return setmetatable({v = a.v * b.v}, mt) end
    mt.__div = function(a, b) return setmetatable({v = a.v / b.v}, mt) end

    local function N(x) return setmetatable({v = x}, mt) end
    assert((N(10) - N(3)).v == 7,  "__sub sai")
    assert((N(4)  * N(5)).v == 20, "__mul sai")
    assert((N(10) / N(2)).v == 5,  "__div sai")
end)

OBFTest.addTest("__eq metamethod", "METATABLES", function()
    local mt = {__eq = function(a, b) return a.v == b.v end}
    local a = setmetatable({v = 5}, mt)
    local b = setmetatable({v = 5}, mt)
    local c = setmetatable({v = 9}, mt)
    assert(a == b, "__eq true sai")
    assert(a ~= c, "__eq false sai")
end)

OBFTest.addTest("__lt và __le metamethods", "METATABLES", function()
    local mt = {}
    mt.__lt = function(a, b) return a.v < b.v end
    mt.__le = function(a, b) return a.v <= b.v end
    local function N(x) return setmetatable({v = x}, mt) end
    assert(N(1) <  N(2), "__lt sai")
    assert(N(2) <= N(2), "__le sai (equal)")
    assert(N(3) >  N(2), "__lt reverse sai")
end)

OBFTest.addTest("__concat metamethod", "METATABLES", function()
    local mt = {__concat = function(a, b)
        return setmetatable({v = tostring(a.v) .. tostring(b.v)}, mt)
    end}
    local a = setmetatable({v = "Hello"}, mt)
    local b = setmetatable({v = "World"}, mt)
    local c = a .. b
    assert(c.v == "HelloWorld", "__concat sai: " .. tostring(c.v))
end)

OBFTest.addTest("__call metamethod", "METATABLES", function()
    local callable = setmetatable({}, {
        __call = function(self, x, y) return x + y end
    })
    assert(callable(10, 20) == 30, "__call sai")
end)

OBFTest.addTest("rawget / rawset bypass metamethod", "METATABLES", function()
    local guarded = setmetatable({}, {
        __index    = function() return "meta" end,
        __newindex = function() error("blocked") end,
    })
    rawset(guarded, "k", "raw_val")
    assert(rawget(guarded, "k") == "raw_val", "rawget/rawset sai")
    -- __index không bị gọi khi key có trong table
    assert(guarded.k == "raw_val", "guarded[k] sau rawset sai")
end)

OBFTest.addTest("Prototype chain (OOP style)", "METATABLES", function()
    local Animal = {}; Animal.__index = Animal
    function Animal.new(name) return setmetatable({name=name}, Animal) end
    function Animal:speak() return self.name .. " speaks" end

    local Dog = setmetatable({}, {__index = Animal}); Dog.__index = Dog
    function Dog.new(name) return setmetatable(Animal.new(name), Dog) end
    function Dog:bark() return self.name .. " barks" end

    local d = Dog.new("Rex")
    assert(d:speak() == "Rex speaks", "inherited method sai")
    assert(d:bark()  == "Rex barks",  "own method sai")
end)

-- ─── GROUP: CONTROL ─────────────────────────────────────────

OBFTest.addTest("if / elseif / else chain", "CONTROL", function()
    local function classify(n)
        if     n > 0  then return "pos"
        elseif n < 0  then return "neg"
        else               return "zero"
        end
    end
    assert(classify(5)  == "pos",  "if pos sai")
    assert(classify(-3) == "neg",  "elseif neg sai")
    assert(classify(0)  == "zero", "else zero sai")
end)

OBFTest.addTest("while loop cơ bản", "CONTROL", function()
    local i, s = 1, 0
    while i <= 5 do s = s + i; i = i + 1 end
    assert(s == 15, "while sum sai: " .. s)
end)

OBFTest.addTest("repeat...until loop", "CONTROL", function()
    local i, s = 1, 0
    repeat s = s + i; i = i + 1 until i > 5
    assert(s == 15, "repeat sum sai: " .. s)
end)

OBFTest.addTest("numeric for loop", "CONTROL", function()
    local s = 0
    for i = 1, 10 do s = s + i end
    assert(s == 55, "for sum sai: " .. s)
end)

OBFTest.addTest("numeric for với step âm", "CONTROL", function()
    local s = 0
    for i = 10, 1, -1 do s = s + i end
    assert(s == 55, "for step-1 sum sai: " .. s)
end)

OBFTest.addTest("numeric for với step float", "CONTROL", function()
    local count = 0
    for i = 0, 1, 0.25 do count = count + 1 end
    assert(count == 5, "for float step count sai: " .. count)
end)

OBFTest.addTest("break trong loop", "CONTROL", function()
    local found = nil
    for i = 1, 100 do
        if i == 42 then found = i; break end
    end
    assert(found == 42, "break sai: " .. tostring(found))
end)

OBFTest.addTest("continue / skip even", "CONTROL", function()
    local sum = 0

    local loadFn = load or loadstring

    if loadFn then
        local code = [[
            local sum = 0

            for i = 1, 10 do
                if i % 2 == 0 then
                    continue
                end

                sum = sum + i
            end

            return sum
        ]]

        local fn, err = loadFn(code)

        if fn then
            local ok, result = pcall(fn)

            if ok then
                assert(result == 25, "continue sum sai: " .. tostring(result))
                return
            end
        end
    end

    -- Fallback nếu môi trường không hỗ trợ load/continue
    for i = 1, 10 do
        if i % 2 ~= 0 then
            sum = sum + i
        end
    end

    assert(sum == 25, "skip-even sum sai: " .. sum)
    OBFTest.warn("continue không available; dùng fallback manual")
end)
OBFTest.addTest("Nested loops với break chỉ thoát inner", "CONTROL", function()
    local outer_count = 0
    for i = 1, 3 do
        outer_count = outer_count + 1
        for j = 1, 10 do
            if j == 2 then break end
        end
    end
    assert(outer_count == 3, "nested break thoát outer loop sai")
end)

OBFTest.addTest("Short-circuit and/or", "CONTROL", function()
    local sideEffect = false
    local function boom() sideEffect = true; return true end

    -- false and boom() → không gọi boom
    local _ = false and boom()
    assert(sideEffect == false, "and short-circuit sai")

    -- true or boom() → không gọi boom
    local _ = true or boom()
    assert(sideEffect == false, "or short-circuit sai")
end)

OBFTest.addTest("Ternary idiom (cond and a or b)", "CONTROL", function()
    local function tern(c, a, b) return c and a or b end
    assert(tern(true,  "yes", "no") == "yes", "ternary true sai")
    assert(tern(false, "yes", "no") == "no",  "ternary false sai")
end)

-- ─── GROUP: TYPE ────────────────────────────────────────────

OBFTest.addTest("type() của tất cả types cơ bản", "TYPE", function()
    assert(type(nil)          == "nil",      "type nil")
    assert(type(true)         == "boolean",  "type bool")
    assert(type(42)           == "number",   "type int")
    assert(type(3.14)         == "number",   "type float")
    assert(type("hello")      == "string",   "type string")
    assert(type({})           == "table",    "type table")
    assert(type(print)        == "function", "type function")
    assert(type(coroutine.create(function()end)) == "thread", "type thread")
end)

OBFTest.addTest("Truthiness: only false và nil là falsy", "TYPE", function()
    local function truthy(v) return v and true or false end
    assert(truthy(0)     == true,  "0 phải truthy")
    assert(truthy("")    == true,  "empty string phải truthy")
    assert(truthy(false) == false, "false phải falsy")
    assert(truthy(nil)   == false, "nil phải falsy")
end)

OBFTest.addTest("Implicit coercion string→number trong arith", "TYPE", function()
    -- Lua thực hiện auto coerce string "5" + 3 = 8
    local ok, r = pcall(function() return "5" + 3 end)
    if ok then
        assert(r == 8, "coerce string+num sai: " .. tostring(r))
    else
        OBFTest.warn("String→number coerce bị disable (strict mode?)")
    end
end)

OBFTest.addTest("tostring + tonumber roundtrip", "TYPE", function()
    local n = 123456.789
    local s = tostring(n)
    local n2 = tonumber(s)
    assert(nearEq(n, n2, 1e-5), "roundtrip precision sai")
end)

OBFTest.addTest("rawlen() trên string và table", "TYPE", function()
    assert(rawlen("hello") == 5, "rawlen string sai")
    assert(rawlen({1,2,3}) == 3, "rawlen table sai")
end)

-- ─── GROUP: ENV ─────────────────────────────────────────────

OBFTest.addTest("_VERSION string tồn tại", "ENV", function()
    assert(type(_VERSION) == "string", "_VERSION không phải string")
    assert(#_VERSION > 0,              "_VERSION rỗng")
end)

OBFTest.addTest("_G chứa globals chuẩn", "ENV", function()
    assert(type(_G)          == "table",    "_G không phải table")
    assert(type(print)    == "function", "_G.print mất")
    assert(type(tostring) == "function", "_G.tostring mất")
    assert(type(pairs)    == "function", "_G.pairs mất")
    assert(type(type)     == "function", "_G.type mất")
end)

OBFTest.addTest("Standard libs tồn tại", "ENV", function()
    assert(type(math)    == "table", "math lib mất")
    assert(type(string)  == "table", "string lib mất")
    assert(type(table)   == "table", "table lib mất")
    assert(type(os)      == "table", "os lib mất")
    assert(type(coroutine) == "table","coroutine lib mất")
end)

OBFTest.addTest("os.clock() trả number > 0", "ENV", function()
    local t = os.clock()
    assert(type(t) == "number", "os.clock không trả number")
    assert(t >= 0,              "os.clock âm?")
end)

OBFTest.addTest("os.time() trả integer hợp lệ", "ENV", function()
    local t = os.time()
    assert(type(t) == "number",  "os.time không trả number")
    assert(t > 1000000000,       "os.time trả giá trị quá nhỏ (< 2001)")
end)

OBFTest.addTest("pcall + require (không crash nếu module missing)", "ENV", function()
    local ok, err = pcall(require, "__nonexistent_module_12345__")
    assert(ok == false,          "require missing module không fail")
    assert(type(err) == "string","require error không phải string")
end)

OBFTest.addTest("ipairs / pairs / next tồn tại", "ENV", function()
    assert(type(ipairs) == "function", "ipairs mất")
    assert(type(pairs)  == "function", "pairs mất")
    assert(type(next)   == "function", "next mất")
    assert(type(select) == "function", "select mất")
    assert(type(unpack or table.unpack) == "function", "unpack mất")
end)

OBFTest.addTest("table.unpack / unpack hoạt động", "ENV", function()
    local up = table.unpack or unpack
    assert(up ~= nil, "unpack/table.unpack không tồn tại")
    local a, b, c = up({10, 20, 30})
    assert(a==10 and b==20 and c==30, "unpack sai")
end)

OBFTest.addTest("table.unpack với range", "ENV", function()
    local up = table.unpack or unpack
    local b, c = up({10, 20, 30, 40}, 2, 3)
    assert(b==20 and c==30, "unpack range sai")
end)

-- ─── GROUP: UNC ─────────────────────────────────────────────

OBFTest.addTest("getgenv() trả table", "UNC", function()
    if not getgenv then
        OBFTest.warn("getgenv không available")
        return
    end
    assert(type(getgenv()) == "table", "getgenv không trả table")
end)

OBFTest.addTest("getrenv() trả table", "UNC", function()
    if not getrenv then
        OBFTest.warn("getrenv không available")
        return
    end
    assert(type(getrenv()) == "table", "getrenv không trả table")
end)

OBFTest.addTest("getrawmetatable bypass lockdown", "UNC", function()
    if not getrawmetatable then
        OBFTest.warn("getrawmetatable không available")
        return
    end
    local t  = setmetatable({}, {__index = function() end})
    local mt = getrawmetatable(t)
    assert(type(mt) == "table", "getrawmetatable không trả table")
end)

OBFTest.addTest("HTTP request function tồn tại", "UNC", function()
    local httpFn = (syn and syn.request) or http_request or request
    if not httpFn then
        OBFTest.warn("Không tìm thấy HTTP function")
        return
    end
    assert(type(httpFn) == "function", "HTTP fn không phải function")
end)

OBFTest.addTest("setreadonly / isreadonly (nếu có)", "UNC", function()
    if not setreadonly or not isreadonly then
        OBFTest.warn("setreadonly/isreadonly không available")
        return
    end
    local t = {}
    setreadonly(t, true)
    assert(isreadonly(t) == true, "setreadonly true sai")
    setreadonly(t, false)
    assert(isreadonly(t) == false, "setreadonly false sai")
end)

OBFTest.addTest("clonefunction (nếu có)", "UNC", function()
    if not clonefunction then
        OBFTest.warn("clonefunction không available")
        return
    end
    local function original(x) return x * 2 end
    local cloned = clonefunction(original)
    assert(type(cloned) == "function", "clonefunction không trả function")
    assert(cloned(5) == 10,            "cloned function kết quả sai")
    assert(cloned ~= original,         "clone phải là object khác")
end)

OBFTest.addTest("hookfunction / hookmetamethod (presence check)", "UNC", function()
    local hasHook = (type(hookfunction) == "function")
                 or (type(hookmetamethod) == "function")
    if not hasHook then
        OBFTest.warn("hookfunction/hookmetamethod không available")
    end
    -- Chỉ kiểm tra tồn tại, không thực sự hook để tránh side effect
end)


-- ============================================================
-- v4.0 EXTENDED COVERAGE
-- Syntax / opcode-pattern / Roblox API / Function / Benchmark
-- ============================================================

local function getLoadFn()
    return loadstring or load
end

local function syntaxCompile(source)
    local loadFn = getLoadFn()
    if not loadFn then
        return nil, "load/loadstring không available"
    end
    local fn, err = loadFn(source)
    if fn == nil then
        return false, tostring(err)
    end
    return true, fn
end

local function benchmark(fn, iterations)
    local t0 = os.clock()
    local ok, err = pcall(function()
        for i = 1, iterations do
            fn(i)
        end
    end)
    local elapsed = os.clock() - t0
    return ok, elapsed, err
end

local function showBench(label, fn, iterations)
    local ok, elapsed, err = benchmark(fn, iterations)
    assert(ok, tostring(err))
    local us = elapsed * 1000000 / iterations
    local ops = iterations / math.max(elapsed, 1e-12)
    print(string.format(
        "  ⚡ BENCH %-32s | %d ops | %.3f ms | %.2f us/op | %.0f ops/s",
        label, iterations, elapsed * 1000, us, ops
    ))
end

-- ─── GROUP: SYNTAX ────────────────────────────────────────────

OBFTest.addTest("Syntax: local + multi assignment", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local a, b, c = 1, "x", true
        assert(a == 1 and b == "x" and c == true)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: if / elseif / else", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local x = 2
        if x == 1 then
            x = 10
        elseif x == 2 then
            x = 20
        else
            x = 30
        end
        assert(x == 20)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: while + break", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local i, s = 0, 0
        while true do
            i += 1
            s += i
            if i >= 5 then break end
        end
        assert(s == 15)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: repeat...until", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local i = 0
        repeat
            i += 1
        until i == 5
        assert(i == 5)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: numeric for", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local s = 0
        for i = 1, 10, 2 do
            s += i
        end
        assert(s == 25)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: generic for i,v in ipairs", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local s = 0
        for i, v in ipairs({1, 2, 3, 4}) do
            s += i + v
        end
        assert(s == 20)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: generic for k,v in pairs", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local t = {a = 1, b = 2}
        local s = 0
        for k, v in pairs(t) do
            s += v
        end
        assert(s == 3)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: continue", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local s = 0
        for i = 1, 10 do
            if i % 2 == 0 then
                continue
            end
            s += i
        end
        assert(s == 25)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: local function + SubFunction", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local function Function(x)
            local function SubFunction(y)
                return x + y
            end
            return SubFunction(x)
        end
        assert(Function(3) == 6)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: method declaration ':'", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local T = {}
        function T:Add(a, b)
            return self.value + a + b
        end
        local obj = setmetatable({value = 10}, {__index = T})
        assert(obj:Add(1, 2) == 13)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: vararg ... + select", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local function F(...)
            return select("#", ...)
        end
        assert(F(1, nil, 3, false) == 4)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: table constructor + computed key", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local k = "answer"
        local t = {
            [k] = 42,
            nested = {1, 2, 3},
            fn = function(x) return x * 2 end
        }
        assert(t.answer == 42 and t.nested[2] == 2 and t.fn(4) == 8)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: Luau compound assignment", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local x = 10
        x += 5
        x -= 2
        x *= 3
        x /= 13
        assert(x == 3)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: floor division //", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local x = 10 // 3
        assert(x == 3)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

OBFTest.addTest("Syntax: pcall / xpcall", "SYNTAX", function()
    local ok, err = syntaxCompile([[
        local a = pcall(function() error("x") end)
        local b = xpcall(function() error("y") end, function(e) return e end)
        assert(a == false and b == false)
    ]])
    if ok == nil then OBFTest.warn(err); return end
    assert(ok, err)
end)

-- ─── GROUP: OPCODE ────────────────────────────────────────────
-- Đây là opcode-pattern coverage, không phải opcode dumper.
-- Nó kích hoạt các nhóm hành vi thường tương ứng với LOAD/MOVE/
-- GET/SET/CALL/RETURN/JUMP/LOOP/CLOSURE/NAMECALL trong VM.

OBFTest.addTest("Opcode-pattern: constants / LOAD-like", "OPCODE", function()
    local a = nil
    local b = true
    local c = false
    local d = 123456
    local e = 3.25
    local f = "opcode"
    assert(a == nil and b and not c and d == 123456 and e == 3.25 and f == "opcode")
end)

OBFTest.addTest("Opcode-pattern: MOVE-like copies", "OPCODE", function()
    local a = 10
    local b = a
    local c = b
    local d = c
    assert(d == 10)
end)

OBFTest.addTest("Opcode-pattern: GETTABLE / SETTABLE-like", "OPCODE", function()
    local t = {}
    t["a"] = 10
    t.b = 20
    t[1] = 30
    assert(t.a == 10 and t.b == 20 and t[1] == 30)
end)

OBFTest.addTest("Opcode-pattern: nested GETTABLE chain", "OPCODE", function()
    local t = {a = {b = {c = {value = 99}}}}
    assert(t.a.b.c.value == 99)
end)

OBFTest.addTest("Opcode-pattern: indexed read/write expressions", "OPCODE", function()
    local t = {}
    local key = "x"
    local base = 40
    t[key] = base + 2
    t[key .. "2"] = t[key] * 2
    assert(t.x == 42 and t.x2 == 84)
end)

OBFTest.addTest("Opcode-pattern: CALL + multi-return", "OPCODE", function()
    local function f(a, b, c)
        return a + b, c * 2
    end
    local x, y = f(10, 20, 3)
    assert(x == 30 and y == 6)
end)

OBFTest.addTest("Opcode-pattern: NAMECALL-like method call", "OPCODE", function()
    local T = {}
    function T:Add(x)
        return self.value + x
    end
    local obj = setmetatable({value = 7}, {__index = T})
    assert(obj:Add(5) == 12)
end)

OBFTest.addTest("Opcode-pattern: conditional jump chain", "OPCODE", function()
    local x = 8
    local r
    if x > 10 then
        r = 1
    elseif x == 8 then
        r = 2
    else
        r = 3
    end
    assert(r == 2)
end)

OBFTest.addTest("Opcode-pattern: short-circuit boolean", "OPCODE", function()
    local hit = 0
    local function inc()
        hit += 1
        return true
    end
    local a = false and inc()
    local b = true or inc()
    local c = true and inc()
    assert(hit == 1)
    assert(a == false and b == true and c == true)
end)

OBFTest.addTest("Opcode-pattern: numeric FOR", "OPCODE", function()
    local s = 0
    for i = 1, 100 do s += i end
    assert(s == 5050)
end)

OBFTest.addTest("Opcode-pattern: generic FOR i,v", "OPCODE", function()
    local t = {1, 2, 3, 4}
    local s = 0
    for i, v in ipairs(t) do s += i * v end
    assert(s == 30)
end)

OBFTest.addTest("Opcode-pattern: closure / upvalue", "OPCODE", function()
    local x = 10
    local function SubFunction(y)
        x += y
        return x
    end
    assert(SubFunction(5) == 15)
    assert(SubFunction(2) == 17)
end)

OBFTest.addTest("Opcode-pattern: recursive CALL", "OPCODE", function()
    local function fact(n)
        if n <= 1 then return 1 end
        return n * fact(n - 1)
    end
    assert(fact(8) == 40320)
end)

OBFTest.addTest("Opcode-pattern: vararg forwarding", "OPCODE", function()
    local function count(...) return select("#", ...) end
    local function forward(...) return count(...) end
    assert(forward(1, nil, 3, false) == 4)
end)

OBFTest.addTest("Opcode-pattern: metamethod arithmetic", "OPCODE", function()
    local mt = {
        __add = function(a, b) return a.v + b.v end,
        __mul = function(a, b) return a.v * b.v end
    }
    local a = setmetatable({v = 6}, mt)
    local b = setmetatable({v = 7}, mt)
    assert(a + b == 13)
    assert(a * b == 42)
end)

OBFTest.addTest("Opcode-pattern: concat / length / unary", "OPCODE", function()
    local s = "ab" .. "cd"
    local t = {1, 2, 3}
    assert(s == "abcd" and #s == 4 and #t == 3 and -10 == -10)
end)

-- ─── ROBLOX SIMULATION LAYER ──────────────────────────────────
-- Giả lập tối thiểu game / workspace / Instance khi test bằng
-- interpreter Lua thường (lua5.1/5.4/LuaJIT) thay vì Roblox thật.
-- Nếu game đã tồn tại sẵn (đang chạy trong Roblox) thì bỏ qua
-- toàn bộ khối này — các API thật sẽ được dùng thay thế.
if game == nil then
    local FakeInstance = {}
    FakeInstance.__index = FakeInstance

    function FakeInstance.new(className, name)
        local self = setmetatable({}, FakeInstance)
        self.ClassName = className
        self.Name      = name or className
        self.Parent    = nil
        self._children = {}
        return self
    end

    function FakeInstance:AddChild(child)
        child.Parent = self
        table.insert(self._children, child)
        return child
    end

    function FakeInstance:FindFirstChild(name, recursive)
        for _, c in ipairs(self._children) do
            if c.Name == name then return c end
        end
        if recursive then
            for _, c in ipairs(self._children) do
                local found = c:FindFirstChild(name, true)
                if found then return found end
            end
        end
        return nil
    end

    function FakeInstance:FindFirstChildOfClass(className)
        for _, c in ipairs(self._children) do
            if c.ClassName == className then return c end
        end
        return nil
    end

    function FakeInstance:WaitForChild(name)
        return self:FindFirstChild(name)
    end

    function FakeInstance:GetChildren()
        local copy = {}
        for i, c in ipairs(self._children) do copy[i] = c end
        return copy
    end

    function FakeInstance:IsA(className)
        return self.ClassName == className
    end

    local fakeGame  = FakeInstance.new("DataModel", "game")
    local _services = {}

    function fakeGame:GetService(serviceName)
        if not _services[serviceName] then
            _services[serviceName] = self:AddChild(FakeInstance.new(serviceName, serviceName))
        end
        return _services[serviceName]
    end

    game      = fakeGame
    workspace = game:GetService("Workspace")
end

-- ─── GROUP: ROBLOX ────────────────────────────────────────────

OBFTest.addTest("Roblox: game exists", "ROBLOX", function()
    if game == nil then
        OBFTest.warn("game không available trong môi trường hiện tại")
        return
    end
    assert(game ~= nil)
end)

OBFTest.addTest("Roblox: game:GetService('Players')", "ROBLOX", function()
    if not game or type(game.GetService) ~= "function" then
        OBFTest.warn("game:GetService không available")
        return
    end
    local ok, service = pcall(function()
        return game:GetService("Players")
    end)
    assert(ok, "GetService lỗi: " .. tostring(service))
    assert(service ~= nil, "Players service == nil")
end)

OBFTest.addTest("Roblox: game:GetService('Workspace')", "ROBLOX", function()
    if not game or type(game.GetService) ~= "function" then
        OBFTest.warn("game:GetService không available")
        return
    end
    local ok, service = pcall(function()
        return game:GetService("Workspace")
    end)
    assert(ok and service ~= nil, "Workspace service lỗi")
end)

OBFTest.addTest("Roblox: game:FindFirstChild('Workspace')", "ROBLOX", function()
    if not game or type(game.FindFirstChild) ~= "function" then
        OBFTest.warn("game:FindFirstChild không available")
        return
    end
    local ok, result = pcall(function()
        return game:FindFirstChild("Workspace")
    end)
    assert(ok, "FindFirstChild lỗi: " .. tostring(result))
    assert(result ~= nil, "Không tìm thấy Workspace")
end)

OBFTest.addTest("Roblox: game:FindFirstChild(missing) -> nil", "ROBLOX", function()
    if not game or type(game.FindFirstChild) ~= "function" then
        OBFTest.warn("game:FindFirstChild không available")
        return
    end
    local ok, result = pcall(function()
        return game:FindFirstChild("__OBF_TEST_MISSING__")
    end)
    assert(ok, "FindFirstChild missing lỗi")
    assert(result == nil, "FindFirstChild missing không trả nil")
end)

OBFTest.addTest("Roblox: GetService -> FindFirstChild chain", "ROBLOX", function()
    if not game or type(game.GetService) ~= "function" then
        OBFTest.warn("game:GetService không available")
        return
    end
    local ok = pcall(function()
        local Players = game:GetService("Players")
        if Players and type(Players.FindFirstChild) == "function" then
            Players:FindFirstChild("__OBF_TEST_MISSING__")
        end
    end)
    assert(ok, "method chain lỗi")
end)

OBFTest.addTest("Roblox: workspace identity", "ROBLOX", function()
    if not game or type(game.GetService) ~= "function" or workspace == nil then
        OBFTest.warn("game/workspace không available")
        return
    end
    local ok, ws = pcall(function() return game:GetService("Workspace") end)
    assert(ok and ws == workspace, "Workspace identity mismatch")
end)

OBFTest.addTest("Roblox: FindFirstChild recursive argument", "ROBLOX", function()
    if not workspace or type(workspace.FindFirstChild) ~= "function" then
        OBFTest.warn("workspace:FindFirstChild không available")
        return
    end
    local ok, result = pcall(function()
        return workspace:FindFirstChild("__OBF_TEST_MISSING__", true)
    end)
    assert(ok, "FindFirstChild recursive call lỗi")
    assert(result == nil, "Unexpected object")
end)

OBFTest.addTest("Roblox: GetChildren sau nhiều GetService", "ROBLOX", function()
    if not game or type(game.GetService) ~= "function" or type(game.GetChildren) ~= "function" then
        OBFTest.warn("game:GetChildren không available")
        return
    end
    game:GetService("Lighting")
    game:GetService("ReplicatedStorage")
    local ok, children = pcall(function() return game:GetChildren() end)
    assert(ok, "GetChildren lỗi: " .. tostring(children))
    assert(type(children) == "table", "GetChildren không trả table")
end)

OBFTest.addTest("Roblox: IsA kiểm tra ClassName", "ROBLOX", function()
    if not workspace or type(workspace.IsA) ~= "function" then
        OBFTest.warn("workspace:IsA không available")
        return
    end
    local ok, isWs = pcall(function() return workspace:IsA("Workspace") end)
    assert(ok, "IsA lỗi: " .. tostring(isWs))
    assert(isWs == true, "workspace:IsA('Workspace') phải true")
end)

OBFTest.addTest("Roblox: FindFirstChildOfClass trên game", "ROBLOX", function()
    if not game or type(game.FindFirstChildOfClass) ~= "function" then
        OBFTest.warn("game:FindFirstChildOfClass không available")
        return
    end
    game:GetService("SoundService")
    local ok, svc = pcall(function() return game:FindFirstChildOfClass("SoundService") end)
    assert(ok, "FindFirstChildOfClass lỗi: " .. tostring(svc))
    assert(svc ~= nil, "Không tìm thấy service theo class")
end)

OBFTest.addTest("Roblox: method chain dài (GetService -> FindFirstChild -> GetChildren)", "ROBLOX", function()
    if not game or type(game.GetService) ~= "function" then
        OBFTest.warn("game:GetService không available")
        return
    end
    local ok = pcall(function()
        local svc = game:GetService("Workspace")
        svc:FindFirstChild("__OBF_TEST_MISSING__")
        local ws = game:GetService("Workspace")
        return ws:GetChildren()
    end)
    assert(ok, "Method chain dài bị lỗi")
end)

-- ─── GROUP: TABFUNC ─────────────────────────────────────────
-- Test các pattern "function nằm trong table" / function nhận và
-- trả vararg (...) — dạng code hay bị obfuscator bẻ gãy khi che
-- giấu tên hàm, ví dụ: tabfunc.create = function(...) ... end
-- hoặc named function(...) return ... end.

OBFTest.addTest("Tabfunc: named function(...) return ...", "TABFUNC", function()
    local function tabfunction(...)
        return ...
    end
    local a, b, c = tabfunction(7, 8, 9)
    assert(a == 7 and b == 8 and c == 9, "tabfunction(...) sai: " .. tostring(a))
end)

OBFTest.addTest("Tabfunc: tabfunc.create = function(...) return ...", "TABFUNC", function()
    local tabfunc = {}
    tabfunc.create = function(...)
        return ...
    end
    local a, b, c = tabfunc.create(1, 2, 3)
    assert(a == 1 and b == 2 and c == 3, "tabfunc.create vararg sai")
end)

OBFTest.addTest("Tabfunc: global _G.fn(...) return ...", "TABFUNC", function()
    function _G.__obf_tabfunction(...)
        return ...
    end
    local a, b = _G.__obf_tabfunction(10, 20)
    assert(a == 10 and b == 20, "global _G function vararg sai")
    _G.__obf_tabfunction = nil
end)

OBFTest.addTest("Tabfunc: table.create-like factory", "TABFUNC", function()
    local tabfunc = {}
    tabfunc.create = function(n, value)
        local t = {}
        for i = 1, n do t[i] = value end
        return t
    end
    local t = tabfunc.create(5, "x")
    assert(#t == 5 and t[3] == "x", "tabfunc.create factory sai")
end)

OBFTest.addTest("Tabfunc: table lồng table.func chain", "TABFUNC", function()
    local tabfunc = {}
    tabfunc.sub = {}
    tabfunc.sub.create = function(...)
        return select("#", ...)
    end
    assert(tabfunc.sub.create(1, 2, 3, 4) == 4, "nested tabfunc chain sai")
end)

OBFTest.addTest("Tabfunc: colon-call self binding + vararg", "TABFUNC", function()
    local tabfunc = {}
    function tabfunc:create(...)
        return self, select("#", ...)
    end
    local selfRef, n = tabfunc:create(1, 2, 3)
    assert(selfRef == tabfunc, "colon self binding sai")
    assert(n == 3, "colon vararg count sai: " .. n)
end)

OBFTest.addTest("Tabfunc: get/set factory (multi-return function)", "TABFUNC", function()
    local tabfunc = {}
    tabfunc.create = function()
        local value = 0
        local function get() return value end
        local function set(v) value = v end
        return get, set
    end
    local get, set = tabfunc.create()
    set(99)
    assert(get() == 99, "get/set factory sai")
end)

OBFTest.addTest("Tabfunc: OOP module pattern (giống Roblox ModuleScript)", "TABFUNC", function()
    local tabfunc = {}
    tabfunc.__index = tabfunc

    function tabfunc.new(name)
        local self = setmetatable({}, tabfunc)
        self.Name = name
        return self
    end

    function tabfunc:GetName(...)
        return self.Name, ...
    end

    local obj = tabfunc.new("Test")
    local name, extra = obj:GetName("extra")
    assert(name == "Test" and extra == "extra", "OOP module pattern sai")
end)

OBFTest.addTest("Tabfunc: recursive tabfunc.create gọi lại chính nó", "TABFUNC", function()
    local tabfunc = {}
    tabfunc.create = function(n)
        if n <= 0 then return 0 end
        return n + tabfunc.create(n - 1)
    end
    local result = tabfunc.create(5)
    assert(result == 15, "recursive tabfunc.create sai: " .. result)
end)

-- ─── GROUP: FUNCTION EXTENSIONS ───────────────────────────────

OBFTest.addTest("Function: named Function", "FUNCTION", function()
    local function Function(x, y)
        return x + y
    end
    assert(Function(2, 3) == 5)
end)

OBFTest.addTest("Function: Function -> SubFunction", "FUNCTION", function()
    local function Function(x)
        local function SubFunction(y)
            return x * y
        end
        return SubFunction(4)
    end
    assert(Function(5) == 20)
end)

OBFTest.addTest("Function: multiple nested SubFunctions", "FUNCTION", function()
    local function Function(x)
        local function Sub1(y)
            local function Sub2(z)
                return x + y + z
            end
            return Sub2(3)
        end
        return Sub1(2)
    end
    assert(Function(1) == 6)
end)

OBFTest.addTest("Function: function stored then called", "FUNCTION", function()
    local Function = function(x) return x * 10 end
    local SubFunction = Function
    assert(SubFunction(7) == 70)
end)

OBFTest.addTest("Function: method + self + SubFunction", "FUNCTION", function()
    local T = {}
    function T:Run(x)
        local function SubFunction(y)
            return self.base + y
        end
        return SubFunction(x)
    end
    local obj = setmetatable({base = 9}, {__index = T})
    assert(obj:Run(3) == 12)
end)

-- ─── GROUP: BENCHMARK ─────────────────────────────────────────

OBFTest.addTest("Benchmark: empty loop", "BENCHMARK", function()
    showBench("empty", function() end, 2000)
end)

OBFTest.addTest("Benchmark: arithmetic", "BENCHMARK", function()
    local x = 0
    showBench("arithmetic", function(i)
        x = (x + i) * 1.000001 - i
    end, 2000)
    assert(type(x) == "number")
end)

OBFTest.addTest("Benchmark: local Function call", "BENCHMARK", function()
    local function Function(x) return x + 1 end
    local sink = 0
    showBench("local call", function(i)
        sink += Function(i)
    end, 2000)
    assert(sink > 0)
end)

OBFTest.addTest("Benchmark: table read/write", "BENCHMARK", function()
    local t = {}
    showBench("table rw", function(i)
        local k = i % 128
        t[k] = i
        local _ = t[k]
    end, 2000)
    assert(type(t) == "table")
end)

OBFTest.addTest("Benchmark: nested Function/SubFunction", "BENCHMARK", function()
    local function Function(x)
        local function SubFunction(y)
            return x + y
        end
        return SubFunction(x)
    end
    local sink = 0
    showBench("nested function", function(i)
        sink += Function(i)
    end, 2000)
    assert(sink > 0)
end)

OBFTest.addTest("Benchmark: numeric for", "BENCHMARK", function()
    local sum = 0
    local t0 = os.clock()
    for _ = 1, 20 do
        sum = 0
        for i = 1, 100 do
            sum += i
        end
    end
    local elapsed = (os.clock() - t0) * 1000
    print(string.format("  ⚡ BENCH %-32s | 2000 iter | %.3f ms | sum=%d",
        "numeric for", elapsed, sum))
    assert(sum == 5050)
end)

OBFTest.addTest("Benchmark: generic for i,v", "BENCHMARK", function()
    local t = {}
    for i = 1, 100 do t[i] = i end
    local sum = 0
    local t0 = os.clock()
    for _ = 1, 20 do
        sum = 0
        for i, v in ipairs(t) do
            sum += i + v
        end
    end
    local elapsed = (os.clock() - t0) * 1000
    print(string.format("  ⚡ BENCH %-32s | 2000 iter | %.3f ms | sum=%d",
        "generic for i,v", elapsed, sum))
    assert(sum == 10100)
end)

OBFTest.addTest("Benchmark: game:GetService('Players')", "BENCHMARK", function()
    if not game or type(game.GetService) ~= "function" then
        OBFTest.warn("game:GetService không available")
        return
    end
    local count = 1000
    local t0 = os.clock()
    for _ = 1, count do
        assert(game:GetService("Players") ~= nil)
    end
    local elapsed = (os.clock() - t0) * 1000
    print(string.format(
        "  ⚡ BENCH %-32s | %d calls | %.3f ms | %.2f us/call",
        "GetService(Players)", count, elapsed, elapsed * 1000 / count
    ))
end)

OBFTest.addTest("Benchmark: workspace:FindFirstChild()", "BENCHMARK", function()
    if not workspace or type(workspace.FindFirstChild) ~= "function" then
        OBFTest.warn("workspace:FindFirstChild không available")
        return
    end
    local count = 1000
    local t0 = os.clock()
    for _ = 1, count do
        assert(workspace:FindFirstChild("__OBF_TEST_MISSING__") == nil)
    end
    local elapsed = (os.clock() - t0) * 1000
    print(string.format(
        "  ⚡ BENCH %-32s | %d calls | %.3f ms | %.2f us/call",
        "FindFirstChild(missing)", count, elapsed, elapsed * 1000 / count
    ))
end)


-- ============================================================
-- v5.0 NEW GROUPS: CLOSURE, ITERATOR
-- ============================================================

-- ─── GROUP: CLOSURE ──────────────────────────────────────────

OBFTest.addTest("Closure: capture biến loop đúng (common pitfall)", "CLOSURE", function()
    local funcs = {}
    for i = 1, 5 do
        local captured = i          -- capture đúng bằng local copy
        funcs[i] = function() return captured end
    end
    for i = 1, 5 do
        assert(funcs[i]() == i, "Loop closure capture sai tại i=" .. i)
    end
end)

OBFTest.addTest("Closure: shared upvalue qua nhiều closure", "CLOSURE", function()
    local function makeShared()
        local val = 0
        local function inc(n) val = val + (n or 1) end
        local function dec(n) val = val - (n or 1) end
        local function get()  return val end
        return inc, dec, get
    end
    local inc, dec, get = makeShared()
    inc(10); inc(5); dec(3)
    assert(get() == 12, "Shared upvalue sai: " .. tostring(get()))
end)

OBFTest.addTest("Closure: upvalue chain 4 tầng", "CLOSURE", function()
    local x = 1
    local function L1()
        local function L2()
            local function L3()
                local function L4()
                    x = x * 2
                end
                L4()
            end
            L3()
        end
        L2()
    end
    L1(); L1(); L1()
    assert(x == 8, "Upvalue 4-level sai: x=" .. tostring(x))
end)

OBFTest.addTest("Closure: table upvalue mutation an toàn", "CLOSURE", function()
    local function makeStore()
        local data = {}
        return {
            set = function(k, v) data[k] = v end,
            get = function(k)    return data[k] end,
            all = function()     return data end,
        }
    end
    local store = makeStore()
    store.set("name", "Tranthien")
    store.set("score", 100)
    assert(store.get("name")  == "Tranthien", "Closure store name sai")
    assert(store.get("score") == 100,         "Closure store score sai")
    assert(type(store.all()) == "table",      "Closure store all sai")
end)

OBFTest.addTest("Closure: generator pattern (stateful)", "CLOSURE", function()
    local function range(from, to, step)
        step = step or 1
        local cur = from - step
        return function()
            cur = cur + step
            if cur <= to then return cur end
        end
    end
    local result = {}
    for v in range(1, 5) do result[#result+1] = v end
    assert(#result == 5, "Range generator count sai: " .. #result)
    assert(result[3] == 3, "Range generator value sai")
end)

OBFTest.addTest("Closure: once-pattern (chỉ thực thi một lần)", "CLOSURE", function()
    local function once(fn)
        local done, val = false, nil
        return function(...)
            if not done then done = true; val = fn(...) end
            return val
        end
    end
    local calls = 0
    local init = once(function(x)
        calls = calls + 1
        return x * 10
    end)
    assert(init(5) == 50, "once() lần 1 sai")
    assert(init(9) == 50, "once() lần 2 không trả cache")
    assert(calls == 1,    "once() gọi fn nhiều lần: " .. calls)
end)

OBFTest.addTest("Closure: memoize với closure cache", "CLOSURE", function()
    local function memoize(fn)
        local cache = {}
        return function(k)
            if cache[k] == nil then
                cache[k] = fn(k)
            end
            return cache[k]
        end
    end
    local computed = 0
    local fib = memoize(function(n)
        computed = computed + 1
        if n <= 1 then return n end
        -- simplified (không recursive để test memoize isolation)
        return n * (n - 1) / 2
    end)
    fib(10); fib(10); fib(5); fib(10)
    assert(computed == 2, "Memoize gọi quá nhiều: " .. computed)
end)

OBFTest.addTest("Closure: independent closures không share upvalue", "CLOSURE", function()
    local function makeCounter(start)
        local n = start
        return function() n = n + 1; return n end
    end
    local c1 = makeCounter(0)
    local c2 = makeCounter(100)
    c1(); c1()
    c2()
    assert(c1() == 3,   "Counter c1 sai: " .. tostring(c1()))
    assert(c2() == 102, "Counter c2 sai: " .. tostring(c2()))
end)

OBFTest.addTest("Closure: partial application", "CLOSURE", function()
    local function partial(fn, ...)
        local outerArgs = {...}
        return function(...)
            local args = {}
            for _, v in ipairs(outerArgs) do args[#args+1] = v end
            for _, v in ipairs({...})      do args[#args+1] = v end
            local _unp = table.unpack or unpack
            return fn(_unp(args))
        end
    end
    local function add3(a, b, c) return a + b + c end
    local addTo10 = partial(add3, 10)
    assert(addTo10(5, 3) == 18, "Partial application sai: " .. tostring(addTo10(5, 3)))
end)

-- ─── GROUP: ITERATOR ─────────────────────────────────────────

OBFTest.addTest("Iterator: custom stateless (ipairs-like)", "ITERATOR", function()
    local function myIter(t, i)
        i = i + 1
        local v = t[i]
        if v ~= nil then return i, v end
    end
    local t = {10, 20, 30, 40}
    local sum = 0
    for i, v in myIter, t, 0 do
        sum = sum + v
    end
    assert(sum == 100, "Stateless iterator sum sai: " .. sum)
end)

OBFTest.addTest("Iterator: stateful closure iterator", "ITERATOR", function()
    local function values(t)
        local i = 0
        return function()
            i = i + 1
            return t[i]
        end
    end
    local result = {}
    for v in values({5, 10, 15}) do
        result[#result+1] = v
    end
    assert(#result == 3 and result[2] == 10, "Stateful iterator sai")
end)

OBFTest.addTest("Iterator: filter combinator", "ITERATOR", function()
    local function filter(iter, pred)
        return function()
            while true do
                local v = iter()
                if v == nil then return nil end
                if pred(v)  then return v   end
            end
        end
    end
    local function fromTable(t)
        local i = 0
        return function() i = i + 1; return t[i] end
    end
    local evens = filter(fromTable({1,2,3,4,5,6}), function(n) return n % 2 == 0 end)
    local r = {}
    for v in evens do r[#r+1] = v end
    assert(#r == 3 and r[1] == 2 and r[3] == 6, "Filter iterator sai")
end)

OBFTest.addTest("Iterator: map combinator", "ITERATOR", function()
    local function map(iter, fn)
        return function()
            local v = iter()
            if v == nil then return nil end
            return fn(v)
        end
    end
    local function fromTable(t)
        local i = 0
        return function() i = i + 1; return t[i] end
    end
    local squares = map(fromTable({1,2,3,4}), function(n) return n * n end)
    local r = {}
    for v in squares do r[#r+1] = v end
    assert(#r == 4 and r[4] == 16, "Map iterator sai: r[4]=" .. tostring(r[4]))
end)

OBFTest.addTest("Iterator: Fibonacci vô hạn (lấy 8 phần tử)", "ITERATOR", function()
    local function fibs()
        local a, b = 0, 1
        return function()
            local v = a
            a, b = b, a + b
            return v
        end
    end
    local iter = fibs()
    local r = {}
    for _ = 1, 8 do r[#r+1] = iter() end
    -- 0,1,1,2,3,5,8,13
    assert(r[1] == 0 and r[6] == 5 and r[8] == 13,
        "Fibonacci iterator sai: " .. table.concat(r, ","))
end)

OBFTest.addTest("Iterator: zip hai iterator cùng lúc", "ITERATOR", function()
    local function fromTable(t)
        local i = 0
        return function() i = i + 1; return t[i] end
    end
    local function zip(it1, it2)
        return function()
            local a, b = it1(), it2()
            if a == nil or b == nil then return nil end
            return a, b
        end
    end
    local pairs_iter = zip(fromTable({1,2,3}), fromTable({10,20,30}))
    local sums = {}
    for a, b in pairs_iter do sums[#sums+1] = a + b end
    assert(#sums == 3 and sums[2] == 22,
        "Zip iterator sai: sums=" .. table.concat(sums, ","))
end)

OBFTest.addTest("Iterator: take N phần tử đầu", "ITERATOR", function()
    local function take(n, iter)
        local count = 0
        return function()
            count = count + 1
            if count > n then return nil end
            return iter()
        end
    end
    local function counter(start)
        local i = start - 1
        return function() i = i + 1; return i end
    end
    local first5 = take(5, counter(1))
    local r = {}
    for v in first5 do r[#r+1] = v end
    assert(#r == 5 and r[5] == 5, "Take iterator sai: r=" .. table.concat(r, ","))
end)

OBFTest.addTest("Iterator: ipairs với early exit", "ITERATOR", function()
    local t    = {1, 2, 3, 4, 5}
    local found = nil
    for _, v in ipairs(t) do
        if v == 3 then found = v; break end
    end
    assert(found == 3, "ipairs early exit sai: found=" .. tostring(found))
end)

local function testSyntax(syntax: boolean)
end
local function testSyntaxWithReturn(syntax: boolean): boolean
    return not syntax
end
local function testsyntax3(src: { number }, uncompressed_size: number): { number }
     print("OK")
    return dst
end
testSyntaxWithReturn()
testsyntax3()
-- ============================================================
-- CHẠY NGAY
-- ============================================================
local summary = OBFTest.run()

-- Xuất JSON (tuỳ chọn — bỏ comment để kích hoạt)
-- print(OBFTest.export(summary))

return OBFTest