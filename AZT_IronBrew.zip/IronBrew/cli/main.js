#!/usr/bin/env node
/**
 * IronBrew2 (Original Version v2.7.0) - Complete Zero-Dependency JavaScript Port
 * Source: https://github.com/Obfuscator-Collections/IronBrew2/tree/master/Original%20version
 *
 * Usage:
 *   node cli/main.js <input.lua|input.luac> [options]
 *
 * Examples:
 *   node cli/main.js file.lua --vm-compress
 *   node cli/main.js file.lua -o out.lua --vm-compress --encrypt-strings --control-flow
 */

'use strict';

const fs = require('fs');
const path = require('path');
const child_process = require('child_process');

// ============================================================================
// 1. Utility & Extension Helpers (IEnumerableExtensions / StringExtensions)
// ============================================================================

function randInt(min, maxExclusive) {
  if (maxExclusive <= min) return min;
  return Math.floor(Math.random() * (maxExclusive - min)) + min;
}

function shuffleArray(list) {
  for (let i = 0; i < list.length; i++) {
    const j = randInt(i, list.length);
    const tmp = list[i];
    list[i] = list[j];
    list[j] = tmp;
  }
  return list;
}

function latin1ToBuffer(str) {
  return Buffer.from(str, 'latin1');
}

function bufferToLatin1(buf, start = 0, end = buf.length) {
  return buf.subarray(start, end).toString('latin1');
}

// ============================================================================
// 2. Bytecode Library: Enums & Opcode (Enums.cs, Opcode.cs)
// ============================================================================

const ConstantType = Object.freeze({
  Nil: 0,
  Boolean: 1,
  Number: 2,
  String: 3,
});

const InstructionType = Object.freeze({
  ABC: 0,
  ABx: 1,
  AsBx: 2,
  AsBxC: 3,
  sAxBC: 4,
  Data: 5,
});

const Opcode = Object.freeze({
  Move: 0,
  LoadConst: 1,
  LoadBool: 2,
  LoadNil: 3,
  GetUpval: 4,
  GetGlobal: 5,
  GetTable: 6,
  SetGlobal: 7,
  SetUpval: 8,
  SetTable: 9,
  NewTable: 10,
  Self: 11,
  Add: 12,
  Sub: 13,
  Mul: 14,
  Div: 15,
  Mod: 16,
  Pow: 17,
  Unm: 18,
  Not: 19,
  Len: 20,
  Concat: 21,
  Jmp: 22,
  Eq: 23,
  Lt: 24,
  Le: 25,
  Test: 26,
  TestSet: 27,
  Call: 28,
  TailCall: 29,
  Return: 30,
  ForLoop: 31,
  ForPrep: 32,
  TForLoop: 33,
  SetList: 34,
  Close: 35,
  Closure: 36,
  VarArg: 37,

  // Custom VM opcodes
  SetTop: 38,
  PushStack: 39,
  NewStack: 40,
  SetFenv: 41,
});

const InstructionMappings = new Map([
  [Opcode.Move, InstructionType.ABC],
  [Opcode.LoadConst, InstructionType.ABx],
  [Opcode.LoadBool, InstructionType.ABC],
  [Opcode.LoadNil, InstructionType.ABC],
  [Opcode.GetUpval, InstructionType.ABC],
  [Opcode.GetGlobal, InstructionType.ABx],
  [Opcode.GetTable, InstructionType.ABC],
  [Opcode.SetGlobal, InstructionType.ABx],
  [Opcode.SetUpval, InstructionType.ABC],
  [Opcode.SetTable, InstructionType.ABC],
  [Opcode.NewTable, InstructionType.ABC],
  [Opcode.Self, InstructionType.ABC],
  [Opcode.Add, InstructionType.ABC],
  [Opcode.Sub, InstructionType.ABC],
  [Opcode.Mul, InstructionType.ABC],
  [Opcode.Div, InstructionType.ABC],
  [Opcode.Mod, InstructionType.ABC],
  [Opcode.Pow, InstructionType.ABC],
  [Opcode.Unm, InstructionType.ABC],
  [Opcode.Not, InstructionType.ABC],
  [Opcode.Len, InstructionType.ABC],
  [Opcode.Concat, InstructionType.ABC],
  [Opcode.Jmp, InstructionType.AsBx],
  [Opcode.Eq, InstructionType.ABC],
  [Opcode.Lt, InstructionType.ABC],
  [Opcode.Le, InstructionType.ABC],
  [Opcode.Test, InstructionType.ABC],
  [Opcode.TestSet, InstructionType.ABC],
  [Opcode.Call, InstructionType.ABC],
  [Opcode.TailCall, InstructionType.ABC],
  [Opcode.Return, InstructionType.ABC],
  [Opcode.ForLoop, InstructionType.AsBx],
  [Opcode.ForPrep, InstructionType.AsBx],
  [Opcode.TForLoop, InstructionType.ABC],
  [Opcode.SetList, InstructionType.ABC],
  [Opcode.Close, InstructionType.ABC],
  [Opcode.Closure, InstructionType.ABx],
  [Opcode.VarArg, InstructionType.ABC],
]);

// ============================================================================
// 3. Bytecode Library: IR (Constant.cs, Instruction.cs, Chunk.cs)
// ============================================================================

class CustomInstructionData {
  constructor(opcode = null, writtenOpcode = null) {
    this.Opcode = opcode;
    this.WrittenOpcode = writtenOpcode;
  }
}

class Constant {
  constructor(other = null) {
    if (other instanceof Constant) {
      this.Type = other.Type;
      this.Data = other.Data;
      this.BackReferences = other.BackReferences.slice();
    } else {
      this.Type = ConstantType.Nil;
      this.Data = null;
      this.BackReferences = [];
    }
  }
}

class Instruction {
  constructor(chunkOrOther, code, ...refOperands) {
    if (chunkOrOther instanceof Instruction) {
      const other = chunkOrOther;
      this.RefOperands = other.RefOperands.slice();
      this.BackReferences = other.BackReferences.slice();
      this.Chunk = other.Chunk;
      this.OpCode = other.OpCode;
      this.InstructionType = other.InstructionType;
      this.A = other.A;
      this.B = other.B;
      this.C = other.C;
      this.Data = other.Data;
      this.PC = other.PC;
      this.Line = other.Line;
      this.CustomData = other.CustomData
        ? new CustomInstructionData(other.CustomData.Opcode, other.CustomData.WrittenOpcode)
        : null;
    } else {
      this.RefOperands = [null, null, null];
      this.BackReferences = [];
      this.Chunk = chunkOrOther;
      this.OpCode = code;
      this.InstructionType = InstructionMappings.has(code)
        ? InstructionMappings.get(code)
        : InstructionType.ABC;
      this.A = 0;
      this.B = 0;
      this.C = 0;
      this.Data = 0;
      this.PC = 0;
      this.Line = 0;
      this.CustomData = null;

      for (let i = 0; i < refOperands.length; i++) {
        const op = refOperands[i];
        this.RefOperands[i] = op;
        if (op instanceof Instruction) {
          op.BackReferences.push(this);
        }
      }
    }
  }

  UpdateRegisters() {
    if (this.InstructionType === InstructionType.Data) return;

    this.PC = this.Chunk.InstructionMap.get(this);
    switch (this.OpCode) {
      case Opcode.LoadConst:
      case Opcode.GetGlobal:
      case Opcode.SetGlobal:
        if (this.RefOperands[0] instanceof Constant) {
          this.B = this.Chunk.ConstantMap.get(this.RefOperands[0]);
        }
        break;
      case Opcode.Jmp:
      case Opcode.ForLoop:
      case Opcode.ForPrep:
        if (this.RefOperands[0] instanceof Instruction) {
          this.B = this.Chunk.InstructionMap.get(this.RefOperands[0]) - this.PC - 1;
        }
        break;
      case Opcode.Closure:
        if (this.RefOperands[0] instanceof Chunk) {
          this.B = this.Chunk.FunctionMap.get(this.RefOperands[0]);
        }
        break;
      case Opcode.GetTable:
      case Opcode.SetTable:
      case Opcode.Add:
      case Opcode.Sub:
      case Opcode.Mul:
      case Opcode.Div:
      case Opcode.Mod:
      case Opcode.Pow:
      case Opcode.Eq:
      case Opcode.Lt:
      case Opcode.Le:
      case Opcode.Self:
        if (this.RefOperands[0] instanceof Constant) {
          this.B = this.Chunk.ConstantMap.get(this.RefOperands[0]) + 256;
        }
        if (this.RefOperands[1] instanceof Constant) {
          this.C = this.Chunk.ConstantMap.get(this.RefOperands[1]) + 256;
        }
        break;
    }
  }

  SetupRefs() {
    this.RefOperands = [null, null, null];
    switch (this.OpCode) {
      case Opcode.LoadConst:
      case Opcode.GetGlobal:
      case Opcode.SetGlobal: {
        const c = this.Chunk.Constants[this.B];
        this.RefOperands[0] = c;
        if (c) c.BackReferences.push(this);
        break;
      }
      case Opcode.Jmp:
      case Opcode.ForLoop:
      case Opcode.ForPrep: {
        const idx = this.Chunk.InstructionMap.get(this) + this.B + 1;
        const target = this.Chunk.Instructions[idx];
        this.RefOperands[0] = target;
        if (target) target.BackReferences.push(this);
        break;
      }
      case Opcode.Closure:
        this.RefOperands[0] = this.Chunk.Functions[this.B];
        break;
      case Opcode.GetTable:
      case Opcode.SetTable:
      case Opcode.Add:
      case Opcode.Sub:
      case Opcode.Mul:
      case Opcode.Div:
      case Opcode.Mod:
      case Opcode.Pow:
      case Opcode.Eq:
      case Opcode.Lt:
      case Opcode.Le:
      case Opcode.Self:
        if (this.B > 255) {
          this.RefOperands[0] = this.Chunk.Constants[this.B - 256];
        }
        if (this.C > 255) {
          this.RefOperands[1] = this.Chunk.Constants[this.C - 256];
        }
        break;
    }
  }
}

class Chunk {
  constructor() {
    this.Name = '';
    this.Line = 0;
    this.LastLine = 0;
    this.UpvalueCount = 0;
    this.ParameterCount = 0;
    this.VarargFlag = 0;
    this.StackSize = 0;
    this.CurrentOffset = 0;
    this.CurrentParamOffset = 0;
    this.Instructions = [];
    this.InstructionMap = new Map();
    this.Constants = [];
    this.ConstantMap = new Map();
    this.Functions = [];
    this.FunctionMap = new Map();
    this.Upvalues = [];
  }

  UpdateMappings() {
    this.InstructionMap.clear();
    this.ConstantMap.clear();
    this.FunctionMap.clear();

    for (let i = 0; i < this.Instructions.length; i++) {
      this.InstructionMap.set(this.Instructions[i], i);
      this.Instructions[i].PC = i;
    }
    for (let i = 0; i < this.Constants.length; i++) {
      this.ConstantMap.set(this.Constants[i], i);
    }
    for (let i = 0; i < this.Functions.length; i++) {
      this.FunctionMap.set(this.Functions[i], i);
    }
  }

  Rebase(offset, paramOffset = 0) {
    offset -= this.CurrentOffset;
    paramOffset -= this.CurrentParamOffset;

    this.CurrentOffset += offset;
    this.CurrentParamOffset += paramOffset;

    this.StackSize = (this.StackSize + offset) & 0xff;

    const Params = this.ParameterCount - 1;
    for (let i = 0; i < this.Instructions.length; i++) {
      const instr = this.Instructions[i];
      switch (instr.OpCode) {
        case Opcode.Move:
        case Opcode.LoadNil:
        case Opcode.Unm:
        case Opcode.Not:
        case Opcode.Len:
        case Opcode.TestSet:
          instr.A += instr.A > Params ? offset : paramOffset;
          instr.B += instr.B > Params ? offset : paramOffset;
          break;
        case Opcode.LoadConst:
        case Opcode.LoadBool:
        case Opcode.GetGlobal:
        case Opcode.SetGlobal:
        case Opcode.GetUpval:
        case Opcode.SetUpval:
        case Opcode.Call:
        case Opcode.TailCall:
        case Opcode.Return:
        case Opcode.VarArg:
        case Opcode.Test:
        case Opcode.ForPrep:
        case Opcode.ForLoop:
        case Opcode.TForLoop:
        case Opcode.NewTable:
        case Opcode.SetList:
        case Opcode.Close:
          instr.A += instr.A > Params ? offset : paramOffset;
          break;
        case Opcode.GetTable:
        case Opcode.SetTable:
          instr.A += instr.A > Params ? offset : paramOffset;
          if (instr.B < 255) {
            instr.B += instr.B > Params ? offset : paramOffset;
          }
          if (instr.C < 255) {
            instr.C += instr.C > Params ? offset : paramOffset;
          }
          break;
        case Opcode.Add:
        case Opcode.Sub:
        case Opcode.Mul:
        case Opcode.Div:
        case Opcode.Mod:
        case Opcode.Pow:
          instr.A += instr.A > Params ? offset : paramOffset;
          if (instr.B < 255) {
            instr.B += instr.B > Params ? offset : paramOffset;
          }
          if (instr.C < 255) {
            instr.C += instr.C > Params ? offset : paramOffset;
          }
          break;
        case Opcode.Concat:
          instr.A += instr.A > Params ? offset : paramOffset;
          instr.B += instr.B > Params ? offset : paramOffset;
          instr.C += instr.C > Params ? offset : paramOffset;
          break;
        case Opcode.Self:
          instr.A += instr.A > Params ? offset : paramOffset;
          instr.B += instr.B > Params ? offset : paramOffset;
          if (instr.C < 255) {
            instr.C += instr.C > Params ? offset : paramOffset;
          }
          break;
        case Opcode.Eq:
        case Opcode.Lt:
        case Opcode.Le:
          if (instr.B < 255) {
            instr.B += instr.B > Params ? offset : paramOffset;
          }
          if (instr.C < 255) {
            instr.C += instr.C > Params ? offset : paramOffset;
          }
          break;
        case Opcode.Closure: {
          instr.A += instr.A > Params ? offset : paramOffset;
          const nProto = this.Functions[instr.B];
          for (let i2 = 0; i2 < nProto.UpvalueCount; i2++) {
            const cInst = this.Instructions[i + i2 + 1];
            if (cInst.OpCode !== Opcode.Move) continue;
            cInst.B += cInst.B > Params ? offset : paramOffset;
          }
          i += nProto.UpvalueCount;
          break;
        }
      }
    }
    return this.ParameterCount;
  }
}

// ============================================================================
// 4. Bytecode Deserializer & Serializers (Deserializer.cs, Serializer.cs, VanillaSerializer.cs)
// ============================================================================

class Deserializer {
  constructor(inputBuffer) {
    this._buffer = Buffer.isBuffer(inputBuffer) ? inputBuffer : Buffer.from(inputBuffer);
    this._pos = 0;
    this._bigEndian = false;
    this._sizeNumber = 8;
    this._sizeSizeT = 4;
    this._expectingSetlistData = false;
  }

  Read(size, factorEndianness = true) {
    const slice = Buffer.from(this._buffer.subarray(this._pos, this._pos + size));
    this._pos += size;
    if (factorEndianness && this._bigEndian) {
      slice.reverse();
    }
    return slice;
  }

  ReadSizeT() {
    return this._sizeSizeT === 4 ? this.ReadInt32() : Number(this.ReadInt64());
  }

  ReadInt64() {
    const b = this.Read(8);
    return b.readBigInt64LE(0);
  }

  ReadInt32(factorEndianness = true) {
    const b = this.Read(4, factorEndianness);
    return b.readInt32LE(0);
  }

  ReadByte() {
    return this.Read(1)[0];
  }

  ReadString() {
    const count = this.ReadSizeT();
    if (count === 0) return '';
    const val = this.Read(count, false);
    return bufferToLatin1(val, 0, count - 1);
  }

  ReadDouble() {
    const b = this.Read(this._sizeNumber);
    return b.readDoubleLE(0);
  }

  DecodeInstruction(chunk) {
    const code = this.ReadInt32();
    const ucode = code >>> 0;
    const i = new Instruction(chunk, ucode & 0x3f);
    i.Data = code;

    if (this._expectingSetlistData) {
      this._expectingSetlistData = false;
      i.InstructionType = InstructionType.Data;
      return i;
    }

    i.A = (ucode >>> 6) & 0xff;
    switch (i.InstructionType) {
      case InstructionType.ABC:
        i.B = (ucode >>> (6 + 8 + 9)) & 0x1ff;
        i.C = (ucode >>> (6 + 8)) & 0x1ff;
        break;
      case InstructionType.ABx:
        i.B = (ucode >>> (6 + 8)) & 0x3ffff;
        i.C = -1;
        break;
      case InstructionType.AsBx:
        i.B = ((ucode >>> (6 + 8)) & 0x3ffff) - 131071;
        i.C = -1;
        break;
    }

    if (i.OpCode === Opcode.SetList && i.C === 0) {
      this._expectingSetlistData = true;
    }
    return i;
  }

  DecodeInstructions(chunk) {
    const instructions = [];
    const count = this.ReadInt32();
    for (let i = 0; i < count; i++) {
      instructions.push(this.DecodeInstruction(chunk, i));
    }
    return instructions;
  }

  DecodeConstant() {
    const c = new Constant();
    const type = this.ReadByte();
    switch (type) {
      case 0:
        c.Type = ConstantType.Nil;
        c.Data = null;
        break;
      case 1:
        c.Type = ConstantType.Boolean;
        c.Data = this.ReadByte() !== 0;
        break;
      case 3:
        c.Type = ConstantType.Number;
        c.Data = this.ReadDouble();
        break;
      case 4:
        c.Type = ConstantType.String;
        c.Data = this.ReadString();
        break;
    }
    return c;
  }

  DecodeConstants() {
    const constants = [];
    const count = this.ReadInt32();
    for (let i = 0; i < count; i++) {
      constants.push(this.DecodeConstant());
    }
    return constants;
  }

  DecodeChunk() {
    const c = new Chunk();
    c.Name = this.ReadString();
    c.Line = this.ReadInt32();
    c.LastLine = this.ReadInt32();
    c.UpvalueCount = this.ReadByte();
    c.ParameterCount = this.ReadByte();
    c.VarargFlag = this.ReadByte();
    c.StackSize = this.ReadByte();
    c.Upvalues = [];

    c.Instructions = this.DecodeInstructions(c);
    c.Constants = this.DecodeConstants();
    c.Functions = this.DecodeChunks();

    c.UpdateMappings();
    for (const inst of c.Instructions) {
      inst.SetupRefs();
    }

    let count = this.ReadInt32();
    for (let i = 0; i < count; i++) {
      c.Instructions[i].Line = this.ReadInt32();
    }

    count = this.ReadInt32();
    for (let i = 0; i < count; i++) {
      this.ReadString();
      this.ReadInt32();
      this.ReadInt32();
    }

    count = this.ReadInt32();
    for (let i = 0; i < count; i++) {
      c.Upvalues.push(this.ReadString());
    }

    return c;
  }

  DecodeChunks() {
    const chunks = [];
    const count = this.ReadInt32();
    for (let i = 0; i < count; i++) {
      chunks.push(this.DecodeChunk());
    }
    return chunks;
  }

  DecodeFile() {
    const header = this.ReadInt32();
    if (header !== 0x1b4c7561 && header !== 0x61754c1b) {
      throw new Error('Invalid luac file.');
    }
    if (this.ReadByte() !== 0x51) {
      throw new Error('Only Lua 5.1 is supported.');
    }
    this.ReadByte(); // format
    this._bigEndian = this.ReadByte() === 0;
    this.ReadByte(); // int size
    this._sizeSizeT = this.ReadByte();
    this.ReadByte(); // instruction size
    this._sizeNumber = this.ReadByte();
    this.ReadByte(); // integral flag

    return this.DecodeChunk();
  }
}

class VanillaSerializer {
  constructor(chunk) {
    this._chunk = chunk;
  }

  Serialize() {
    const res = [];
    const writeByte = (b) => res.push(b & 0xff);
    const writeBytes = (bs) => {
      for (let i = 0; i < bs.length; i++) res.push(bs[i] & 0xff);
    };
    const writeInt = (val) => {
      const b = Buffer.allocUnsafe(4);
      b.writeInt32LE(val | 0, 0);
      writeBytes(b);
    };
    const writeUInt = (val) => {
      const b = Buffer.allocUnsafe(4);
      b.writeUInt32LE(val >>> 0, 0);
      writeBytes(b);
    };
    const writeNum = (d) => {
      const b = Buffer.allocUnsafe(8);
      b.writeDoubleLE(Number(d), 0);
      writeBytes(b);
    };
    const writeString = (str) => {
      const bytes = latin1ToBuffer(str);
      writeInt(bytes.length + 1);
      writeBytes(bytes);
      writeByte(0);
    };

    const writeChunk = (chunk) => {
      if (chunk.Name !== '') writeString(chunk.Name);
      else writeInt(0);

      writeInt(chunk.Line);
      writeInt(chunk.LastLine);
      writeByte(chunk.UpvalueCount);
      writeByte(chunk.ParameterCount);
      writeByte(chunk.VarargFlag);
      writeByte(chunk.StackSize);

      chunk.UpdateMappings();
      for (const inst of chunk.Instructions) {
        inst.UpdateRegisters();
      }

      writeInt(chunk.Instructions.length);
      for (const i of chunk.Instructions) {
        i.UpdateRegisters();
        if (i.InstructionType === InstructionType.Data) {
          writeInt(i.Data);
          continue;
        }
        const a = i.A & 0xff;
        let b = i.B;
        const c = i.C & 0x1ff;
        let result = (i.OpCode & 0x3f) | (a << 6);

        switch (i.InstructionType) {
          case InstructionType.ABx:
            result |= (b & 0x3ffff) << (6 + 8);
            break;
          case InstructionType.AsBx:
            b += 131071;
            result |= (b & 0x3ffff) << (6 + 8);
            break;
          case InstructionType.ABC:
            result |= (c & 0x1ff) << (6 + 8);
            result |= (b & 0x1ff) << (6 + 8 + 9);
            break;
        }
        writeUInt(result >>> 0);
      }

      writeInt(chunk.Constants.length);
      for (const constant of chunk.Constants) {
        switch (constant.Type) {
          case ConstantType.Nil:
            writeByte(0);
            break;
          case ConstantType.Boolean:
            writeByte(1);
            writeByte(constant.Data ? 1 : 0);
            break;
          case ConstantType.Number:
            writeByte(3);
            writeNum(constant.Data);
            break;
          case ConstantType.String:
            writeByte(4);
            writeString(constant.Data);
            break;
        }
      }

      writeInt(chunk.Functions.length);
      for (const sChunk of chunk.Functions) {
        writeChunk(sChunk);
      }

      writeInt(chunk.Instructions.length);
      for (const instr of chunk.Instructions) {
        writeInt(instr.Line || 1);
      }
      writeInt(0);
      writeInt(0);
    };

    writeByte(27);
    writeBytes(latin1ToBuffer('Lua'));
    writeByte(0x51);
    writeByte(0);
    writeByte(1);
    writeByte(4);
    writeByte(4);
    writeByte(4);
    writeByte(8);
    writeByte(0);

    writeChunk(this._chunk);
    return Buffer.from(res);
  }
}

const ChunkStep = Object.freeze({
  ParameterCount: 0,
  StringTable: 1,
  Instructions: 2,
  Constants: 3,
  Functions: 4,
  LineInfo: 5,
  StepCount: 6,
});

const InstructionStep1 = Object.freeze({
  Type: 0,
  A: 1,
  B: 2,
  C: 3,
  StepCount: 4,
});

const InstructionStep2 = Object.freeze({
  Op: 0,
  Bx: 1,
  D: 2,
  StepCount: 3,
});

class Serializer {
  constructor(context, settings) {
    this._context = context;
    this._settings = settings;
  }

  SerializeLChunk(chunk, factorXor = true) {
    const bytes = [];
    const xorKey = this._context.PrimaryXorKey & 0xff;

    const writeByte = (b) => {
      let val = b & 0xff;
      if (factorXor) val ^= xorKey;
      bytes.push(val);
    };

    const write = (buf) => {
      for (let i = 0; i < buf.length; i++) {
        writeByte(buf[i]);
      }
    };

    const writeInt32 = (i) => {
      const b = Buffer.allocUnsafe(4);
      b.writeInt32LE(i | 0, 0);
      write(b);
    };

    const writeNumber = (d) => {
      const b = Buffer.allocUnsafe(8);
      b.writeDoubleLE(Number(d), 0);
      write(b);
    };

    const writeString = (s) => {
      const sBytes = latin1ToBuffer(s);
      writeInt32(sBytes.length);
      write(sBytes);
    };

    const writeBool = (b) => {
      writeByte(b ? 1 : 0);
    };

    chunk.UpdateMappings();
    for (const ins of chunk.Instructions) {
      ins.UpdateRegisters();
    }

    const serializeInstruction = (inst) => {
      inst.UpdateRegisters();

      if (inst.InstructionType === InstructionType.Data) {
        return [randInt(0, 0x7fffffff), inst.Data | 0];
      }

      const cData = inst.CustomData;
      let opCode = inst.OpCode | 0;

      if (cData != null) {
        const virtualOpcode = cData.Opcode;
        opCode =
          cData.WrittenOpcode != null && cData.WrittenOpcode.VIndex !== undefined
            ? cData.WrittenOpcode.VIndex
            : virtualOpcode.VIndex;
        if (virtualOpcode) {
          virtualOpcode.Mutate(inst);
        }
      }

      const a = inst.A | 0;
      let b = inst.B | 0;
      const c = inst.C | 0;

      let result_i1 = 0;
      let result_i2 = 0;

      if (
        inst.InstructionType === InstructionType.AsBx ||
        inst.InstructionType === InstructionType.AsBxC
      ) {
        b += 1048575;
      }

      result_i1 |= inst.InstructionType & 0xff;
      result_i1 |= (a & 0x1ff) << 2;
      result_i1 |= (b & 0x1ff) << (2 + 9);
      result_i1 |= (c & 0x1ff) << (2 + 9 + 9);

      result_i2 |= opCode & 0x7ff;
      result_i2 |= b << 11;

      return [result_i1 | 0, result_i2 | 0];
    };

    for (let i = 0; i < ChunkStep.StepCount; i++) {
      switch (this._context.ChunkSteps[i]) {
        case ChunkStep.ParameterCount:
          writeByte(chunk.ParameterCount);
          break;
        case ChunkStep.Constants:
          writeInt32(chunk.Constants.length);
          for (const c of chunk.Constants) {
            writeByte(this._context.ConstantMapping[c.Type]);
            switch (c.Type) {
              case ConstantType.Boolean:
                writeBool(c.Data);
                break;
              case ConstantType.Number:
                writeNumber(c.Data);
                break;
              case ConstantType.String:
                writeString(c.Data);
                break;
            }
          }
          break;
        case ChunkStep.Instructions:
          writeInt32(chunk.Instructions.length);
          for (const ins of chunk.Instructions) {
            const arr = serializeInstruction(ins);
            writeInt32((arr[0] ^ this._context.IXorKey1) | 0);
            writeInt32((arr[1] ^ this._context.IXorKey2) | 0);
          }
          break;
        case ChunkStep.Functions:
          writeInt32(chunk.Functions.length);
          for (const c of chunk.Functions) {
            write(this.SerializeLChunk(c, false));
          }
          break;
        case ChunkStep.LineInfo:
          if (this._settings.PreserveLineInfo) {
            writeInt32(chunk.Instructions.length);
            for (const instr of chunk.Instructions) {
              writeInt32(instr.Line || 1);
            }
          }
          break;
      }
    }

    return Buffer.from(bytes);
  }
}

// ============================================================================
// 5. ObfuscationSettings & ObfuscationContext
// ============================================================================

class ObfuscationSettings {
  constructor() {
    this.EncryptStrings = false;
    this.EncryptImportantStrings = false;
    this.ControlFlow = true;
    this.BytecodeCompress = true;
    this.DecryptTableLen = 500;
    this.PreserveLineInfo = false;
    this.Mutate = true;
    this.SuperOperators = true;
    this.MaxMegaSuperOperators = 200;
    this.MaxMiniSuperOperators = 150;
    this.MaxMutations = 300;
    this.MinifyOutput = true;
    this.WrapCompress = false;
    this.RuntimeDecodeMode = 'lzw'; // 'lzw' | 'encoding-service' | 'http-service' | 'luau-buffer' | 'hybrid' | 'roblox-only'
    this.RobloxStrict = false;
    this.PlaceLock = null;
    this.GameLock = null;
    this.Path2DLayer = false;
    this.CustomBufferAPI = true;
    this.CustomTableAPI = true;
  }
}

class ObfuscationContext {
  constructor(chunk) {
    this.HeadChunk = chunk;
    this.ChunkSteps = shuffleArray(
      Array.from({ length: ChunkStep.StepCount }, (_, i) => i)
    );
    this.InstructionSteps1 = shuffleArray(
      Array.from({ length: InstructionStep1.StepCount }, (_, i) => i)
    );
    this.InstructionSteps2 = shuffleArray(
      Array.from({ length: InstructionStep2.StepCount }, (_, i) => i)
    );
    this.ConstantMapping = shuffleArray([0, 1, 2, 3]);
    this.InstructionMapping = new Map();

    this.PrimaryXorKey = randInt(0, 256);
    this.IXorKey1 = randInt(0, 256);
    this.IXorKey2 = randInt(0, 256);
  }
}

// ============================================================================
// 6. All 82 Virtual Opcodes (VOpcode.cs & Opcodes/*.cs)
// ============================================================================

class VOpcode {
  constructor() {
    this.VIndex = 0;
  }
  IsInstruction(_instruction) {
    return false;
  }
  GetObfuscated(_context) {
    return '';
  }
  Mutate(_instruction) {}
}

// --- OpAdd.cs ---
class OpAdd extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Add && i.B <= 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]+Stk[Inst[OP_C]];'; }
}
class OpAddB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Add && i.B > 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]+Stk[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; }
}
class OpAddC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Add && i.B <= 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]+Const[Inst[OP_C]];'; }
  Mutate(i) { i.C -= 255; }
}
class OpAddBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Add && i.B > 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]+Const[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; i.C -= 255; }
}

// --- OpCall.cs ---
class OpCall extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B > 1 && i.C > 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Edx=0;local Limit=A+Inst[OP_B]-1;for Idx=A+1,Limit do Edx=Edx+1;Args[Edx]=Stk[Idx];end;local Results={Stk[A](Unpack(Args,1,Limit-A))};local Limit=A+Inst[OP_C]-2;Edx=0;for Idx=A,Limit do Edx=Edx+1;Stk[Idx]=Results[Edx];end;Top=Limit;';
  }
}
class OpCallB0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B === 0 && i.C > 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Edx=0;local Limit=Top;for Idx=A+1,Limit do Edx=Edx+1;Args[Edx]=Stk[Idx];end;local Results={Stk[A](Unpack(Args,1,Limit-A))};local Limit=A+Inst[OP_C]-2;Edx=0;for Idx=A,Limit do Edx=Edx+1;Stk[Idx]=Results[Edx];end;Top=Limit;';
  }
}
class OpCallB1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B === 1 && i.C > 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Results,Limit={Stk[A]()};local Limit=A+Inst[OP_C]-2;local Edx=0;for Idx=A,Limit do Edx=Edx+1;Stk[Idx]=Results[Edx];end;Top=Limit;';
  }
}
class OpCallC0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B > 1 && i.C === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Edx=0;local Limit=A+Inst[OP_B]-1;for Idx=A+1,Limit do Edx=Edx+1;Args[Edx]=Stk[Idx];end;local Results,Limit=_R(Stk[A](Unpack(Args,1,Limit-A)));Limit=Limit+A-1;Edx=0;for Idx=A,Limit do Edx=Edx+1;Stk[Idx]=Results[Edx];end;Top=Limit;';
  }
}
class OpCallC1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B > 1 && i.C === 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Edx=0;local Limit=A+Inst[OP_B]-1;for Idx=A+1,Limit do Edx=Edx+1;Args[Edx]=Stk[Idx];end;Stk[A](Unpack(Args,1,Limit-A));Top=A;';
  }
}
class OpCallB0C0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B === 0 && i.C === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Edx=0;local Limit=Top;for Idx=A+1,Limit do Edx=Edx+1;Args[Edx]=Stk[Idx];end;local Results,Limit=_R(Stk[A](Unpack(Args,1,Limit-A)));Limit=Limit+A-1;Edx=0;for Idx=A,Limit do Edx=Edx+1;Stk[Idx]=Results[Edx];end;Top=Limit;';
  }
}
class OpCallB0C1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B === 0 && i.C === 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Edx=0;local Limit=Top;for Idx=A+1,Limit do Edx=Edx+1;Args[Edx]=Stk[Idx];end;Stk[A](Unpack(Args,1,Limit-A));Top=A;';
  }
}
class OpCallB1C0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B === 1 && i.C === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Results,Limit=_R(Stk[A]());Top=A-1;Limit=Limit+A-1;local Edx=0;for Idx=A,Limit do Edx=Edx+1;Stk[Idx]=Results[Edx];end;Top=Limit;';
  }
}
class OpCallB1C1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Call && i.B === 1 && i.C === 1; }
  GetObfuscated() {
    return 'Stk[Inst[OP_A]]();Top=A;';
  }
}

// --- OpClose.cs ---
class OpClose extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Close; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Cls={};for Idx=1,#Lupvals do local List=Lupvals[Idx];for Idz=0,#List do local Upv=List[Idz];local NStk=Upv[1];local Pos=Upv[2]; if NStk==Stk and Pos>=A then Cls[Pos]=NStk[Pos];Upv[1]=Cls;end;end;end;';
  }
}

// --- OpClosure.cs ---
class OpClosure extends VOpcode {
  IsInstruction(i) {
    return i.OpCode === Opcode.Closure && i.Chunk.Functions[i.B].UpvalueCount > 0;
  }
  GetObfuscated(context) {
    const i1 = context.InstructionMapping.get(Opcode.Move);
    const opMoveStr = i1 ? String(i1.VIndex) : '-1';
    return (
      'local NewProto=Proto[Inst[OP_B]];local NewUvals;local Indexes={};NewUvals=Setmetatable({},{__index=function(_,Key)local Val=Indexes[Key];return Val[1][Val[2]];end,__newindex=function(_,Key,Value)local Val=Indexes[Key] Val[1][Val[2]]=Value;end;});for Idx=1,Inst[OP_C] do InstrPoint=InstrPoint+1;local Mvm=Instr[InstrPoint];if Mvm[OP_ENUM]==OP_MOVE then Indexes[Idx-1]={Stk,Mvm[OP_B]};else Indexes[Idx-1]={Upvalues,Mvm[OP_B]};end;Lupvals[#Lupvals+1]=Indexes;end;Stk[Inst[OP_A]]=Wrap(NewProto,NewUvals,Env);'
    ).replace('OP_MOVE', opMoveStr);
  }
  Mutate(i) {
    i.InstructionType = InstructionType.AsBxC;
    i.C = i.Chunk.Functions[i.B].UpvalueCount;
  }
}
class OpClosureNU extends VOpcode {
  IsInstruction(i) {
    return i.OpCode === Opcode.Closure && i.Chunk.Functions[i.B].UpvalueCount === 0;
  }
  GetObfuscated() {
    return 'Stk[Inst[OP_A]]=Wrap(Proto[Inst[OP_B]],nil,Env);';
  }
}

// --- OpConcat.cs ---
class OpConcat extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Concat; }
  GetObfuscated() {
    return 'local B=Inst[OP_B];local K=Stk[B] for Idx=B+1,Inst[OP_C] do K=K..Stk[Idx];end;Stk[Inst[OP_A]]=K;';
  }
}

// --- OpDiv.cs ---
class OpDiv extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Div && i.B <= 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]/Stk[Inst[OP_C]];'; }
}
class OpDivB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Div && i.B > 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]/Stk[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; }
}
class OpDivC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Div && i.B <= 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]/Const[Inst[OP_C]];'; }
  Mutate(i) { i.C -= 255; }
}
class OpDivBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Div && i.B > 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]/Const[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; i.C -= 255; }
}

// --- OpEq.cs ---
class OpEq extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A === 0 && i.B <= 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]==Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpEqB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A === 0 && i.B > 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]==Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpEqC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A === 0 && i.B <= 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]==Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpEqBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A === 0 && i.B > 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]==Const[Inst[OP_C]]) then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}

// --- OpForLoop.cs ---
class OpForLoop extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.ForLoop; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Step=Stk[A+2];local Index=Stk[A]+Step;Stk[A]=Index;if Step>0 then if Index<=Stk[A+1] then InstrPoint=InstrPoint+Inst[OP_B];Stk[A+3]=Index;end;elseif Index>=Stk[A+1] then InstrPoint=InstrPoint+Inst[OP_B];Stk[A+3]=Index;end;';
  }
}

// --- OpForPrep.cs ---
class OpForPrep extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.ForPrep; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];Stk[A]=Stk[A]-Stk[A+2];InstrPoint=InstrPoint+Inst[OP_B];';
  }
}

// --- OpGe.cs ---
class OpGe extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A !== 0 && i.B <= 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]>=Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpGeB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A !== 0 && i.B > 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]>=Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpGeC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A !== 0 && i.B <= 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]>=Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpGeBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A !== 0 && i.B > 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]>=Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}

// --- OpGetGlobal.cs ---
class OpGetGlobal extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.GetGlobal; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Env[Const[Inst[OP_B]]];'; }
  Mutate(i) { i.B++; }
}

// --- OpGetTable.cs ---
class OpGetTable extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.GetTable && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]][Stk[Inst[OP_C]]];'; }
}
class OpGetTableConst extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.GetTable && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]][Const[Inst[OP_C]]];'; }
  Mutate(i) { i.C -= 255; }
}

// --- OpGetUpval.cs ---
class OpGetUpval extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.GetUpval; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Upvalues[Inst[OP_B]];'; }
}

// --- OpGt.cs ---
class OpGt extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A !== 0 && i.B <= 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]>Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpGtB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A !== 0 && i.B > 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]>Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpGtC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A !== 0 && i.B <= 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]>Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpGtBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A !== 0 && i.B > 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]>Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}

// --- OpJmp.cs ---
class OpJmp extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Jmp; }
  GetObfuscated() { return 'InstrPoint=InstrPoint+Inst[OP_B];'; }
}

// --- OpLe.cs ---
class OpLe extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A === 0 && i.B <= 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]<=Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpLeB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A === 0 && i.B > 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]<=Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpLeC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A === 0 && i.B <= 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]<=Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpLeBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Le && i.A === 0 && i.B > 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]<=Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}

// --- OpLen.cs ---
class OpLen extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Len; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=#Stk[Inst[OP_B]];'; }
}

// --- OpLoadBool.cs ---
class OpLoadBool extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.LoadBool && i.C === 0; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=(Inst[OP_B]~=0);'; }
}
class OpLoadBoolC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.LoadBool && i.C !== 0; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=(Inst[OP_B]~=0);InstrPoint=InstrPoint+1;'; }
  Mutate(i) { i.C = 0; }
}

// --- OpLoadK.cs ---
class OpLoadK extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.LoadConst; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]];'; }
  Mutate(i) { i.B++; }
}

// --- OpLoadNil.cs ---
class OpLoadNil extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.LoadNil; }
  GetObfuscated() { return 'for Idx=Inst[OP_A],Inst[OP_B] do Stk[Idx]=nil;end;'; }
}

// --- OpLt.cs ---
class OpLt extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A === 0 && i.B <= 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]<Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpLtB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A === 0 && i.B > 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]<Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpLtC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A === 0 && i.B <= 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]<Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpLtBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Lt && i.A === 0 && i.B > 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]<Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}

// --- OpMod.cs ---
class OpMod extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mod && i.B <= 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]%Stk[Inst[OP_C]];'; }
}
class OpModB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mod && i.B > 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]%Stk[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; }
}
class OpModC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mod && i.B <= 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]%Const[Inst[OP_C]];'; }
  Mutate(i) { i.C -= 255; }
}
class OpModBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mod && i.B > 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]%Const[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; i.C -= 255; }
}

// --- OpMove.cs ---
class OpMove extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Move; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]];'; }
}

// --- OpMul.cs ---
class OpMul extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mul && i.B <= 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]*Stk[Inst[OP_C]];'; }
}
class OpMulB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mul && i.B > 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]*Stk[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; }
}
class OpMulC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mul && i.B <= 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]*Const[Inst[OP_C]];'; }
  Mutate(i) { i.C -= 255; }
}
class OpMulBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Mul && i.B > 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]*Const[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; i.C -= 255; }
}

// --- OpMutated.cs ---
class OpMutated extends VOpcode {
  constructor() {
    super();
    this.Mutated = null;
    this.Registers = null;
  }
  IsInstruction() { return false; }
  CheckInstruction() { return randInt(1, 15) === 1; }
  GetObfuscated(context) { return this.Mutated.GetObfuscated(context); }
  Mutate(instruction) { this.Mutated.Mutate(instruction); }
}

// --- OpNe.cs ---
class OpNe extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A !== 0 && i.B <= 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]~=Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpNeB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A !== 0 && i.B > 255 && i.C <= 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]~=Stk[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpNeC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A !== 0 && i.B <= 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Stk[Inst[OP_A]]~=Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpNeBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Eq && i.A !== 0 && i.B > 255 && i.C > 255; }
  GetObfuscated() {
    return 'if(Const[Inst[OP_A]]~=Const[Inst[OP_C]])then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.A = i.B - 255;
    i.C -= 255;
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}

// --- OpNewStk.cs ---
class OpNewStk extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.NewStack; }
  GetObfuscated() {
    return 'Stk = {};for Idx = 0, PCount do if Idx < Params then Stk[Idx] = Args[Idx + 1]; else break end; end;';
  }
}

// --- OpNewTable.cs ---
class OpNewTableB0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.NewTable && i.B === 0; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]={};'; }
}
class OpNewTableB5000 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.NewTable && i.B > 5000; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]={};'; }
}
class OpNewTableBElse extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.NewTable && i.B > 0 && i.B <= 5000; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]={unpack({}, 1, Inst[OP_B])};'; }
}

// --- OpNot.cs ---
class OpNot extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Not; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=(not Stk[Inst[OP_B]]);'; }
}

// --- OpPow.cs ---
class OpPow extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Pow && i.B <= 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]^Stk[Inst[OP_C]];'; }
}
class OpPowB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Pow && i.B > 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]^Stk[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; }
}
class OpPowC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Pow && i.B <= 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]^Const[Inst[OP_C]];'; }
  Mutate(i) { i.C -= 255; }
}
class OpPowBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Pow && i.B > 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]^Const[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; i.C -= 255; }
}

// --- OpPushStk.cs ---
class OpPushStk extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.PushStack; }
  GetObfuscated() { return 'Stk[Inst[OP_A]] = Stk'; }
}

// --- OpReturn.cs ---
class OpReturn extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Return && i.B > 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Limit=A+Inst[OP_B]-2;local Output={};local Edx=0;for Idx=A,Limit do Edx=Edx+1;Output[Edx]=Stk[Idx];end; do return Unpack(Output,1,Edx) end;';
  }
}
class OpReturnB0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Return && i.B === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Limit=Top;local Output={};local Edx=0;for Idx=A,Limit do Edx=Edx+1;Output[Edx]=Stk[Idx];end;do return Unpack(Output,1,Edx) end;';
  }
}
class OpReturnB1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Return && i.B === 1; }
  GetObfuscated() { return 'do return end;'; }
}

// --- OpSelf.cs ---
class OpSelf extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Self && i.C <= 255; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local B=Stk[Inst[OP_B]];Stk[A+1]=B;Stk[A]=B[Stk[Inst[OP_C]]];';
  }
}
class OpSelfC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Self && i.C > 255; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local B=Stk[Inst[OP_B]];Stk[A+1]=B;Stk[A]=B[Const[Inst[OP_C]]];';
  }
  Mutate(i) { i.C -= 255; }
}

// --- OpSetFEnv.cs ---
class OpSetFEnv extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetFenv; }
  GetObfuscated() { return 'Env = Stk[Inst[OP_A]]'; }
}

// --- OpSetGlobal.cs ---
class OpSetGlobal extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetGlobal; }
  GetObfuscated() { return 'Env[Const[Inst[OP_B]]]=Stk[Inst[OP_A]];'; }
  Mutate(i) { i.B++; }
}

// --- OpSetList.cs ---
class OpSetList extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetList && i.B !== 0 && i.C > 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Offset=(Inst[OP_C]-1)*50;local T=Stk[A];local B=Inst[OP_B];for Idx=1,B do T[Offset+Idx]=Stk[A+Idx] end;';
  }
}
class OpSetListC1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetList && i.B !== 0 && i.C === 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local T=Stk[A];local B=Inst[OP_B];for Idx=1,B do T[Idx]=Stk[A+Idx] end;';
  }
}
class OpSetListB0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetList && i.B === 0 && i.C !== 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Offset=(Inst[OP_C]-1)*50;local T=Stk[A];local X=Top-A;for Idx=1,X do T[Offset+Idx]=Stk[A+Idx] end;';
  }
}
class OpSetListC0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetList && i.B !== 0 && i.C === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];InstrPoint=InstrPoint+1;local Offset=(Instr[InstrPoint][5]-1)*50;local T=Stk[A];local B=Inst[OP_B];for Idx=1,B do T[Offset+Idx]=Stk[A+Idx] end;';
  }
}
class OpSetListB0C0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetList && i.B === 0 && i.C === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];InstrPoint=InstrPoint+1;local Offset=(Instr[InstrPoint][5]-1)*50;local T=Stk[A];local X=Top-A;for Idx=1,X do T[Offset+Idx]=Stk[A+Idx] end;';
  }
}
class OpSetListB0C1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetList && i.B === 0 && i.C === 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local T=Stk[A];local X=Top-A;for Idx=1,X do T[Idx]=Stk[A+Idx] end;';
  }
}

// --- OpSetTable.cs ---
class OpSetTable extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetTable && i.B <= 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]][Stk[Inst[OP_B]]]=Stk[Inst[OP_C]];'; }
}
class OpSetTableB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetTable && i.B > 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]][Const[Inst[OP_B]]]=Stk[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; }
}
class OpSetTableC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetTable && i.B <= 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]][Stk[Inst[OP_B]]]=Const[Inst[OP_C]];'; }
  Mutate(i) { i.C -= 255; }
}
class OpSetTableBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetTable && i.B > 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]][Const[Inst[OP_B]]]=Const[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; i.C -= 255; }
}

// --- OpSetTop.cs ---
class OpSetTop extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetTop; }
  GetObfuscated() { return 'Top=Inst[OP_A];'; }
}

// --- OpSetUpval.cs ---
class OpSetUpval extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.SetUpval; }
  GetObfuscated() { return 'Upvalues[Inst[OP_B]]=Stk[Inst[OP_A]];'; }
}

// --- OpSub.cs ---
class OpSub extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Sub && i.B <= 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]-Stk[Inst[OP_C]];'; }
}
class OpSubB extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Sub && i.B > 255 && i.C <= 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]-Stk[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; }
}
class OpSubC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Sub && i.B <= 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Stk[Inst[OP_B]]-Const[Inst[OP_C]];'; }
  Mutate(i) { i.C -= 255; }
}
class OpSubBC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Sub && i.B > 255 && i.C > 255; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=Const[Inst[OP_B]]-Const[Inst[OP_C]];'; }
  Mutate(i) { i.B -= 255; i.C -= 255; }
}

// --- OpSuperOperator.cs ---
class OpSuperOperator extends VOpcode {
  constructor() {
    super();
    this.SubOpcodes = null;
  }
  IsInstruction(instructions) {
    if (!Array.isArray(instructions)) return false;
    if (instructions.length !== this.SubOpcodes.length) return false;
    for (let i = 0; i < this.SubOpcodes.length; i++) {
      const sub = this.SubOpcodes[i];
      if (sub instanceof OpMutated) {
        if (!sub.Mutated.IsInstruction(instructions[i])) return false;
      } else if (!sub.IsInstruction(instructions[i])) {
        return false;
      }
    }
    return true;
  }
  GetObfuscated(context) {
    let s = '';
    const locals = [];
    const reg = /local(.*?)[;=]/g;

    for (let index = 0; index < this.SubOpcodes.length; index++) {
      const subOpcode = this.SubOpcodes[index];
      let s2 = subOpcode.GetObfuscated(context);

      const matches = [...s2.matchAll(reg)];
      for (const m of matches) {
        const loc = m[1].replace(/ /g, '');
        if (!locals.includes(loc)) locals.push(loc);

        if (!m[0].includes(';')) {
          s2 = s2.split(`local${m[1]}`).join(loc);
        } else {
          s2 = s2.split(`local${m[1]};`).join('');
        }
      }

      s += s2;
      if (index + 1 < this.SubOpcodes.length) {
        s += 'InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];';
      }
    }

    for (const l of locals) {
      s = 'local ' + l + ';' + s;
    }
    return s;
  }
}

// --- OpTForLoop.cs ---
class OpTForLoop extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.TForLoop; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local C=Inst[OP_C];local Offset=A+2;if Type(Stk[A])~="function" then local Mt=Getmetatable(Stk[A]);if Mt and Mt.__iter then Stk[A],Stk[A+1],Stk[Offset]=Mt.__iter(Stk[A]);else Stk[A+1]=Stk[A];Stk[A]=Next;end;end;local Result={Stk[A](Stk[A+1],Stk[Offset])};for Idx=1,C do Stk[Offset+Idx]=Result[Idx];end;local R=Stk[A+3];if R~=nil then Stk[Offset]=R else InstrPoint=InstrPoint+1;end;';
  }
}

// --- OpTailCall.cs ---
class OpTailCall extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.TailCall && i.B > 1; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Limit=A+Inst[OP_B]-1;for Idx=A+1,Limit do Args[#Args+1]=Stk[Idx];end;do return Stk[A](Unpack(Args,1,Limit-A)) end;';
  }
}
class OpTailCallB0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.TailCall && i.B === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local Args={};local Limit=Top;for Idx=A+1,Limit do Args[#Args+1]=Stk[Idx];end;do return Stk[A](Unpack(Args,1,Limit-A)) end;';
  }
}
class OpTailCallB1 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.TailCall && i.B === 1; }
  GetObfuscated() { return 'local A=Inst[OP_A];do return Stk[A](); end;'; }
}

// --- OpTest.cs ---
class OpTest extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Test && i.C === 0; }
  GetObfuscated() {
    return 'if Stk[Inst[OP_A]] then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}
class OpTestC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Test && i.C !== 0; }
  GetObfuscated() {
    return 'if not Stk[Inst[OP_A]] then InstrPoint=InstrPoint+1;else InstrPoint=InstrPoint+Inst[OP_B];end;';
  }
  Mutate(i) {
    i.B = i.Chunk.Instructions[i.PC + 1].B + 1;
    i.InstructionType = InstructionType.AsBxC;
  }
}

// --- OpTestSet.cs ---
class OpTestSet extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.TestSet && i.C === 0; }
  GetObfuscated() {
    return 'local B=Stk[Inst[OP_B]];if B then InstrPoint=InstrPoint+1;else Stk[Inst[OP_A]]=B;InstrPoint=InstrPoint+Instr[InstrPoint+1][OP_B]+1;end;';
  }
}
class OpTestSetC extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.TestSet && i.C !== 0; }
  GetObfuscated() {
    return 'local B=Stk[Inst[OP_B]];if not B then InstrPoint=InstrPoint+1;else Stk[Inst[OP_A]]=B;InstrPoint=InstrPoint+Instr[InstrPoint+1][OP_B]+1;end;';
  }
}

// --- OpUnm.cs ---
class OpUnm extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.Unm; }
  GetObfuscated() { return 'Stk[Inst[OP_A]]=-Stk[Inst[OP_B]];'; }
}

// --- OpVarArg.cs ---
class OpVarArg extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.VarArg && i.B !== 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];local B=Inst[OP_B];for Idx=A,A+B-1 do Stk[Idx]=Vararg[Idx-A];end;';
  }
}
class OpVarArgB0 extends VOpcode {
  IsInstruction(i) { return i.OpCode === Opcode.VarArg && i.B === 0; }
  GetObfuscated() {
    return 'local A=Inst[OP_A];Top=A+Varargsz-1;for Idx=A,Top do local VA=Vararg[Idx-A];Stk[Idx]=VA;end;';
  }
}

const ALL_VOPCODE_CLASSES = [
  OpAdd, OpAddB, OpAddC, OpAddBC,
  OpCall, OpCallB0, OpCallB1, OpCallC0, OpCallC1, OpCallB0C0, OpCallB0C1, OpCallB1C0, OpCallB1C1,
  OpClose,
  OpClosure, OpClosureNU,
  OpConcat,
  OpDiv, OpDivB, OpDivC, OpDivBC,
  OpEq, OpEqB, OpEqC, OpEqBC,
  OpForLoop,
  OpForPrep,
  OpGe, OpGeB, OpGeC, OpGeBC,
  OpGetGlobal,
  OpGetTable, OpGetTableConst,
  OpGetUpval,
  OpGt, OpGtB, OpGtC, OpGtBC,
  OpJmp,
  OpLe, OpLeB, OpLeC, OpLeBC,
  OpLen,
  OpLoadBool, OpLoadBoolC,
  OpLoadK,
  OpLoadNil,
  OpLt, OpLtB, OpLtC, OpLtBC,
  OpMod, OpModB, OpModC, OpModBC,
  OpMove,
  OpMul, OpMulB, OpMulC, OpMulBC,
  OpMutated,
  OpNe, OpNeB, OpNeC, OpNeBC,
  OpNewStk,
  OpNewTableB0, OpNewTableB5000, OpNewTableBElse,
  OpNot,
  OpPow, OpPowB, OpPowC, OpPowBC,
  OpPushStk,
  OpReturn, OpReturnB0, OpReturnB1,
  OpSelf, OpSelfC,
  OpSetFEnv,
  OpSetGlobal,
  OpSetList, OpSetListC1, OpSetListB0, OpSetListC0, OpSetListB0C0, OpSetListB0C1,
  OpSetTable, OpSetTableB, OpSetTableC, OpSetTableBC,
  OpSetTop,
  OpSetUpval,
  OpSub, OpSubB, OpSubC, OpSubBC,
  OpSuperOperator,
  OpTForLoop,
  OpTailCall, OpTailCallB0, OpTailCallB1,
  OpTest, OpTestC,
  OpTestSet, OpTestSetC,
  OpUnm,
  OpVarArg, OpVarArgB0,
];

// ============================================================================
// 7. Control Flow Passes (CFContext.cs, CFGenerator.cs, Types/*.cs)
// ============================================================================

class CFGenerator {
  NextJMP(lc, reference) {
    return new Instruction(lc, Opcode.Jmp, reference);
  }

  BelievableRandom(lc) {
    const ins = new Instruction(lc, randInt(0, 37));
    ins.A = randInt(0, 128);
    ins.B = randInt(0, 128);
    ins.C = randInt(0, 128);

    while (true) {
      switch (ins.OpCode) {
        case Opcode.LoadConst:
        case Opcode.GetGlobal:
        case Opcode.SetGlobal:
        case Opcode.Jmp:
        case Opcode.ForLoop:
        case Opcode.TForLoop:
        case Opcode.ForPrep:
        case Opcode.Closure:
        case Opcode.GetTable:
        case Opcode.SetTable:
        case Opcode.Add:
        case Opcode.Sub:
        case Opcode.Mul:
        case Opcode.Div:
        case Opcode.Mod:
        case Opcode.Pow:
        case Opcode.Test:
        case Opcode.TestSet:
        case Opcode.Eq:
        case Opcode.Lt:
        case Opcode.Le:
        case Opcode.Self:
          ins.OpCode = randInt(0, 37);
          continue;
        default:
          return ins;
      }
    }
  }

  GetOrAddConstant(chunk, type, constant) {
    const current = chunk.Constants.find((c) => c.Type === type && c.Data === constant);
    if (current) {
      return { constant: current, constantIndex: chunk.Constants.indexOf(current) };
    }
    const newConst = new Constant();
    newConst.Type = type;
    newConst.Data = constant;
    const constantIndex = chunk.Constants.length;
    chunk.Constants.push(newConst);
    chunk.ConstantMap.set(newConst, constantIndex);
    return { constant: newConst, constantIndex };
  }
}

class Bounce {
  static DoInstructions(chunk, instructions) {
    const list = instructions.slice();
    const cfGen = new CFGenerator();
    for (const l of list) {
      if (l.OpCode !== Opcode.Jmp) continue;
      const first = cfGen.NextJMP(chunk, l.RefOperands[0]);
      chunk.Instructions.push(first);
      l.RefOperands[0] = first;
    }
    chunk.UpdateMappings();
  }
}

class EQMutate {
  static DoInstructions(chunk, instructions) {
    const cfGen = new CFGenerator();
    chunk.UpdateMappings();
    for (const l of instructions) {
      if (l.OpCode !== Opcode.Eq) continue;

      const lIdx = chunk.InstructionMap.get(l);
      const target = chunk.Instructions[lIdx + 1].RefOperands[0];
      const target2 = chunk.Instructions[lIdx + 2];

      const newLt = new Instruction(l);
      newLt.OpCode = Opcode.Lt;
      newLt.A = l.A;

      const newLe = new Instruction(l);
      newLe.OpCode = Opcode.Le;
      newLe.A = l.A === 0 ? 1 : 0;

      const j1 = cfGen.NextJMP(chunk, target2);
      const j2 = cfGen.NextJMP(chunk, target2);
      const j3 = cfGen.NextJMP(chunk, target);

      chunk.Instructions.splice(lIdx, 0, newLt, j1, newLe, j2, j3);
      chunk.UpdateMappings();
      for (const i of chunk.Instructions) i.UpdateRegisters();

      const curLIdx = chunk.InstructionMap.get(l);
      const j = chunk.Instructions[curLIdx + 1];

      const idx1 = chunk.Instructions.indexOf(l);
      if (idx1 !== -1) chunk.Instructions.splice(idx1, 1);
      const idx2 = chunk.Instructions.indexOf(j);
      if (idx2 !== -1) chunk.Instructions.splice(idx2, 1);

      for (const br of l.BackReferences) br.RefOperands[0] = newLt;
      for (const br of j.BackReferences) br.RefOperands[0] = newLt;
      chunk.UpdateMappings();
    }
  }
}

class TestFlip {
  static DoInstructions(chunk, instructions) {
    const list = instructions.slice();
    const generator = new CFGenerator();

    for (let idx = list.length - 1; idx >= 0; idx--) {
      const i = list[idx];
      switch (i.OpCode) {
        case Opcode.Lt:
        case Opcode.Le:
        case Opcode.Eq:
          if (randInt(0, 2) === 1 && list[idx + 2]) {
            i.A = i.A === 0 ? 1 : 0;
            const nJmp = generator.NextJMP(chunk, list[idx + 2]);
            chunk.Instructions.splice(chunk.InstructionMap.get(i) + 1, 0, nJmp);
            chunk.UpdateMappings();
          }
          break;
        case Opcode.Test:
          if (randInt(0, 2) === 1 && list[idx + 2]) {
            i.C = i.C === 0 ? 1 : 0;
            const nJmp = generator.NextJMP(chunk, list[idx + 2]);
            chunk.Instructions.splice(chunk.InstructionMap.get(i) + 1, 0, nJmp);
            chunk.UpdateMappings();
          }
          break;
      }
    }
    chunk.UpdateMappings();
    for (const inst of chunk.Instructions) {
      inst.UpdateRegisters();
    }
  }
}

class TestPreserve {
  static DoInstructions(chunk, instructions) {
    const used = [];
    const nIntND = (min, max) => {
      const x = [];
      for (let v = min; v < max; v++) {
        if (!used.includes(v)) x.push(v);
      }
      shuffleArray(x);
      const n = x[0];
      used.push(n);
      return n;
    };

    for (let idx = 0; idx < instructions.length; idx++) {
      used.length = 0;
      const i = instructions[idx];
      switch (i.OpCode) {
        case Opcode.Lt:
        case Opcode.Le:
        case Opcode.Eq: {
          const mReg1 = 250;
          const mReg2 = 251;
          let ma, mb;
          if (i.RefOperands[0] instanceof Constant) {
            ma = new Instruction(chunk, Opcode.LoadConst, i.RefOperands[0]);
            ma.A = mReg1;
          } else {
            ma = new Instruction(chunk, Opcode.Move);
            ma.A = mReg1;
            ma.B = i.B;
          }
          if (i.RefOperands[1] instanceof Constant) {
            mb = new Instruction(chunk, Opcode.LoadConst, i.RefOperands[1]);
            mb.A = mReg2;
          } else {
            mb = new Instruction(chunk, Opcode.Move);
            mb.A = mReg2;
            mb.B = i.C;
          }

          const loadbool1 = new Instruction(chunk, Opcode.LoadBool);
          loadbool1.A = mReg1;
          loadbool1.B = 0;
          const loadbool2 = new Instruction(chunk, Opcode.LoadBool);
          loadbool2.A = mReg2;
          loadbool2.B = 0;

          i.B = mReg1;
          i.C = mReg2;
          i.SetupRefs();

          chunk.Instructions.splice(
            chunk.InstructionMap.get(i) + 2,
            0,
            new Instruction(loadbool1),
            new Instruction(loadbool2)
          );
          chunk.Instructions.splice(chunk.InstructionMap.get(i), 0, ma, mb);
          chunk.UpdateMappings();

          const jmpTarget = chunk.Instructions[chunk.InstructionMap.get(i) + 1].RefOperands[0];
          chunk.Instructions.splice(
            chunk.InstructionMap.get(jmpTarget),
            0,
            loadbool1,
            loadbool2
          );
          chunk.Instructions[chunk.InstructionMap.get(i) + 1].RefOperands[0] = loadbool1;
          chunk.UpdateMappings();

          for (const ins of i.BackReferences) ins.RefOperands[0] = ma;
          break;
        }
        case Opcode.Test:
        case Opcode.TestSet: {
          const rReg = nIntND(0, 128);
          const pReg = nIntND(257, 512);

          const m1 = new Instruction(chunk, Opcode.Move);
          m1.A = pReg;
          m1.B = rReg;
          const m2 = new Instruction(chunk, Opcode.Move);
          m2.A = rReg;
          m2.B = i.A;
          const lb = new Instruction(chunk, Opcode.LoadBool);
          lb.A = pReg;
          lb.B = 0;
          const m3 = new Instruction(chunk, Opcode.Move);
          m3.A = rReg;
          m3.B = pReg;

          chunk.Instructions.splice(
            chunk.InstructionMap.get(i) + 2,
            0,
            new Instruction(m3),
            new Instruction(lb)
          );
          chunk.Instructions.splice(chunk.InstructionMap.get(i), 0, m1, m2);
          chunk.UpdateMappings();

          const jmpTarget = chunk.Instructions[chunk.InstructionMap.get(i) + 1].RefOperands[0];
          chunk.Instructions.splice(chunk.InstructionMap.get(jmpTarget), 0, m3, lb);
          chunk.Instructions[chunk.InstructionMap.get(i) + 1].RefOperands[0] = m3;
          chunk.UpdateMappings();

          for (const ins of i.BackReferences) ins.RefOperands[0] = m1;
          break;
        }
      }
    }
  }
}

class TestSpam {
  static DoInstructions(chunk, instructions) {
    const list = instructions.slice();
    const cg = new CFGenerator();

    for (let i = list.length - 1; i >= 0; i--) {
      const instr = list[i];
      switch (instr.OpCode) {
        case Opcode.Eq:
        case Opcode.Lt:
        case Opcode.Le:
        case Opcode.Test:
        case Opcode.TestSet: {
          const addTVGroup = (test) => {
            const cmp1 = new Instruction(test);
            const target1 = chunk.Instructions[chunk.InstructionMap.get(test) + 1];
            const jmpCorrect1 = cg.NextJMP(chunk, target1.RefOperands[0]);
            const jmpJunk1 = cg.NextJMP(chunk, list[Math.max(0, randInt(0, i - 2))]);
            target1.RefOperands[0] = cmp1;
            chunk.Instructions.push(cmp1, jmpCorrect1, jmpJunk1);

            const cmp2 = new Instruction(test);
            const target2 = chunk.Instructions[chunk.InstructionMap.get(test) + 2];
            const jmpCorrect2 = cg.NextJMP(chunk, target2);
            const jmpJunk2 = cg.NextJMP(chunk, list[Math.max(0, randInt(0, i - 2))]);
            const jmpStart2 = cg.NextJMP(chunk, cmp2);
            chunk.Instructions.splice(chunk.InstructionMap.get(target2), 0, jmpStart2);
            chunk.Instructions.push(cmp2, jmpJunk2, jmpCorrect2);

            chunk.UpdateMappings();
            return [cmp1, cmp2];
          };

          let tv1 = addTVGroup(instr);
          for (let j = 0; j < 3; j++) {
            const tv2 = [];
            for (const ins of tv1) {
              tv2.push(...addTVGroup(ins));
            }
            tv1 = tv2;
          }
          break;
        }
      }
    }
    chunk.UpdateMappings();
  }
}

class Inlining {
  constructor(chunk) {
    this._head = chunk;
  }

  ShouldInline(target, inlined) {
    const calls = [];
    const closures = [];
    let inlineAll = false;

    if (inlined.Instructions.length < 3) {
      return { should: false, calls, closures, inlineAll };
    }
    if (
      inlined.Instructions[0].OpCode !== Opcode.GetGlobal ||
      inlined.Instructions[1].OpCode !== Opcode.LoadBool ||
      inlined.Instructions[2].OpCode !== Opcode.Call
    ) {
      return { should: false, calls, closures, inlineAll };
    }
    const cRef = inlined.Instructions[0].RefOperands[0];
    if (!cRef || String(cRef.Data) !== 'IB_INLINING_START') {
      return { should: false, calls, closures, inlineAll };
    }

    inlineAll = inlined.Instructions[1].B === 1;
    for (let k = 0; k < 3; k++) {
      inlined.Instructions[k].OpCode = Opcode.Move;
      inlined.Instructions[k].A = 0;
      inlined.Instructions[k].B = 0;
    }

    const cIdx = inlined.Constants.indexOf(cRef);
    if (cIdx !== -1) inlined.Constants.splice(cIdx, 1);

    if (target.StackSize + inlined.StackSize + 1 > 255) {
      return { should: false, calls, closures, inlineAll };
    }
    if (
      inlined.Instructions.some(
        (i) => i.OpCode === Opcode.GetUpval || i.OpCode === Opcode.SetUpval
      )
    ) {
      return { should: false, calls, closures, inlineAll };
    }

    const registers = new Array(256).fill(false);
    let res = false;

    for (let i = 0; i < target.Instructions.length; i++) {
      const instr = target.Instructions[i];
      switch (instr.OpCode) {
        case Opcode.Move:
          registers[instr.A] = registers[instr.B];
          break;
        case Opcode.LoadNil:
        case Opcode.Unm:
        case Opcode.Not:
        case Opcode.Len:
        case Opcode.TestSet:
          registers[instr.A] = false;
          registers[instr.B] = false;
          break;
        case Opcode.LoadConst:
        case Opcode.LoadBool:
        case Opcode.GetGlobal:
        case Opcode.SetGlobal:
        case Opcode.Return:
        case Opcode.VarArg:
        case Opcode.Test:
        case Opcode.ForPrep:
        case Opcode.ForLoop:
        case Opcode.TForLoop:
        case Opcode.NewTable:
        case Opcode.SetList:
        case Opcode.Close:
        case Opcode.GetTable:
        case Opcode.SetTable:
        case Opcode.Add:
        case Opcode.Sub:
        case Opcode.Mul:
        case Opcode.Div:
        case Opcode.Mod:
        case Opcode.Pow:
        case Opcode.Concat:
        case Opcode.Self:
          registers[instr.A] = false;
          break;
        case Opcode.Closure:
          if (instr.RefOperands[0] === inlined) {
            closures.push(instr);
            registers[instr.A] = true;
          }
          break;
        case Opcode.Call:
        case Opcode.TailCall: {
          let limit = instr.A + instr.C - 1;
          if (instr.C === 0) limit = target.StackSize;
          if (registers[instr.A]) {
            calls.push(instr);
            res = true;
          }
          for (let c = instr.A; c <= limit; c++) registers[c] = false;
          break;
        }
      }
    }
    return { should: res, calls, closures, inlineAll };
  }

  DoChunk(chunk) {
    for (const sub of chunk.Functions.slice()) {
      this.DoChunk(sub);
      const { should, calls: locations, closures, inlineAll } = this.ShouldInline(chunk, sub);
      if (should) {
        if (inlineAll) {
          const sIdx = chunk.Functions.indexOf(sub);
          if (sIdx !== -1) chunk.Functions.splice(sIdx, 1);
        }

        for (const loc of locations) {
          let target = loc.A + loc.B + 1;
          if (loc.B === 0) target = chunk.StackSize + 1;

          sub.Rebase(target, target);

          const modified = [];
          let idx = chunk.Instructions.indexOf(loc);
          chunk.Instructions.splice(idx, 1);

          for (const bRef of loc.BackReferences) bRef.SetupRefs();
          chunk.UpdateMappings();

          const next = chunk.Instructions[idx];
          let lim = sub.ParameterCount - 1;
          if (loc.B === 0) lim = chunk.StackSize - loc.A;

          for (let i = 0; i <= lim; i++) {
            const mv = new Instruction(chunk, Opcode.Move);
            mv.A = target + i;
            mv.B = loc.A + i + 1;
            chunk.Instructions.splice(idx++, 0, mv);
          }

          const map = new Map();
          let done = false;
          for (let i = 0; i < sub.Instructions.length; i++) {
            const orig = sub.Instructions[i];
            const instr = new Instruction(orig);
            instr.Chunk = chunk;
            map.set(orig, instr);

            switch (instr.OpCode) {
              case Opcode.Return: {
                let callLimit = loc.C - 1;
                if (callLimit === -1) callLimit = instr.B - 2;
                if (callLimit <= -1) callLimit = sub.StackSize;

                const t = [];
                for (let j = 0; j <= callLimit; j++) {
                  const mv = new Instruction(chunk, Opcode.Move);
                  mv.A = loc.A + j;
                  mv.B = instr.A + j;
                  t.push(mv);
                }
                const setTop = new Instruction(chunk, Opcode.SetTop);
                setTop.A = loc.A + callLimit;
                t.push(setTop);
                t.push(new Instruction(chunk, Opcode.Jmp, next));

                map.set(orig, t[0]);
                modified.push(...t);
                done = true;
                break;
              }
              case Opcode.TailCall: {
                let callLimit = loc.C - 1;
                if (callLimit === -1) callLimit = instr.B - 1;
                if (callLimit === -1) callLimit = chunk.StackSize - loc.A + 1;

                const t = [];
                for (let j = 0; j <= callLimit; j++) {
                  const mv = new Instruction(chunk, Opcode.Move);
                  mv.A = loc.A + j;
                  mv.B = instr.A + j;
                  t.push(mv);
                }
                instr.OpCode = Opcode.Call;
                instr.A = loc.A;
                t.push(instr);
                t.push(new Instruction(chunk, Opcode.Jmp, next));

                map.set(orig, t[0]);
                modified.push(...t);
                done = true;
                break;
              }
              default:
                modified.push(instr);
                break;
            }
            if (done) break;
          }

          chunk.Instructions.splice(idx, 0, ...modified);

          for (const [k, mapped] of map.entries()) {
            mapped.BackReferences = [];
            for (let i = 0; i < k.BackReferences.length; i++) {
              const br = map.get(k.BackReferences[i]);
              if (br) mapped.BackReferences.push(br);
            }
            if (k.RefOperands[0] instanceof Instruction) {
              mapped.RefOperands[0] = map.get(k.RefOperands[0]) || k.RefOperands[0];
            }
          }
        }

        chunk.UpdateMappings();
        for (const clos of closures) {
          const cPos = chunk.InstructionMap.get(clos);
          if (cPos !== undefined) {
            chunk.Instructions.splice(cPos, clos.RefOperands[0].UpvalueCount + 1);
            for (const bRef of clos.BackReferences) bRef.SetupRefs();
          }
        }

        for (const c of sub.Constants) {
          let nc = chunk.Constants.find((c2) => c2.Type === c.Type && c2.Data === c.Data);
          if (!nc) {
            nc = new Constant(c);
            chunk.Constants.push(nc);
          }
          for (const inst of chunk.Instructions) {
            if (inst.RefOperands[0] === c) inst.RefOperands[0] = nc;
            if (inst.RefOperands[1] === c) inst.RefOperands[1] = nc;
          }
        }

        for (const c of sub.Functions) chunk.Functions.push(c);
        chunk.UpdateMappings();
        for (const _ins of chunk.Instructions) _ins.UpdateRegisters();
      }
    }
  }

  DoChunks() {
    this.DoChunk(this._head);
  }
}

class CFContext {
  constructor(lChunk) {
    this.lChunk = lChunk;
  }

  DoChunk(c) {
    let chunkHasCflow = false;
    let CBegin = null;

    const instructs = c.Instructions.slice();
    for (let index = 0; index < instructs.length - 1; index++) {
      const instr = instructs[index];
      if (instr.OpCode === Opcode.GetGlobal && instructs[index + 1].OpCode === Opcode.Call) {
        const str = instr.RefOperands[0] ? String(instr.RefOperands[0].Data) : '';
        let do_ = false;

        switch (str) {
          case 'IB_MAX_CFLOW_START':
            CBegin = instr;
            do_ = true;
            chunkHasCflow = true;
            break;
          case 'IB_MAX_CFLOW_END': {
            do_ = true;
            let cBegin = c.InstructionMap.get(CBegin);
            let cEnd = c.InstructionMap.get(instr);
            let nIns = c.Instructions.slice(cBegin, cEnd);

            TestSpam.DoInstructions(c, nIns);

            cBegin = c.InstructionMap.get(CBegin);
            cEnd = c.InstructionMap.get(instr);
            nIns = c.Instructions.slice(cBegin, cEnd);

            Bounce.DoInstructions(c, nIns);

            cBegin = c.InstructionMap.get(CBegin);
            cEnd = c.InstructionMap.get(instr);
            nIns = c.Instructions.slice(cBegin, cEnd);

            TestPreserve.DoInstructions(c, nIns);
            EQMutate.DoInstructions(c, c.Instructions.slice());
            break;
          }
        }

        if (do_) {
          instr.OpCode = Opcode.Move;
          instr.A = 0;
          instr.B = 0;
          const call = instructs[index + 1];
          call.OpCode = Opcode.Move;
          call.A = 0;
          call.B = 0;
        }
      }
    }

    TestFlip.DoInstructions(c, c.Instructions.slice());

    if (chunkHasCflow) {
      c.Instructions.unshift(new Instruction(c, Opcode.NewStack));
      c.UpdateMappings();
      for (const inst of c.Instructions) inst.UpdateRegisters();
    }

    for (const _c of c.Functions) {
      this.DoChunk(_c);
    }
  }

  DoChunks() {
    new Inlining(this.lChunk).DoChunks();
    this.DoChunk(this.lChunk);
  }
}

// ============================================================================
// 8. ConstantEncryption & Decryptor (ConstantEncryption.cs)
// ============================================================================

class Decryptor {
  constructor(name, maxLen) {
    this.Name = name;
    this.SLen = 0;
    const len = Math.max(1, maxLen);
    this.Table = Array.from({ length: len }, () => randInt(0, 256));
  }

  Encrypt(bytes) {
    const L = this.Table.length;
    const encrypted = [];
    for (let i = 0; i < bytes.length; i++) {
      encrypted.push((bytes[i] ^ this.Table[i % L]) & 0xff);
    }
    const tableEscaped = this.Table.map((t) => '\\' + t).join('');
    const encEscaped = encrypted.map((t) => '\\' + t).join('');
    return `((function(b)IB_INLINING_START(true);local function xor(b,c)IB_INLINING_START(true);local d,e=1,0;while b>0 and c>0 do local f,g=b%2,c%2;if f~=g then e=e+d end;b,c,d=(b-f)/2,(c-g)/2,d*2 end;if b<c then b=c end;while b>0 do local f=b%2;if f>0 then e=e+d end;b,d=(b-f)/2,d*2 end;return e end;local c=""local e=string.sub;local h=string.char;local t = {} for j=0, 255 do local x=h(j);t[j]=x;t[x]=j;end;local f="${tableEscaped}" for g=1,#b do local x=(g-1) % ${this.Table.length}+1 c=c..t[xor(t[e(b,g,g)],t[e(f, x, x)])];end;return c;end)("${encEscaped}"))`;
  }
}

class ConstantEncryption {
  constructor(settings, source) {
    this._settings = settings;
    this._src = source;
  }

  static UnescapeLuaString(str) {
    const bytes = [];
    let i = 0;
    while (i < str.length) {
      const cur = str[i++];
      if (cur === '\\' && i < str.length) {
        const next = str[i++];
        switch (next) {
          case 'a': bytes.push(7); break;
          case 'b': bytes.push(8); break;
          case 'f': bytes.push(12); break;
          case 'n': bytes.push(10); break;
          case 'r': bytes.push(13); break;
          case 't': bytes.push(9); break;
          case 'v': bytes.push(11); break;
          case 'z':
            while (i < str.length && (str[i] === ' ' || str[i] === '\t' || str[i] === '\r' || str[i] === '\n' || str[i] === '\f' || str[i] === '\v')) {
              i++;
            }
            break;
          case 'x': {
            const hex = str.slice(i, i + 2);
            if (/^[0-9a-fA-F]{2}$/.test(hex)) {
              bytes.push(parseInt(hex, 16) & 0xff);
              i += 2;
            } else {
              bytes.push('x'.charCodeAt(0));
            }
            break;
          }
          case 'u': {
            if (str[i] === '{') {
              const closeIdx = str.indexOf('}', i + 1);
              if (closeIdx !== -1) {
                const hex = str.slice(i + 1, closeIdx);
                const cp = parseInt(hex, 16);
                if (!Number.isNaN(cp)) {
                  const utf8Buf = Buffer.from(String.fromCodePoint(cp), 'utf8');
                  for (let b of utf8Buf) bytes.push(b);
                }
                i = closeIdx + 1;
                break;
              }
            }
            bytes.push('u'.charCodeAt(0));
            break;
          }
          default:
            if (next < '0' || next > '9') {
              bytes.push(next.charCodeAt(0) & 0xff);
            } else {
              let s = next;
              for (let j = 0; j < 2 && i < str.length; j++) {
                const n = str[i];
                if (n >= '0' && n <= '9') {
                  s += n;
                  i++;
                } else {
                  break;
                }
              }
              bytes.push(parseInt(s, 10) & 0xff);
            }
            break;
        }
      } else {
        bytes.push(cur.charCodeAt(0) & 0xff);
      }
    }
    return Buffer.from(bytes);
  }

  static FindLuaStrings(src) {
    // Matches both short quoted strings ('...', "...") and long bracket strings ([=[...]=])
    // while ignoring comments (--... and --[=[...]=])
    const matches = [];
    let i = 0;
    const len = src.length;

    while (i < len) {
      // Check for comment
      if (src[i] === '-' && src[i + 1] === '-') {
        i += 2;
        if (src[i] === '[') {
          let eq = 0;
          let k = i + 1;
          while (k < len && src[k] === '=') { eq++; k++; }
          if (src[k] === '[') {
            const closeSeq = ']' + '='.repeat(eq) + ']';
            const endIdx = src.indexOf(closeSeq, k + 1);
            i = endIdx === -1 ? len : endIdx + closeSeq.length;
            continue;
          }
        }
        while (i < len && src[i] !== '\n') i++;
        continue;
      }

      // Check for quoted string
      if (src[i] === '"' || src[i] === "'") {
        const quote = src[i];
        const start = i++;
        let body = '';
        while (i < len && src[i] !== quote) {
          if (src[i] === '\\' && i + 1 < len) {
            body += src[i] + src[i + 1];
            i += 2;
          } else {
            body += src[i++];
          }
        }
        if (i < len && src[i] === quote) i++;
        matches.push({ index: start, length: i - start, isShort: true, content: body });
        continue;
      }

      // Check for long string [=[...]=]
      if (src[i] === '[') {
        let eq = 0;
        let k = i + 1;
        while (k < len && src[k] === '=') { eq++; k++; }
        if (src[k] === '[') {
          const start = i;
          const closeSeq = ']' + '='.repeat(eq) + ']';
          const endIdx = src.indexOf(closeSeq, k + 1);
          if (endIdx !== -1) {
            let content = src.slice(k + 1, endIdx);
            if (content.startsWith('\r\n')) content = content.slice(2);
            else if (content.startsWith('\n')) content = content.slice(1);
            i = endIdx + closeSeq.length;
            matches.push({ index: start, length: i - start, isShort: false, content });
            continue;
          }
        }
      }

      i++;
    }
    return matches;
  }

  GenerateGenericDecryptor(matches) {
    let len = 0;
    for (const m of matches) {
      if (m.length > len) len = m.length;
    }
    if (len > this._settings.DecryptTableLen) {
      len = this._settings.DecryptTableLen;
    }
    return new Decryptor('IRONBREW_STR_DEC_GENERIC', Math.max(1, len));
  }

  EncryptStrings() {
    let matches = ConstantEncryption.FindLuaStrings(this._src);

    if (this._settings.EncryptStrings && matches.length > 0) {
      const dec = this.GenerateGenericDecryptor(matches);
      let indDiff = 0;
      for (const m of matches) {
        const before = this._src.slice(0, m.index + indDiff);
        const after = this._src.slice(m.index + indDiff + m.length);
        let captured = m.content;
        if (captured.startsWith('[STR_ENCRYPT]')) {
          captured = captured.slice(13);
        }
        const rawBytes = m.isShort
          ? ConstantEncryption.UnescapeLuaString(captured)
          : latin1ToBuffer(captured);
        const nStr = before + dec.Encrypt(rawBytes) + after;
        indDiff += nStr.length - this._src.length;
        this._src = nStr;
      }
    } else {
      let indDiff = 0;
      let n = 0;
      for (const m of matches) {
        let captured = m.content;
        if (!captured.startsWith('[STR_ENCRYPT]')) continue;
        captured = captured.slice(13);
        const dec = new Decryptor('IRONBREW_STR_ENCRYPT' + n++, m.length);
        const before = this._src.slice(0, m.index + indDiff);
        const after = this._src.slice(m.index + indDiff + m.length);
        const rawBytes = m.isShort
          ? ConstantEncryption.UnescapeLuaString(captured)
          : latin1ToBuffer(captured);
        const nStr = before + dec.Encrypt(rawBytes) + after;
        indDiff += nStr.length - this._src.length;
        this._src = nStr;
      }
    }

    if (this._settings.EncryptImportantStrings) {
      matches = ConstantEncryption.FindLuaStrings(this._src);
      let indDiff = 0;
      let n = 0;
      const sTerms = ['http', 'function', 'metatable', 'local'];

      for (const m of matches) {
        let captured = m.content;
        if (captured.startsWith('[STR_ENCRYPT]')) {
          captured = captured.slice(13);
        }
        const lower = captured.toLowerCase();
        if (!sTerms.some((term) => lower.includes(term))) continue;

        const dec = new Decryptor('IRONBREW_STR_ENCRYPT_IMPORTANT' + n++, m.length);
        const before = this._src.slice(0, m.index + indDiff);
        const after = this._src.slice(m.index + indDiff + m.length);
        const rawBytes = m.isShort
          ? ConstantEncryption.UnescapeLuaString(captured)
          : latin1ToBuffer(captured);
        const nStr = before + dec.Encrypt(rawBytes) + after;
        indDiff += nStr.length - this._src.length;
        this._src = nStr;
      }
    }

    return this._src;
  }
}

// ============================================================================
// 9. VM Generation (VMStrings.cs & Generator.cs)
// ============================================================================

const VMStrings = Object.freeze({
  Watermark: '-- Ironbrew 1 https://discord.gg/BPwXUwAMbF\n',
  VMP1: `
local Pos = 1;

local function gBits32()
    local W, X, Y, Z = Byte(ByteString, Pos, Pos + 3);

	W = BitXOR(W, XOR_KEY)
	X = BitXOR(X, XOR_KEY)
	Y = BitXOR(Y, XOR_KEY)
	Z = BitXOR(Z, XOR_KEY)

    Pos	= Pos + 4;
    return (Z*16777216) + (Y*65536) + (X*256) + W;
end;

local function gBits8()
    local F = BitXOR(Byte(ByteString, Pos, Pos), XOR_KEY);
    Pos = Pos + 1;
    return F;
end;

local function gFloat()
	local Left = gBits32();
	local Right = gBits32();
	local IsNormal = 1;
	local Mantissa = (gBit(Right, 1, 20) * (2 ^ 32))
					+ Left;
	local Exponent = gBit(Right, 21, 31);
	local Sign = ((-1) ^ gBit(Right, 32));
	if (Exponent == 0) then
		if (Mantissa == 0) then
			return Sign * 0; -- +-0
		else
			Exponent = 1;
			IsNormal = 0;
		end;
	elseif (Exponent == 2047) then
        return (Mantissa == 0) and (Sign * (1 / 0)) or (Sign * (0 / 0));
	end;
	return LDExp(Sign, Exponent - 1023) * (IsNormal + (Mantissa / (2 ^ 52)));
end;

local gSizet = gBits32;
local function gString(Len)
    local Str;
    if (not Len) then
        Len = gSizet();
        if (Len == 0) then
            return '';
        end;
    end;

    Str	= Sub(ByteString, Pos, Pos + Len - 1);
    Pos = Pos + Len;

	local FStr = {}
	for Idx = 1, #Str do
		FStr[Idx] = Char(BitXOR(Byte(Sub(Str, Idx, Idx)), XOR_KEY))
	end

    return Concat(FStr);
end;

local gInt = gBits32;

local _VM_CTbl = {
    alloc = function(n) return (table and table.create and table.create(n)) or {} end,
    move  = function(src, a, b, t, dst)
        if table and table.move then return table.move(src, a, b, t, dst) end;
        local d = dst or src;
        for idx = a, b do d[t + (idx - a)] = src[idx] end;
        return d;
    end,
    freeze = function(t) return (table and table.freeze and table.freeze(t)) or t end
};
local function Deserialize()
    local Instrs = _VM_CTbl.alloc(INSTR_NUM);
    local Functions = _VM_CTbl.alloc(FUNC_NUM);
	local Lines = {};
    local Chunk = 
	{
		Instrs,
		nil,
		Functions,
		nil,
		Lines
	};`,

  VMP2: `
local function Wrap(Chunk, Upvalues, Env)
	local Instr  = Chunk[1];
	local Const  = Chunk[2];
	local Proto  = Chunk[3];
	local Params = Chunk[4];

	return function(...)
		local Instr  = Instr; 
		local Const  = Const; 
		local Proto  = Proto; 
		local Params = Params;

		local _R = _R
		local InstrPoint = 1;
		local Top = -1;

		local Vararg = {};
		local Args	= {...};

		local PCount = Select('#', ...) - 1;

		local Lupvals	= {};
		local Stk		= {};

		for Idx = 0, PCount do
			if (Idx >= Params) then
				Vararg[Idx - Params] = Args[Idx + 1];
			else
				Stk[Idx] = Args[Idx + 1];
			end;
		end;

		local Varargsz = PCount - Params + 1

		local Inst;
		local Enum;	

		while true do
			Inst		= Instr[InstrPoint];
			Enum		= Inst[OP_ENUM];`,

  VMP3: `
			InstrPoint	= InstrPoint + 1;
		end;
	end;
end;
H[AZT] = Wrap;
return Wrap;
`,

  VMP2_LI: `
local PCall = pcall
local function Wrap(Chunk, Upvalues, Env)
	local Instr = Chunk[1];
	local Const = Chunk[2];
	local Proto = Chunk[3];
	local Params = Chunk[4];

	return function(...)
		local InstrPoint = 1;
		local Top = -1;

		local Args = {...};
		local PCount = Select('#', ...) - 1;

		local function Loop()
			local Instr  = Instr; 
			local Const  = Const; 
			local Proto  = Proto; 
			local Params = Params;

			local _R = _R
			local Vararg = {};

			local Lupvals	= {};
			local Stk		= {};
	
			for Idx = 0, PCount do
				if (Idx >= Params) then
					Vararg[Idx - Params] = Args[Idx + 1];
				else
					Stk[Idx] = Args[Idx + 1];
				end;
			end;
	
			local Varargsz = PCount - Params + 1

			local Inst;
			local Enum;	

			while true do
				Inst		= Instr[InstrPoint];
				Enum		= Inst[OP_ENUM];`,

  VMP3_LI: `
				InstrPoint	= InstrPoint + 1;
			end;
		end;

		local A, B = _R(PCall(Loop))
		if not A[1] then
			local line = Chunk[5][InstrPoint] or '?'
			error('ERROR IN IRONBREW SCRIPT [LINE ' .. line .. ']:' .. A[2])
		else
			return Unpack(A, 2, B)
		end;
	end;
end;
H[AZT] = Wrap;
return Wrap;
`,
});

const crypto = require('crypto');

class RuntimePayloadEncoder {
  static applyRollingStreamCipher(buf, seedKey) {
    const out = Buffer.allocUnsafe(buf.length);
    let state = (seedKey & 0xff) || 0x5a;
    for (let i = 0; i < buf.length; i++) {
      state = ((state * 167 + 113 + (i & 0xff)) & 0xff);
      out[i] = (buf[i] ^ state) & 0xff;
    }
    return out;
  }



  static rotl32(x, r) {
    r &= 31;
    if (r === 0) return x >>> 0;
    return (((x << r) | (x >>> (32 - r))) >>> 0);
  }

  static rotr32(x, r) {
    r &= 31;
    if (r === 0) return x >>> 0;
    return (((x >>> r) | (x << (32 - r))) >>> 0);
  }

  static getPath2DProbes() {
    // 32 exact IEEE-754 float32 / uint32 geometry probes from Roblox Studio Path2D (Frame 237x290)
    return [
      { u32: 0x43AE3815, mode: 81 },  // 1. p2d:GetLength()
      { u32: 0x3E3FE023, mode: 81 },  // 2a. Pos(7/8).X.Scale
      { u32: 0x3D537B96, mode: 60 },  // 2b. Pos(7/8).Y.Scale
      { u32: 0x3EDF9BBB, mode: 81 },  // 3a. Pos(4/11).X.Scale
      { u32: 0x3ECB78E2, mode: 60 },  // 3b. Pos(4/11).Y.Scale
      { u32: 0x3E1CBED7, mode: 81 },  // 4a. Pos(4/5).X.Scale
      { u32: 0x3E8B98BC, mode: 60 },  // 5a. PosArc(0.75).X.Scale
      { u32: 0x3D307EC9, mode: 60 },  // 4b. Pos(4/5).Y.Scale
      { u32: 0x3DF9CDA4, mode: 81 },  // 5b. PosArc(0.75).Y.Scale
      { u32: 0x41BC47B8, mode: 81 },  // 6a. Tan(4/5).X
      { u32: 0x41B28F59, mode: 81 },  // 6b. Tan(4/5).Y
      { u32: 0xC2C26DB7, mode: 60 },  // 7a. Tan(3/7).X
      { u32: 0xC347B6DC, mode: 60 },  // 7b. Tan(3/7).Y
      { u32: 0x41BD0000, mode: 60 },  // 8a. Tan(1/6).X
      { u32: 0x430F0000, mode: 81 },  // 8b. Tan(1/6).Y
      { u32: 0x3E9D8764, mode: 60 },  // 9a. Pos(6/13).X.Scale
      { u32: 0x3ECABBA4, mode: 60 },  // 10a. Pos(1/13).X.Scale
      { u32: 0x3E75EC0A, mode: 60 },  // 11a. PosArc(0.8).X.Scale
      { u32: 0x3D8B7066, mode: 60 },  // 11b. PosArc(0.8).Y.Scale
      { u32: 0x3EC2966C, mode: 60 },  // 12a. PosArc(7/12).X.Scale
      { u32: 0x3E9A9B07, mode: 81 },  // 12b. PosArc(7/12).Y.Scale
      { u32: 0xC2F8FB47, mode: 81 },  // 13a. TanArc(0.5).X
      { u32: 0x3D53DCB1, mode: 81 },  // 10b. Pos(1/13).Y.Scale
      { u32: 0x421870D4, mode: 60 },  // 14a. TanArc(1/3).X
      { u32: 0x434D5E8D, mode: 81 },  // 14b. TanArc(1/3).Y
      { u32: 0x3E38CE02, mode: 102 }, // 9b. Pos(6/13).Y.Scale
      { u32: 0xC3805C51, mode: 135 }, // 13b. TanArc(0.5).Y
      { u32: 0x4207A4B0, mode: 81 },  // 15a. BoundingRect.Min.X
      { u32: 0x42500000, mode: 60 },  // 15b. BoundingRect.Min.Y
      { u32: 0x42E90000, mode: 102 }, // 15c. BoundingRect.Max.X
      { u32: 0x43470000, mode: 135 }, // 15d. BoundingRect.Max.Y
      { u32: ((237 << 16) | 290) >>> 0, mode: 81 }, // 16. Frame AbsoluteSize (237, 290)
    ];
  }

  static buildPath2DKeyRing1024(seedKey, sha256Buf = null) {
    // Builds a 1024-byte (256 x 32-bit word) rotating key schedule from the 32 Path2D geometry probes
    const probes = RuntimePayloadEncoder.getPath2DProbes();
    const keyRing = Buffer.alloc(1024);
    let byteOffset = 0;

    for (let idx = 0; idx < 32; idx++) {
      const rawU32 = probes[idx].u32 >>> 0;
      const mode = probes[idx].mode;
      const rotShift = ((idx * 7 + (seedKey & 0xff)) % 29) + 1;
      const rotU32 = RuntimePayloadEncoder.rotl32(rawU32, rotShift);

      const b0 = rotU32 & 0xff;
      const b1 = (rotU32 >>> 8) & 0xff;
      const b2 = (rotU32 >>> 16) & 0xff;
      const b3 = (rotU32 >>> 24) & 0xff;

      if (mode === 60) {
        keyRing[byteOffset] = b0; keyRing[byteOffset + 1] = b1; keyRing[byteOffset + 2] = b2; keyRing[byteOffset + 3] = b3;
      } else if (mode === 81) {
        keyRing[byteOffset] = b3; keyRing[byteOffset + 1] = b2; keyRing[byteOffset + 2] = b1; keyRing[byteOffset + 3] = b0;
      } else if (mode === 102) {
        keyRing[byteOffset] = b1; keyRing[byteOffset + 1] = b2; keyRing[byteOffset + 2] = b3; keyRing[byteOffset + 3] = b0;
      } else {
        keyRing[byteOffset] = b2; keyRing[byteOffset + 1] = b1; keyRing[byteOffset + 2] = b0; keyRing[byteOffset + 3] = b3;
      }
      byteOffset += 4;
    }

    if (sha256Buf) {
      for (let i = 0; i < 128; i++) {
        keyRing[i] ^= sha256Buf[i & 31];
      }
    }

    // Expand 32 words (128 bytes) -> 256 words (1024 bytes) with 3-tap bit-rotation schedule
    for (let wIdx = 32; wIdx < 256; wIdx++) {
      const p1 = RuntimePayloadEncoder.rotl32(keyRing.readUInt32LE((wIdx - 32) * 4), (wIdx % 13) + 3);
      const p2 = RuntimePayloadEncoder.rotr32(keyRing.readUInt32LE((wIdx - 19) * 4), (wIdx % 11) + 5);
      const p3 = RuntimePayloadEncoder.rotl32(keyRing.readUInt32LE((wIdx - 7) * 4), (wIdx % 17) + 1);
      const c = ((wIdx * 2654435761 + (seedKey & 0xff)) % 4294967296) >>> 0;
      const mw = RuntimePayloadEncoder.rotl32((p1 ^ p2 ^ p3 ^ c) >>> 0, (wIdx % 7) + 1);
      keyRing.writeUInt32LE(mw >>> 0, wIdx * 4);
    }

    // 4 full ARX/rotation diffusion rounds across all 256 words (1024 bytes)
    for (let round = 1; round <= 4; round++) {
      for (let wIdx = 0; wIdx < 256; wIdx++) {
        const cur = keyRing.readUInt32LE(wIdx * 4);
        const nbr = keyRing.readUInt32LE(((wIdx + 53 * round) & 255) * 4);
        const r1 = RuntimePayloadEncoder.rotr32(nbr, ((round * 5 + wIdx) % 29) + 1);
        const rot = RuntimePayloadEncoder.rotl32((cur ^ r1) >>> 0, ((wIdx + round * 3) % 31) + 1);
        keyRing.writeUInt32LE(rot >>> 0, wIdx * 4);
      }
    }

    return keyRing;
  }

  static applyPath2DRotatingCipher(plainBuf, seedKey, sha256Buf = null) {
    // Prepends 4-byte Path2D integrity tag (0x49, 0x42, 0x32, 0x50 ^ seedKey) and encrypts
    // against the 1024-byte Path2D rotating key schedule.
    const sb = seedKey & 0xff;
    const taggedPlain = Buffer.allocUnsafe(plainBuf.length + 4);
    taggedPlain[0] = (0x49 ^ sb) & 0xff;
    taggedPlain[1] = (0x42 ^ sb) & 0xff;
    taggedPlain[2] = (0x32 ^ sb) & 0xff;
    taggedPlain[3] = (0x50 ^ sb) & 0xff;
    plainBuf.copy(taggedPlain, 4);

    const keyRing = RuntimePayloadEncoder.buildPath2DKeyRing1024(seedKey, sha256Buf);
    const out = Buffer.allocUnsafe(taggedPlain.length);
    let acc = (sb * 0x01010101) >>> 0;

    for (let i = 0; i < taggedPlain.length; i++) {
      if ((i & 3) === 0) {
        const wSlot = (i >>> 2) & 255;
        const pSlot = ((i >>> 2) + 101) & 255;
        const wA = keyRing.readUInt32LE(wSlot * 4);
        const wB = keyRing.readUInt32LE(pSlot * 4);
        const nextW = RuntimePayloadEncoder.rotl32(
          (wA ^ RuntimePayloadEncoder.rotr32(wB, ((i >>> 2) % 19) + 1)) >>> 0,
          ((i >>> 2) % 13) + 1
        );
        keyRing.writeUInt32LE(nextW >>> 0, wSlot * 4);
        acc = RuntimePayloadEncoder.rotl32((acc ^ nextW) >>> 0, 5);
      }
      const kByte = keyRing[i & 1023];
      const accByte = (acc >>> ((i & 3) * 8)) & 0xff;
      out[i] = (taggedPlain[i] ^ kByte ^ accByte) & 0xff;
    }

    return out;
  }

  static generateCustomBufferAndTableAPILua() {
    return `
local _CTbl = {
    alloc = function(n) return (table and table.create and table.create(n)) or {} end,
    clear = function(t) if table and table.clear then table.clear(t) else for k in Next, t do t[k] = nil end end end,
    move  = function(src, a, b, dstOff, dst)
        if table and table.move then return table.move(src, a, b, dstOff, dst) end;
        local d = dst or src;
        for idx = a, b do d[dstOff + (idx - a)] = src[idx] end;
        return d;
    end,
    freeze = function(t) return (table and table.freeze and table.freeze(t)) or t end,
    pack   = function(...) return (table and table.pack and table.pack(...)) or { n = Select('#', ...), ... } end,
    unpack = (table and table.unpack) or Unpack,
    pushQ  = function(t, b0, b1, b2, b3)
        local n = #t;
        t[n + 1] = b0; t[n + 2] = b1; t[n + 3] = b2; t[n + 4] = b3;
    end
};
local _CBuf = {
    alloc   = function(sz) return { _b = buffer.create(sz), _l = sz, _p = 0 } end,
    fromStr = function(s) return { _b = buffer.fromstring(s), _l = #s, _p = 0 } end,
    toStr   = function(cb) return buffer.tostring(cb._b) end,
    len     = function(cb) return buffer.len(cb._b) end,
    rB      = function(cb, off) return buffer.readu8(cb._b, off) end,
    wB      = function(cb, off, v) buffer.writeu8(cb._b, off, v) end,
    rW      = function(cb, off) return buffer.readu32(cb._b, off) end,
    wW      = function(cb, off, v) buffer.writeu32(cb._b, off, v) end,
    wF      = function(cb, off, v) buffer.writef32(cb._b, off, v) end,
    pushRotF = function(scratch4, keyTbl, slotIdx, val, modeFlag, seedByte)
        buffer.writef32(scratch4._b, 0, val);
        local rawU32 = buffer.readu32(scratch4._b, 0);
        local shift = ((slotIdx * 7 + seedByte) % 29) + 1;
        local rotU32 = bit32.lrotate(rawU32, shift);
        buffer.writeu32(scratch4._b, 0, rotU32);
        local b0 = buffer.readu8(scratch4._b, 0);
        local b1 = buffer.readu8(scratch4._b, 1);
        local b2 = buffer.readu8(scratch4._b, 2);
        local b3 = buffer.readu8(scratch4._b, 3);
        if modeFlag == 60 then
            _CTbl.pushQ(keyTbl, b0, b1, b2, b3);
        elseif modeFlag == 81 then
            _CTbl.pushQ(keyTbl, b3, b2, b1, b0);
        elseif modeFlag == 102 then
            _CTbl.pushQ(keyTbl, b1, b2, b3, b0);
        else
            _CTbl.pushQ(keyTbl, b2, b1, b0, b3);
        end;
    end,
    pushRotW = function(scratch4, keyTbl, slotIdx, rawU32, modeFlag, seedByte)
        local shift = ((slotIdx * 7 + seedByte) % 29) + 1;
        local rotU32 = bit32.lrotate(rawU32, shift);
        buffer.writeu32(scratch4._b, 0, rotU32);
        local b0 = buffer.readu8(scratch4._b, 0);
        local b1 = buffer.readu8(scratch4._b, 1);
        local b2 = buffer.readu8(scratch4._b, 2);
        local b3 = buffer.readu8(scratch4._b, 3);
        if modeFlag == 81 then
            _CTbl.pushQ(keyTbl, b3, b2, b1, b0);
        else
            _CTbl.pushQ(keyTbl, b0, b1, b2, b3);
        end;
    end
};
`;
  }

  static generatePath2DKeyRingLua(seedKey, shaKeyVar = 'nil') {
    const sb = seedKey & 0xff;
    return `
local function _BuildPath2DKeyRing1024(_OptShaKey)
    local _SG = Instance.new("ScreenGui");
    pcall(function() _SG.Parent = game:GetService("CoreGui") end);
    if not _SG.Parent then
        pcall(function()
            local _Plrs = game:GetService("Players");
            if _Plrs and _Plrs.LocalPlayer then
                _SG.Parent = _Plrs.LocalPlayer:FindFirstChildOfClass("PlayerGui");
            end;
        end);
    end;
    local _FR = Instance.new("Frame");
    _FR.Size = UDim2.new(0, 237, 0, 290);
    _FR.Parent = _SG;
    local _P2D = Instance.new("Path2D");
    _P2D.Parent = _FR;
    _P2D:SetControlPoints({
        Path2DControlPoint.new(UDim2.new(3 / 8, 3, 0, -3), UDim2.new(1 / 8, 4, 0, -2), UDim2.new(0, 2, 1 / 8, -7)),
        Path2DControlPoint.new(UDim2.new(1 / 2, -3, 1 / 2, -5), UDim2.new(0, 0, 0, 0), UDim2.new(0, 0, 0, 0)),
        Path2DControlPoint.new(UDim2.new(1 / 4, -10, 0, 5), UDim2.new(0, -3, 0, -8), UDim2.new(-(1 / 8), -7, 0, 0)),
        Path2DControlPoint.new(UDim2.new(3 / 16, 8, 0, -5), UDim2.new(0, 6, 1 / 8, 2), UDim2.new(0, 0, 0, 0))
    });

    local _Scratch4 = _CBuf.alloc(4);
    local _SeedBytes = _CTbl.alloc(128);

    local _LVal = _P2D:GetLength();
    local _P7_8 = _P2D:GetPositionOnCurve(7 / 8);
    local _P4_11 = _P2D:GetPositionOnCurve(4 / 11);
    local _P4_5 = _P2D:GetPositionOnCurve(4 / 5);
    local _PArc75 = _P2D:GetPositionOnCurveArcLength(3 / 4);
    local _T4_5 = _P2D:GetTangentOnCurve(4 / 5);
    local _T3_7 = _P2D:GetTangentOnCurve(3 / 7);
    local _T1_6 = _P2D:GetTangentOnCurve(1 / 6);
    local _P6_13 = _P2D:GetPositionOnCurve(6 / 13);
    local _P1_13 = _P2D:GetPositionOnCurve(1 / 13);
    local _PArc80 = _P2D:GetPositionOnCurveArcLength(4 / 5);
    local _PArc7_12 = _P2D:GetPositionOnCurveArcLength(7 / 12);
    local _TArc50 = _P2D:GetTangentOnCurveArcLength(1 / 2);
    local _TArc1_3 = _P2D:GetTangentOnCurveArcLength(1 / 3);
    local _Rect = _P2D:GetBoundingRect();
    local _AbsX, _AbsY = _FR.AbsoluteSize.X, _FR.AbsoluteSize.Y;
    _SG:Destroy();

    -- Extract 32 rotated 32-bit probes (128 bytes) into _SeedBytes via _CBuf & _CTbl
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 0,  _LVal, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 1,  _P7_8.X.Scale, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 2,  _P7_8.Y.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 3,  _P4_11.X.Scale, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 4,  _P4_11.Y.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 5,  _P4_5.X.Scale, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 6,  _PArc75.X.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 7,  _P4_5.Y.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 8,  _PArc75.Y.Scale, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 9,  _T4_5.X, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 10, _T4_5.Y, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 11, _T3_7.X, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 12, _T3_7.Y, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 13, _T1_6.X, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 14, _T1_6.Y, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 15, _P6_13.X.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 16, _P1_13.X.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 17, _PArc80.X.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 18, _PArc80.Y.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 19, _PArc7_12.X.Scale, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 20, _PArc7_12.Y.Scale, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 21, _TArc50.X, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 22, _P1_13.Y.Scale, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 23, _TArc1_3.X, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 24, _TArc1_3.Y, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 25, _P6_13.Y.Scale, 102, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 26, _TArc50.Y, 135, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 27, _Rect.Min.X, 81, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 28, _Rect.Min.Y, 60, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 29, _Rect.Max.X, 102, ${sb});
    _CBuf.pushRotF(_Scratch4, _SeedBytes, 30, _Rect.Max.Y, 135, ${sb});
    _CBuf.pushRotW(_Scratch4, _SeedBytes, 31, bit32.bor(bit32.lshift(_AbsX, 16), _AbsY), 81, ${sb});

    -- Allocate 1024-byte (256 x 32-bit word) KeyRing buffer
    local _KeyRing = _CBuf.alloc(1024);
    for _Idx = 0, 127 do
        local _B = _SeedBytes[_Idx + 1];
        if _OptShaKey then
            _B = bit32.bxor(_B, Byte(_OptShaKey, (_Idx % 32) + 1));
        end;
        _CBuf.wB(_KeyRing, _Idx, _B);
    end;
    _CTbl.clear(_SeedBytes);

    -- Expand 32 words (128 bytes) -> 256 words (1024 bytes) with 3-tap bit-rotation
    for _WIdx = 32, 255 do
        local _P1 = bit32.lrotate(_CBuf.rW(_KeyRing, (_WIdx - 32) * 4), (_WIdx % 13) + 3);
        local _P2 = bit32.rrotate(_CBuf.rW(_KeyRing, (_WIdx - 19) * 4), (_WIdx % 11) + 5);
        local _P3 = bit32.lrotate(_CBuf.rW(_KeyRing, (_WIdx - 7) * 4), (_WIdx % 17) + 1);
        local _C  = (_WIdx * 2654435761 + ${sb}) % 4294967296;
        local _MW = bit32.lrotate(bit32.bxor(_P1, _P2, _P3, _C), (_WIdx % 7) + 1);
        _CBuf.wW(_KeyRing, _WIdx * 4, _MW);
    end;

    -- 4 Full ARX / Bit-Rotation Diffusion Rounds across all 256 words (1024 bytes)
    for _Rnd = 1, 4 do
        for _WIdx = 0, 255 do
            local _Cur = _CBuf.rW(_KeyRing, _WIdx * 4);
            local _Nbr = _CBuf.rW(_KeyRing, ((_WIdx + 53 * _Rnd) % 256) * 4);
            local _R1  = bit32.rrotate(_Nbr, ((_Rnd * 5 + _WIdx) % 29) + 1);
            local _Rot = bit32.lrotate(bit32.bxor(_Cur, _R1), ((_WIdx + _Rnd * 3) % 31) + 1);
            _CBuf.wW(_KeyRing, _WIdx * 4, _Rot);
        end;
    end;

    return _KeyRing;
end;

local function _DecryptWithPath2DKeyRing(_EncRawBuf, _KeyRing)
    local _Len = buffer.len(_EncRawBuf);
    local _OutTbl = _CTbl.alloc(_Len - 4);
    local _Acc = ${(sb * 0x01010101) >>> 0};
    local _T0, _T1, _T2, _T3;
    for _Idx = 0, _Len - 1 do
        if (_Idx % 4) == 0 then
            local _Step = _Idx / 4;
            local _WSlot = _Step % 256;
            local _PSlot = (_Step + 101) % 256;
            local _WA = _CBuf.rW(_KeyRing, _WSlot * 4);
            local _WB = _CBuf.rW(_KeyRing, _PSlot * 4);
            local _NextW = bit32.lrotate(bit32.bxor(_WA, bit32.rrotate(_WB, (_Step % 19) + 1)), (_Step % 13) + 1);
            _CBuf.wW(_KeyRing, _WSlot * 4, _NextW);
            _Acc = bit32.lrotate(bit32.bxor(_Acc, _NextW), 5);
        end;
        local _KByte = _CBuf.rB(_KeyRing, _Idx % 1024);
        local _AccByte = bit32.band(bit32.rshift(_Acc, (_Idx % 4) * 8), 255);
        local _PByte = bit32.bxor(buffer.readu8(_EncRawBuf, _Idx), _KByte, _AccByte);
        if _Idx < 4 then
            if _Idx == 0 then _T0 = _PByte
            elseif _Idx == 1 then _T1 = _PByte
            elseif _Idx == 2 then _T2 = _PByte
            else
                _T3 = _PByte;
                if _T0 ~= ${(0x49 ^ sb) & 0xff} or _T1 ~= ${(0x42 ^ sb) & 0xff} or _T2 ~= ${(0x32 ^ sb) & 0xff} or _T3 ~= ${(0x50 ^ sb) & 0xff} then
                    error("IRONBREW_PATH2D_INTEGRITY_VIOLATION");
                end;
            end;
        else
            _OutTbl[_Idx - 3] = Char(_PByte);
        end;
    end;
    return Concat(_OutTbl);
end;
`;
  }

  static packZstdFrame(rawBuf) {
    // Valid RFC-8878 Zstandard frame with Single_Segment_Flag = 1 and 4-byte FCS (0xA0)
    // Magic: 0xFD2FB528 (LE: 28 B5 2F FD)
    // Frame_Header_Descriptor: 0xA0 (FCS_Field_Size = 2 -> 4 bytes, Single_Segment_Flag = 1)
    const chunks = [];
    const header = Buffer.allocUnsafe(9);
    header[0] = 0x28;
    header[1] = 0xb5;
    header[2] = 0x2f;
    header[3] = 0xfd;
    header[4] = 0xa0;
    header.writeUInt32LE(rawBuf.length >>> 0, 5);
    chunks.push(header);

    // Split into Raw_Block chunks (max 128 KB = 131072 bytes per block per RFC-8878)
    const maxBlock = 131072;
    let offset = 0;
    while (offset < rawBuf.length || offset === 0) {
      const rem = rawBuf.length - offset;
      const blkSize = Math.min(rem, maxBlock);
      const isLast = offset + blkSize >= rawBuf.length ? 1 : 0;
      // Block_Header (3 bytes LE): Last_Block (bit 0) | (Block_Type=0 (Raw) << 1) | (Block_Size << 3)
      const blkHdrVal = (isLast & 1) | ((blkSize & 0x1fffff) << 3);
      const blkHdr = Buffer.allocUnsafe(3);
      blkHdr[0] = blkHdrVal & 0xff;
      blkHdr[1] = (blkHdrVal >>> 8) & 0xff;
      blkHdr[2] = (blkHdrVal >>> 16) & 0xff;
      chunks.push(blkHdr);
      if (blkSize > 0) {
        chunks.push(rawBuf.subarray(offset, offset + blkSize));
      }
      offset += blkSize;
      if (offset >= rawBuf.length) break;
    }
    return Buffer.concat(chunks);
  }

  static generateRobloxOnlyLoader(bs, seedKey, settings = null) {
    const placeLock = settings && settings.PlaceLock != null ? String(settings.PlaceLock) : null;
    const gameLock = settings && settings.GameLock != null ? String(settings.GameLock) : null;
    const usePath2D = settings && (settings.Path2DLayer || (settings.RuntimeDecodeMode || '').toLowerCase() === 'path2d');
    const salt = 'RBX_SVC_' + String(seedKey) + '_' + String(bs.length);
    let kdfString = `${salt}::HttpService::EncodingService::Zstd`;
    if (placeLock) kdfString += `::Place=${placeLock}`;
    if (gameLock) kdfString += `::Game=${gameLock}`;
    const sha256Key = crypto.createHash('sha256').update(kdfString, 'latin1').digest();

    let encBuf;
    if (usePath2D) {
      // Final Layer: 1024-byte Path2D Geometry + SHA-256 Rotating Key Ring
      encBuf = RuntimePayloadEncoder.applyPath2DRotatingCipher(bs, seedKey, sha256Key);
    } else {
      encBuf = Buffer.allocUnsafe(bs.length);
      let st = sha256Key[0] ^ (seedKey & 0xff);
      for (let i = 0; i < bs.length; i++) {
        const kByte = sha256Key[i & 31];
        st = (st * 167 + kByte + (i & 0xff)) & 0xff;
        encBuf[i] = (bs[i] ^ st ^ kByte) & 0xff;
      }
    }

    const zstdFrame = RuntimePayloadEncoder.packZstdFrame(encBuf);
    const b64Payload = zstdFrame.toString('base64');
    const jsonEnvelope = JSON.stringify({
      v: 270,
      s: salt,
      n: bs.length,
      p: b64Payload,
    });
    const escapedJson = jsonEnvelope.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

    if (usePath2D) {
      return (
        RuntimePayloadEncoder.generateCustomBufferAndTableAPILua() +
        RuntimePayloadEncoder.generatePath2DKeyRingLua(seedKey) +
        `
local _HS = game:GetService("HttpService");
local _ES = game:GetService("EncodingService");
local _Pkt = _HS:JSONDecode('${escapedJson}');
local _KdfInput = _Pkt.s .. "::" .. _HS.ClassName .. "::" .. _ES.ClassName .. "::" .. Enum.CompressionAlgorithm.Zstd.Name${placeLock ? ' .. "::Place=" .. tostring(game.PlaceId)' : ''}${gameLock ? ' .. "::Game=" .. tostring(game.GameId)' : ''};
local _ShaKey = _ES:ComputeStringHash(_KdfInput, Enum.HashAlgorithm.Sha256);
local _ZstdBuf = _ES["Base64Decode"](_ES, buffer.fromstring(_Pkt.p));
local _EncBuf = _ES:DecompressBuffer(_ZstdBuf, Enum.CompressionAlgorithm.Zstd);
local _KeyRing1024 = _BuildPath2DKeyRing1024(_ShaKey);
local ByteString = _DecryptWithPath2DKeyRing(_EncBuf, _KeyRing1024);
`
      );
    }

    return (
      RuntimePayloadEncoder.generateCustomBufferAndTableAPILua() +
      `
local _HS = game:GetService("HttpService");
local _ES = game:GetService("EncodingService");
local _Pkt = _HS:JSONDecode('${escapedJson}');
local _KdfInput = _Pkt.s .. "::" .. _HS.ClassName .. "::" .. _ES.ClassName .. "::" .. Enum.CompressionAlgorithm.Zstd.Name${placeLock ? ' .. "::Place=" .. tostring(game.PlaceId)' : ''}${gameLock ? ' .. "::Game=" .. tostring(game.GameId)' : ''};
local _ShaKey = _ES:ComputeStringHash(_KdfInput, Enum.HashAlgorithm.Sha256);
local _ZstdBuf = _ES["Base64Decode"](_ES, buffer.fromstring(_Pkt.p));
local _EncBuf = _ES:DecompressBuffer(_ZstdBuf, Enum.CompressionAlgorithm.Zstd);
local _Len = buffer.len(_EncBuf);
local _Out = _CTbl.alloc(_Len);
local _St = bit32.bxor(Byte(_ShaKey, 1), ${seedKey & 0xff});
for _Idx = 0, _Len - 1 do
    local _KByte = Byte(_ShaKey, (_Idx % 32) + 1);
    _St = (_St * 167 + _KByte + (_Idx % 256)) % 256;
    local _CipherByte = buffer.readu8(_EncBuf, _Idx);
    _Out[_Idx + 1] = Char(bit32.bxor(bit32.bxor(_CipherByte, _St), _KByte));
end;
local ByteString = Concat(_Out);
`
    );
  }

  static generateEncodingServiceLoader(bs, seedKey, strictRoblox = false) {
    const encBuf = RuntimePayloadEncoder.applyRollingStreamCipher(bs, seedKey);
    const b64 = encBuf.toString('base64');

    if (strictRoblox) {
      return `
local _ES = game:GetService("EncodingService");
local _B64 = "${b64}";
local _RawBuf = _ES["Base64Decode"](_ES, buffer.fromstring(_B64));
local _Len = buffer.len(_RawBuf);
local _OutParts = {};
local _St = ${(seedKey & 0xff) || 0x5a};
for _Idx = 0, _Len - 1 do
    _St = (_St * 167 + 113 + (_Idx % 256)) % 256;
    _OutParts[_Idx + 1] = Char(bit32.bxor(buffer.readu8(_RawBuf, _Idx), _St));
end;
local ByteString = Concat(_OutParts);
`;
    }

    return `
local _B64 = "${b64}";
local function _DecodePayload(b64)
    local function _gs(s) return game and game.GetService and game:GetService(s) end; local ok, es = pcall(_gs, "EncodingService");
    local rawStr;
    if ok and es and buffer and buffer.fromstring then
        local b = es["Base64Decode"](es, buffer.fromstring(b64));
        rawStr = buffer.tostring(b);
    else
        local map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        local lut = {};
        for idx = 1, #map do lut[Byte(map, idx)] = idx - 1; end;
        local out = {};
        local n = 0;
        local bits = 0;
        for idx = 1, #b64 do
            local v = lut[Byte(b64, idx)];
            if v then
                n = n * 64 + v;
                bits = bits + 6;
                if bits >= 8 then
                    bits = bits - 8;
                    local byteVal = (n - (n % (2 ^ bits))) / (2 ^ bits);
                    n = n % (2 ^ bits);
                    out[#out + 1] = Char(byteVal % 256);
                end;
            end;
        end;
        rawStr = Concat(out);
    end;
    local res = {};
    local st = ${(seedKey & 0xff) || 0x5a};
    local bx = (bit32 and bit32.bxor) or (bit and bit.bxor);
    for idx = 1, #rawStr do
        st = (st * 167 + 113 + ((idx - 1) % 256)) % 256;
        local bVal = Byte(rawStr, idx);
        if bx then
            res[idx] = Char(bx(bVal, st));
        else
            local a, b, p, c = bVal, st, 1, 0;
            while a > 0 and b > 0 do
                local ra, rb = a % 2, b % 2;
                if ra ~= rb then c = c + p end;
                a, b, p = (a - ra) / 2, (b - rb) / 2, p * 2;
            end;
            if a < b then a = b end;
            while a > 0 do
                local ra = a % 2;
                if ra > 0 then c = c + p end;
                a, p = (a - ra) / 2, p * 2;
            end;
            res[idx] = Char(c);
        end;
    end;
    return Concat(res);
end;
local ByteString = _DecodePayload(_B64);
`;
  }

  static generateHttpServiceLoader(bs, seedKey, strictRoblox = false) {
    // Pack bytes into 32-bit signed integers with rolling XOR mask inside a JSON payload
    const words = [];
    const len = bs.length;
    let mask = (seedKey * 1103515245 + 12345) & 0x7fffffff;
    for (let i = 0; i < len; i += 4) {
      const b0 = bs[i] || 0;
      const b1 = bs[i + 1] || 0;
      const b2 = bs[i + 2] || 0;
      const b3 = bs[i + 3] || 0;
      const u32 = ((b0) | (b1 << 8) | (b2 << 16) | (b3 << 24)) >>> 0;
      mask = ((mask * 214013 + 2531011) & 0x7fffffff) >>> 0;
      const enc = (u32 ^ mask) >>> 0;
      words.push(enc);
    }
    const jsonPayload = JSON.stringify({ n: len, s: seedKey, d: words });
    const escapedJson = jsonPayload.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

    if (strictRoblox) {
      return `
local _HS = game:GetService("HttpService");
local _Pkt = _HS:JSONDecode('${escapedJson}');
local _Words = _Pkt.d;
local _Total = _Pkt.n;
local _Mask = (_Pkt.s * 1103515245 + 12345) % 2147483648;
local _Parts = {};
local _OutIdx = 1;
for _Idx = 1, #_Words do
    _Mask = (_Mask * 214013 + 2531011) % 2147483648;
    local _Val = bit32.bxor(_Words[_Idx], _Mask);
    local _B0 = _Val % 256; _Val = (_Val - _B0) / 256;
    local _B1 = _Val % 256; _Val = (_Val - _B1) / 256;
    local _B2 = _Val % 256; _Val = (_Val - _B2) / 256;
    local _B3 = _Val % 256;
    if _OutIdx <= _Total then _Parts[_OutIdx] = Char(_B0); _OutIdx = _OutIdx + 1; end;
    if _OutIdx <= _Total then _Parts[_OutIdx] = Char(_B1); _OutIdx = _OutIdx + 1; end;
    if _OutIdx <= _Total then _Parts[_OutIdx] = Char(_B2); _OutIdx = _OutIdx + 1; end;
    if _OutIdx <= _Total then _Parts[_OutIdx] = Char(_B3); _OutIdx = _OutIdx + 1; end;
end;
local ByteString = Concat(_Parts);
`;
    }

    return `
local _JSON = '${escapedJson}';
local function _DecodeHttpPayload(rawJson)
    local function _gs(s) return game and game.GetService and game:GetService(s) end; local ok, hs = pcall(_gs, "HttpService");
    local total, seed, words;
    if ok and hs then
        local pkt = hs:JSONDecode(rawJson);
        total, seed, words = pkt.n, pkt.s, pkt.d;
    else
        total = ToNumber(rawJson:match('"n":(%d+)'));
        seed = ToNumber(rawJson:match('"s":(%d+)'));
        words = {};
        local arrStr = rawJson:match('"d":%[(.-)%]');
        for num in arrStr:gmatch('(%d+)') do
            words[#words + 1] = ToNumber(num);
        end;
    end;
    local mask = (seed * 1103515245 + 12345) % 2147483648;
    local parts = {};
    local outIdx = 1;
    local bx = (bit32 and bit32.bxor) or (bit and bit.bxor);
    for idx = 1, #words do
        mask = (mask * 214013 + 2531011) % 2147483648;
        local val;
        if bx then
            val = bx(words[idx], mask);
            if val < 0 then val = val + 4294967296 end;
        else
            local a, b, p, c = words[idx], mask, 1, 0;
            while a > 0 and b > 0 do
                local ra, rb = a % 2, b % 2;
                if ra ~= rb then c = c + p end;
                a, b, p = (a - ra) / 2, (b - rb) / 2, p * 2;
            end;
            if a < b then a = b end;
            while a > 0 do
                local ra = a % 2;
                if ra > 0 then c = c + p end;
                a, p = (a - ra) / 2, p * 2;
            end;
            val = c;
        end;
        local b0 = val % 256; val = (val - b0) / 256;
        local b1 = val % 256; val = (val - b1) / 256;
        local b2 = val % 256; val = (val - b2) / 256;
        local b3 = val % 256;
        if outIdx <= total then parts[outIdx] = Char(b0); outIdx = outIdx + 1; end;
        if outIdx <= total then parts[outIdx] = Char(b1); outIdx = outIdx + 1; end;
        if outIdx <= total then parts[outIdx] = Char(b2); outIdx = outIdx + 1; end;
        if outIdx <= total then parts[outIdx] = Char(b3); outIdx = outIdx + 1; end;
    end;
    return Concat(parts);
end;
local ByteString = _DecodeHttpPayload(_JSON);
`;
  }

  static generateHybridLoader(bs, seedKey, strictRoblox = false) {
    // Hybrid mode:
    // 1. Salt + Key derivation via EncodingService:ComputeStringHash (SHA-256 first byte) or fallback
    // 2. Outer envelope via HttpService:JSONDecode
    // 3. Inner payload via EncodingService:Base64Decode + buffer + bit32
    const salt = 'IB2_RBLX_' + String(seedKey);
    const shaHash = crypto.createHash('sha256').update(salt, 'latin1').digest();
    const derivedByte = shaHash[0] ^ (seedKey & 0xff);
    const encBuf = RuntimePayloadEncoder.applyRollingStreamCipher(bs, derivedByte);
    const b64 = encBuf.toString('base64');
    const envelope = JSON.stringify({
      v: 270,
      k: salt,
      h: derivedByte,
      p: b64,
    });
    const escapedEnv = envelope.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

    if (strictRoblox) {
      return `
local _HS = game:GetService("HttpService");
local _ES = game:GetService("EncodingService");
local _Env = _HS:JSONDecode('${escapedEnv}');
local _Hash = _ES:ComputeStringHash(_Env.k, Enum.HashAlgorithm.Sha256);
local _Seed = bit32.bxor(Byte(_Hash, 1), ${seedKey & 0xff});
local _RawBuf = _ES["Base64Decode"](_ES, buffer.fromstring(_Env.p));
local _Len = buffer.len(_RawBuf);
local _Parts = {};
local _St = (_Seed % 256);
if _St == 0 then _St = 90 end;
for _Idx = 0, _Len - 1 do
    _St = (_St * 167 + 113 + (_Idx % 256)) % 256;
    _Parts[_Idx + 1] = Char(bit32.bxor(buffer.readu8(_RawBuf, _Idx), _St));
end;
local ByteString = Concat(_Parts);
`;
    }

    return `
local _ENV_JSON = '${escapedEnv}';
local function _DecodeHybrid(envJson)
    local function _gs(s) return game and game.GetService and game:GetService(s) end;
    local okH, hs = pcall(_gs, "HttpService");
    local okE, es = pcall(_gs, "EncodingService");
    local salt, b64, dByte;
    if okH and hs then
        local pkt = hs:JSONDecode(envJson);
        salt, b64, dByte = pkt.k, pkt.p, pkt.h;
    else
        salt = envJson:match('"k":"(.-)"');
        dByte = ToNumber(envJson:match('"h":(%d+)'));
        b64 = envJson:match('"p":"(.-)"');
    end;
    if okE and es and Enum and Enum.HashAlgorithm and Enum.HashAlgorithm.Sha256 then
        local hStr = es:ComputeStringHash(salt, Enum.HashAlgorithm.Sha256);
        dByte = bit32.bxor(Byte(hStr, 1), ${seedKey & 0xff});
    end;
    local rawStr;
    if okE and es and buffer and buffer.fromstring then
        rawStr = buffer.tostring(es["Base64Decode"](es, buffer.fromstring(b64)));
    else
        local map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        local lut = {};
        for idx = 1, #map do lut[Byte(map, idx)] = idx - 1; end;
        local out = {};
        local n, bits = 0, 0;
        for idx = 1, #b64 do
            local v = lut[Byte(b64, idx)];
            if v then
                n = n * 64 + v;
                bits = bits + 6;
                if bits >= 8 then
                    bits = bits - 8;
                    local bv = (n - (n % (2 ^ bits))) / (2 ^ bits);
                    n = n % (2 ^ bits);
                    out[#out + 1] = Char(bv % 256);
                end;
            end;
        end;
        rawStr = Concat(out);
    end;
    local st = dByte % 256;
    if st == 0 then st = 90 end;
    local res = {};
    local bx = (bit32 and bit32.bxor) or (bit and bit.bxor);
    for idx = 1, #rawStr do
        st = (st * 167 + 113 + ((idx - 1) % 256)) % 256;
        local bVal = Byte(rawStr, idx);
        if bx then
            res[idx] = Char(bx(bVal, st));
        else
            local a, b, p, c = bVal, st, 1, 0;
            while a > 0 and b > 0 do
                local ra, rb = a % 2, b % 2;
                if ra ~= rb then c = c + p end;
                a, b, p = (a - ra) / 2, (b - rb) / 2, p * 2;
            end;
            if a < b then a = b end;
            while a > 0 do
                local ra = a % 2;
                if ra > 0 then c = c + p end;
                a, p = (a - ra) / 2, p * 2;
            end;
            res[idx] = Char(c);
        end;
    end;
    return Concat(res);
end;
local ByteString = _DecodeHybrid(_ENV_JSON);
`;
  }
}

class Generator {
  constructor(context) {
    this._context = context;
  }

  IsUsed(chunk, virt) {
    let isUsed = false;
    for (const ins of chunk.Instructions) {
      if (virt.IsInstruction(ins)) {
        if (!this._context.InstructionMapping.has(ins.OpCode)) {
          this._context.InstructionMapping.set(ins.OpCode, virt);
        }
        ins.CustomData = new CustomInstructionData(virt, null);
        isUsed = true;
      }
    }
    for (const sChunk of chunk.Functions) {
      if (this.IsUsed(sChunk, virt)) isUsed = true;
    }
    return isUsed;
  }

  static Compress(uncompressed) {
    const dictionary = new Map();
    for (let i = 0; i < 256; i++) {
      dictionary.set(String.fromCharCode(i), i);
    }
    let w = '';
    const compressed = [];
    for (let idx = 0; idx < uncompressed.length; idx++) {
      const b = uncompressed[idx];
      const wc = w + String.fromCharCode(b);
      if (dictionary.has(wc)) {
        w = wc;
      } else {
        compressed.push(dictionary.get(w));
        dictionary.set(wc, dictionary.size);
        w = String.fromCharCode(b);
      }
    }
    if (w.length > 0) {
      compressed.push(dictionary.get(w));
    }
    return compressed;
  }

  static ToBase36(value) {
    const base26 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let v = BigInt(value);
    let out = '';
    do {
      out = base26[Number(v % 26n)] + out;
      v /= 26n;
    } while (v !== 0n);
    return out;
  }

  static CompressedToString(compressed) {
    let sb = '';
    for (const i of compressed) {
      const n = Generator.ToBase36(i);
      sb += Generator.ToBase36(n.length) + n;
    }
    return sb;
  }

  GenerateMutations(opcodes) {
    const mutated = [];
    for (const opc of opcodes) {
      if (opc instanceof OpSuperOperator) continue;
      const count = randInt(35, 50);
      for (let i = 0; i < count; i++) {
        const rand = shuffleArray([0, 1, 2]);
        const mut = new OpMutated();
        mut.Registers = rand;
        mut.Mutated = opc;
        mutated.push(mut);
      }
    }
    shuffleArray(mutated);
    return mutated;
  }

  FoldMutations(mutations, used, chunk) {
    const skip = new Array(chunk.Instructions.length + 1).fill(false);
    for (let i = 0; i < chunk.Instructions.length; i++) {
      const opc = chunk.Instructions[i];
      if (opc.OpCode === Opcode.Closure) {
        const upvCnt = opc.RefOperands[0].UpvalueCount;
        for (let j = 1; j <= upvCnt; j++) {
          skip[i + j] = true;
        }
      }
    }

    for (let i = 0; i < chunk.Instructions.length; i++) {
      if (skip[i]) continue;
      const opc = chunk.Instructions[i];
      const data = opc.CustomData;
      if (!data) continue;
      for (const mut of mutations) {
        if (data.Opcode === mut.Mutated && data.WrittenOpcode == null) {
          if (!used.has(mut)) used.add(mut);
          data.Opcode = mut;
          break;
        }
      }
    }

    for (const _c of chunk.Functions) {
      this.FoldMutations(mutations, used, _c);
    }
  }

  GenerateSuperOperators(chunk, maxSize, minSize = 5) {
    const results = [];
    const skip = new Array(chunk.Instructions.length + 1).fill(false);

    chunk.UpdateMappings();
    for (let i = 0; i < chunk.Instructions.length - 1; i++) {
      const ins = chunk.Instructions[i];
      switch (ins.OpCode) {
        case Opcode.Closure: {
          skip[i] = true;
          const upvCnt = ins.RefOperands[0].UpvalueCount;
          for (let j = 0; j < upvCnt; j++) skip[i + j + 1] = true;
          break;
        }
        case Opcode.Eq:
        case Opcode.Lt:
        case Opcode.Le:
        case Opcode.Test:
        case Opcode.TestSet:
        case Opcode.TForLoop:
        case Opcode.SetList:
          skip[i + 1] = true;
          break;
        case Opcode.LoadBool:
          if (ins.C !== 0) skip[i + 1] = true;
          break;
        case Opcode.ForLoop:
        case Opcode.ForPrep:
        case Opcode.Jmp:
          ins.UpdateRegisters();
          skip[i + 1] = true;
          if (i + ins.B + 1 >= 0 && i + ins.B + 1 <= chunk.Instructions.length) {
            skip[i + ins.B + 1] = true;
          }
          break;
      }
      if (
        ins.CustomData &&
        ins.CustomData.WrittenOpcode instanceof OpSuperOperator &&
        ins.CustomData.WrittenOpcode.SubOpcodes != null
      ) {
        for (let j = 0; j < ins.CustomData.WrittenOpcode.SubOpcodes.length; j++) {
          skip[i + j] = true;
        }
      }
    }

    let c = 0;
    while (c < chunk.Instructions.length) {
      let targetCount = maxSize;
      let superOperator = new OpSuperOperator();
      superOperator.SubOpcodes = new Array(targetCount);

      let d = true;
      let cutoff = targetCount;
      for (let j = 0; j < targetCount; j++) {
        if (c + j > chunk.Instructions.length - 1 || skip[c + j]) {
          cutoff = j;
          d = false;
          break;
        }
      }

      if (!d) {
        if (cutoff < minSize) {
          c += cutoff + 1;
          continue;
        }
        targetCount = cutoff;
        superOperator = new OpSuperOperator();
        superOperator.SubOpcodes = new Array(targetCount);
      }

      for (let j = 0; j < targetCount; j++) {
        superOperator.SubOpcodes[j] = chunk.Instructions[c + j].CustomData.Opcode;
      }
      results.push(superOperator);
      c += targetCount + 1;
    }

    for (const _c of chunk.Functions) {
      results.push(...this.GenerateSuperOperators(_c, maxSize, minSize));
    }
    return results;
  }

  FoldAdditionalSuperOperators(chunk, operators, foldedRef) {
    const skip = new Array(chunk.Instructions.length + 1).fill(false);
    chunk.UpdateMappings();
    for (let i = 0; i < chunk.Instructions.length - 1; i++) {
      const ins = chunk.Instructions[i];
      switch (ins.OpCode) {
        case Opcode.Closure: {
          skip[i] = true;
          const upvCnt = ins.RefOperands[0].UpvalueCount;
          for (let j = 0; j < upvCnt; j++) skip[i + j + 1] = true;
          break;
        }
        case Opcode.Eq:
        case Opcode.Lt:
        case Opcode.Le:
        case Opcode.Test:
        case Opcode.TestSet:
        case Opcode.TForLoop:
        case Opcode.SetList:
          skip[i + 1] = true;
          break;
        case Opcode.LoadBool:
          if (ins.C !== 0) skip[i + 1] = true;
          break;
        case Opcode.ForLoop:
        case Opcode.ForPrep:
        case Opcode.Jmp:
          ins.UpdateRegisters();
          skip[i + 1] = true;
          if (i + ins.B + 1 >= 0 && i + ins.B + 1 <= chunk.Instructions.length) {
            skip[i + ins.B + 1] = true;
          }
          break;
      }
      if (
        ins.CustomData &&
        ins.CustomData.WrittenOpcode instanceof OpSuperOperator &&
        ins.CustomData.WrittenOpcode.SubOpcodes != null
      ) {
        for (let j = 0; j < ins.CustomData.WrittenOpcode.SubOpcodes.length; j++) {
          skip[i + j] = true;
        }
      }
    }

    let c = 0;
    while (c < chunk.Instructions.length) {
      if (skip[c]) {
        c++;
        continue;
      }
      let used = false;
      for (const op of operators) {
        const targetCount = op.SubOpcodes.length;
        let cu = true;
        for (let j = 0; j < targetCount; j++) {
          if (c + j > chunk.Instructions.length - 1 || skip[c + j]) {
            cu = false;
            break;
          }
        }
        if (!cu) continue;

        const taken = chunk.Instructions.slice(c, c + targetCount);
        if (op.IsInstruction(taken)) {
          for (let j = 0; j < targetCount; j++) {
            skip[c + j] = true;
            const dummy = new OpSuperOperator();
            dummy.VIndex = 0;
            chunk.Instructions[c + j].CustomData.WrittenOpcode = dummy;
          }
          chunk.Instructions[c].CustomData.WrittenOpcode = op;
          used = true;
          break;
        }
      }
      if (!used) c++;
      else foldedRef.count++;
    }

    for (const _c of chunk.Functions) {
      this.FoldAdditionalSuperOperators(_c, operators, foldedRef);
    }
  }

  GenerateVM(settings) {
    const virtuals = [];
    for (const Cls of ALL_VOPCODE_CLASSES) {
      const inst = new Cls();
      if (this.IsUsed(this._context.HeadChunk, inst)) {
        virtuals.push(inst);
      }
    }

    if (settings.Mutate) {
      const muts = this.GenerateMutations(virtuals).slice(0, settings.MaxMutations);
      console.log('Created ' + muts.length + ' mutations.');
      const used = new Set();
      this.FoldMutations(muts, used, this._context.HeadChunk);
      console.log('Used ' + used.size + ' mutations.');
      virtuals.push(...used);
    }

    if (settings.SuperOperators) {
      const foldedRef = { count: 0 };
      const megaOperators = shuffleArray(
        this.GenerateSuperOperators(this._context.HeadChunk, 80, 60)
      ).slice(0, settings.MaxMegaSuperOperators);
      console.log('Created ' + megaOperators.length + ' mega super operators.');
      virtuals.push(...megaOperators);
      this.FoldAdditionalSuperOperators(this._context.HeadChunk, megaOperators, foldedRef);

      const miniOperators = shuffleArray(
        this.GenerateSuperOperators(this._context.HeadChunk, 10)
      ).slice(0, settings.MaxMiniSuperOperators);
      console.log('Created ' + miniOperators.length + ' mini super operators.');
      virtuals.push(...miniOperators);
      this.FoldAdditionalSuperOperators(this._context.HeadChunk, miniOperators, foldedRef);

      console.log('Folded ' + foldedRef.count + ' instructions into super operators.');
    }

    shuffleArray(virtuals);
    for (let i = 0; i < virtuals.length; i++) {
      virtuals[i].VIndex = i;
    }

    const bs = new Serializer(this._context, settings).SerializeLChunk(
      this._context.HeadChunk
    );

    const rtMode = (settings.RuntimeDecodeMode || 'lzw').toLowerCase();
    const seedKey = (this._context.PrimaryXorKey ^ this._context.IXorKey1 ^ 0xA5) & 0xff;
    let loaderCode = '';
    let payloadArg = '""';

    if (rtMode === 'roblox-only' || rtMode === 'roblox-exclusive' || rtMode === 'zstd-service' || rtMode === 'path2d' || settings.Path2DLayer) {
      const rawLoader = RuntimePayloadEncoder.generateRobloxOnlyLoader(bs, seedKey, settings);
      const m = rawLoader.match(/JSONDecode\('([^']*)'\)/);
      if (m) {
        payloadArg = `'${m[1]}'`;
        loaderCode = rawLoader.replace(`JSONDecode('${m[1]}')`, 'JSONDecode(AZT)');
      } else {
        loaderCode = rawLoader;
      }
    } else if (rtMode === 'encoding-service' || rtMode === 'encoding') {
      const rawLoader = RuntimePayloadEncoder.generateEncodingServiceLoader(bs, seedKey, settings.RobloxStrict);
      const m = rawLoader.match(/local _B64 = "([^"]*)";/);
      if (m) {
        payloadArg = `"${m[1]}"`;
        loaderCode = rawLoader.replace(`local _B64 = "${m[1]}";`, 'local _B64 = AZT;');
      } else {
        loaderCode = rawLoader;
      }
    } else if (rtMode === 'http-service' || rtMode === 'http' || rtMode === 'json') {
      const rawLoader = RuntimePayloadEncoder.generateHttpServiceLoader(bs, seedKey, settings.RobloxStrict);
      const m1 = rawLoader.match(/JSONDecode\('([^']*)'\)/);
      const m2 = rawLoader.match(/local _JSON = '([^']*)';/);
      if (m1) {
        payloadArg = `'${m1[1]}'`;
        loaderCode = rawLoader.replace(`JSONDecode('${m1[1]}')`, 'JSONDecode(AZT)');
      } else if (m2) {
        payloadArg = `'${m2[1]}'`;
        loaderCode = rawLoader.replace(`local _JSON = '${m2[1]}';`, 'local _JSON = AZT;');
      } else {
        loaderCode = rawLoader;
      }
    } else if (rtMode === 'hybrid' || rtMode === 'roblox-hybrid') {
      const rawLoader = RuntimePayloadEncoder.generateHybridLoader(bs, seedKey, settings.RobloxStrict);
      const m1 = rawLoader.match(/JSONDecode\('([^']*)'\)/);
      const m2 = rawLoader.match(/local _ENV_JSON = '([^']*)';/);
      if (m1) {
        payloadArg = `'${m1[1]}'`;
        loaderCode = rawLoader.replace(`JSONDecode('${m1[1]}')`, 'JSONDecode(AZT)');
      } else if (m2) {
        payloadArg = `'${m2[1]}'`;
        loaderCode = rawLoader.replace(`local _ENV_JSON = '${m2[1]}';`, 'local _ENV_JSON = AZT;');
      } else {
        loaderCode = rawLoader;
      }
    } else if (settings.BytecodeCompress || settings.WrapCompress) {
      loaderCode +=
        'local function decompress(b)local c,d,e="","",{}local f=256;local g={}for h=0,f-1 do g[h]=Char(h)end;local i=1;local baseA=Byte("A");local function k()local l=Byte(b,i)-baseA;i=i+1;local m=0;for idx=i,i+l-1 do m=m*26+(Byte(b,idx)-baseA)end;i=i+l;return m end;c=Char(k())e[1]=c;while i<#b do local n=k()if g[n]then d=g[n]else d=c..Sub(c,1,1)end;g[f]=c..Sub(d,1,1)e[#e+1],c,f=d,d,f+1 end;return Concat(e)end;';
      const layer1 = Generator.CompressedToString(Generator.Compress(bs));
      if (settings.WrapCompress) {
        const layer2 = Generator.CompressedToString(Generator.Compress(Buffer.from(layer1, 'latin1')));
        payloadArg = `'${layer2}'`;
        loaderCode += 'local ByteString=decompress(decompress(AZT));\n';
      } else {
        payloadArg = `'${layer1}'`;
        loaderCode += 'local ByteString=decompress(AZT);\n';
      }
    } else {
      let alphaHex = '';
      for (let i = 0; i < bs.length; i++) {
        const b = bs[i] & 0xff;
        alphaHex += String.fromCharCode(65 + (b >> 4), 65 + (b & 15));
      }
      payloadArg = `'${alphaHex}'`;
      loaderCode += 'local ByteString=_S_DEC(AZT);\n';
    }

    let maxConstants = 0;
    const computeConstants = (c) => {
      if (c.Constants.length > maxConstants) maxConstants = c.Constants.length;
      for (const _c of c.Functions) computeConstants(_c);
    };
    computeConstants(this._context.HeadChunk);

    let deserCode = VMStrings.VMP1.split('XOR_KEY').join(String(this._context.PrimaryXorKey));

    for (let i = 0; i < ChunkStep.StepCount; i++) {
      switch (this._context.ChunkSteps[i]) {
        case ChunkStep.ParameterCount:
          deserCode += 'Chunk[4] = gBits8();';
          break;
        case ChunkStep.Constants:
          deserCode += `
								local ConstCount = gBits32()
    							local Consts = _VM_CTbl.alloc(ConstCount);

								for Idx=1,ConstCount do 
									local Type=gBits8();
									local Cons;
	
									if(Type==${this._context.ConstantMapping[1]}) then Cons=(gBits8() ~= 0);
									elseif(Type==${this._context.ConstantMapping[2]}) then Cons = gFloat();
									elseif(Type==${this._context.ConstantMapping[3]}) then Cons=gString();
									end;
									
									Consts[Idx]=Cons;
								end;
								Chunk[2] = Consts
								`;
          break;
        case ChunkStep.Instructions:
          deserCode += `for Idx=1,gBits32() do 
									local Data1=BitXOR(gBits32(),${this._context.IXorKey1});
									local Data2=BitXOR(gBits32(),${this._context.IXorKey2}); 

									local Type=gBit(Data1,1,2);
									local Opco=gBit(Data2,1,11);
									
									local Inst=
									{
										Opco,
										gBit(Data1,3,11),
										nil,
										nil,
										Data2
									};

									if (Type == 0) then Inst[OP_B]=gBit(Data1,12,20);Inst[OP_C]=gBit(Data1,21,29);
									elseif(Type==1) then Inst[OP_B]=gBit(Data2,12,33);
									elseif(Type==2) then Inst[OP_B]=gBit(Data2,12,32)-1048575;
									elseif(Type==3) then Inst[OP_B]=gBit(Data2,12,32)-1048575;Inst[OP_C]=gBit(Data1,21,29);
									end;
									
									Instrs[Idx]=Inst;end;`;
          break;
        case ChunkStep.Functions:
          deserCode += 'for Idx=1,gBits32() do Functions[Idx-1]=Deserialize();end;';
          break;
        case ChunkStep.LineInfo:
          if (settings.PreserveLineInfo) {
            deserCode += 'for Idx=1,gBits32() do Lines[Idx]=gBits32();end;';
          }
          break;
      }
    }

    deserCode += 'return Chunk;end;';

    let maxFunc = 0;
    const computeFuncs = (c) => {
      if (c.Functions.length > maxFunc) maxFunc = c.Functions.length;
      for (const _c of c.Functions) computeFuncs(_c);
    };
    computeFuncs(this._context.HeadChunk);
    deserCode = deserCode.replace('FUNC_NUM', String(maxFunc));

    let maxInstrs = 0;
    const computeInstrs = (c) => {
      if (c.Instructions.length > maxInstrs) maxInstrs = c.Instructions.length;
      for (const _c of c.Functions) computeInstrs(_c);
    };
    computeInstrs(this._context.HeadChunk);
    deserCode = deserCode.replace('INSTR_NUM', String(maxInstrs));

    const getStr = (opcodes) => {
      let str = '';
      if (opcodes.length === 1) {
        str += `${virtuals[opcodes[0]].GetObfuscated(this._context)}`;
      } else if (opcodes.length === 2) {
        if (randInt(0, 2) === 0) {
          str += `if Enum > ${virtuals[opcodes[0]].VIndex} then ${virtuals[opcodes[1]].GetObfuscated(this._context)}`;
          str += `else ${virtuals[opcodes[0]].GetObfuscated(this._context)}`;
          str += 'end;';
        } else {
          str += `if Enum == ${virtuals[opcodes[0]].VIndex} then ${virtuals[opcodes[0]].GetObfuscated(this._context)}`;
          str += `else ${virtuals[opcodes[1]].GetObfuscated(this._context)}`;
          str += 'end;';
        }
      } else if (opcodes.length > 2) {
        const ordered = opcodes.slice().sort((a, b) => a - b);
        const mid = Math.floor(ordered.length / 2);
        const left = ordered.slice(0, mid);
        const right = ordered.slice(mid);
        str += 'if Enum <= ' + left[left.length - 1] + ' then ';
        str += getStr(left);
        str += ' else';
        str += getStr(right);
      }
      return str;
    };

    const indices = Array.from({ length: virtuals.length }, (_, i) => i);
    const vmLoopCode =
      (settings.PreserveLineInfo ? VMStrings.VMP2_LI : VMStrings.VMP2) +
      getStr(indices) +
      (settings.PreserveLineInfo ? VMStrings.VMP3_LI : VMStrings.VMP3);

    let vm = `return setmetatable({
H = function(AZT, H)
    local function _S_DEC(_str)
        local _out = {};
        local _bA = string.byte("A");
        local _sixteen = #"________________";
        local _idx = #"_";
        for _p = #"_", #_str, #"__" do
            local _hi = string.byte(_str, _p) - _bA;
            local _lo = string.byte(_str, _p + #"_") - _bA;
            _out[_idx] = string.char(_hi * _sixteen + _lo);
            _idx = _idx + #"_";
        end;
        return table.concat(_out);
    end;
    local _N_Z = #"";
    local _N_A = #"_";
    local _N_B = #"__";
    local _N_C = #"___";
    local _N_D = #"____";
    local _N_E = #"_____";
    local _N_F = #"______";
    local Byte = string.byte;
    local Char = string.char;
    local Sub = string.sub;
    local Concat = table.concat;
    local GetFEnv = getfenv or function() return _ENV end;
    local _G_ENV = GetFEnv();
    local BitXOR = (bit32 and bit32.bxor) or (bit and bit.bxor) or function(a,b)
        local p,c=1,0
        while a>0 and b>0 do
            local ra,rb=a%2,b%2
            if ra~=rb then c=c+p end
            a,b,p=(a-ra)/2,(b-rb)/2,p*2
        end
        if a<b then a=b end
        while a>0 do
            local ra=a%2
            if ra>0 then c=c+p end
            a,p=(a-ra)/2,p*2
        end
        return c
    end;
    local function gBit(Bit, Start, End)
        if End then
            local Res = (Bit / 2 ^ (Start - 1)) % 2 ^ ((End - 1) - (Start - 1) + 1);
            return Res - Res % 1;
        else
            local Plc = 2 ^ (Start - 1);
            return (Bit % (Plc + Plc) >= Plc) and 1 or 0;
        end;
    end;
    H.S = _S_DEC;
    H.E = _G_ENV;
    H.X = BitXOR;
    H.B = gBit;
    local _bA = Byte("A");
    local _ba = Byte("a");
    local _rad = Byte("Z") - _bA + _N_A;
    local _pos = _N_A;
    local _m = _N_Z;
    while _pos <= #AZT do
        local _len = Byte(AZT, _pos) - _bA;
        _pos = _pos + _N_A;
        local _val = _N_Z;
        for _i = _pos, _pos + _len - _N_A do
            _val = _val * _rad + (Byte(AZT, _i) - _bA);
        end;
        _pos = _pos + _len;
        local _rZero = _m % _rad;
        local _tOne = (_m - _rZero) / _rad;
        local _rOne = _tOne % _rad;
        local _rTwo = (_tOne - _rOne) / _rad;
        H[Char(_ba + _rTwo, _ba + _rOne, _ba + _rZero)] = _val;
        _m = _m + _N_A;
    end;
    return H;
end,
J = function(AZT, H)
    local function _J_LOAD(AZT, H)
        local _N_Z = #"";
        local _N_A = #"_";
        local _N_B = #"__";
        local _N_C = #"___";
        local _N_D = #"____";
        local _N_E = #"_____";
        local _N_F = #"______";
        local _S_DEC = H.S;
        local _G_ENV = H.E;
        local Byte = string.byte;
        local Char = string.char;
        local Sub = string.sub;
        local Concat = table.concat;
        local Select = select;
        local Next = next;
        local Unpack = unpack or table.unpack;
        local ToNumber = tonumber;
        ${loaderCode}
        return ByteString;
    end;
    H.D = _J_LOAD(AZT, H);
    return H.D;
end,
K = function(AZT, H)
    local function _K_DESER(AZT, H)
        local _N_Z = #"";
        local _N_A = #"_";
        local _N_B = #"__";
        local _N_C = #"___";
        local _N_D = #"____";
        local _N_E = #"_____";
        local _N_F = #"______";
        local _S_DEC = H.S;
        local _G_ENV = H.E;
        local BitXOR = H.X;
        local gBit = H.B;
        local Byte = string.byte;
        local Char = string.char;
        local Sub = string.sub;
        local Concat = table.concat;
        local LDExp = math.ldexp or function(m, e) return m * (_N_B ^ e) end;
        local ByteString = AZT;
        ${deserCode}
        return Deserialize();
    end;
    return _K_DESER(AZT, H);
end
}, {
__index = function(H, AZT)
    local function _R(...) return {...}, select('#', ...) end;
    local _N_Z = #"";
    local _N_A = #"_";
    local _N_B = #"__";
    local _N_C = #"___";
    local _N_D = #"____";
    local _N_E = #"_____";
    local _N_F = #"______";
    local _S_DEC = H.S;
    local _G_ENV = H.E;
    local Select = select;
    local Unpack = unpack or table.unpack;
    local Setmetatable = setmetatable;
    local Getmetatable = getmetatable;
    local Next = next;
    local Type = type;
    ${vmLoopCode}
end,
__call = function(H, ...)
    H.H("__IB2_NUM_BLOB__", H);
    local _S_DEC = H.S;
    H.J(${payloadArg}, H);
    return H.W(H.K(H.D, H), {}, H.E)(...);
end
})(...)`;

    vm = vm
      .split('OP_ENUM').join('1')
      .split('OP_A').join('2')
      .split('OP_B').join('3')
      .split('OP_BX').join('4')
      .split('OP_C').join('5')
      .split('OP_DATA').join('6');

    return vm;
  }
}

// ============================================================================
// 10. Pure-JS Lua 5.1 Lexer, Minifier (luasrcdiet), and LZW Wrapper (compress.lua)
// ============================================================================

const LUA_KEYWORDS = new Set([
  'and', 'break', 'do', 'else', 'elseif', 'end', 'false',
  'for', 'function', 'if', 'in', 'local', 'nil', 'not',
  'or', 'repeat', 'return', 'then', 'true', 'until', 'while',
]);

class LuaLexer {
  static expandInterpolatedStrings(src) {
    // Converts Luau backtick interpolated strings `Hello {name}!` into standard Lua expressions
    // while preserving comments, normal strings, long strings, and line numbers.
    let out = '';
    let i = 0;
    const len = src.length;

    const escapeDoubleQuoted = (rawSegment) => {
      let res = '"';
      for (let k = 0; k < rawSegment.length; k++) {
        const c = rawSegment[k];
        if (c === '\\' && k + 1 < rawSegment.length) {
          const next = rawSegment[k + 1];
          if (next === '{' || next === '}' || next === '`') {
            res += next;
            k++;
          } else {
            res += c + next;
            k++;
          }
        } else if (c === '"') {
          res += '\\"';
        } else if (c === '\r') {
          res += '\\r';
        } else if (c === '\n') {
          res += '\\n';
        } else {
          res += c;
        }
      }
      res += '"';
      return res;
    };

    while (i < len) {
      if (src[i] === '-' && src[i + 1] === '-') {
        const start = i;
        i += 2;
        if (src[i] === '[') {
          let eq = 0;
          let k = i + 1;
          while (k < len && src[k] === '=') { eq++; k++; }
          if (src[k] === '[') {
            const closeSeq = ']' + '='.repeat(eq) + ']';
            const endIdx = src.indexOf(closeSeq, k + 1);
            const endPos = endIdx === -1 ? len : endIdx + closeSeq.length;
            out += src.slice(start, endPos);
            i = endPos;
            continue;
          }
        }
        while (i < len && src[i] !== '\n') i++;
        out += src.slice(start, i);
        continue;
      }

      if (src[i] === '"' || src[i] === "'") {
        const q = src[i];
        out += src[i++];
        while (i < len && src[i] !== q) {
          if (src[i] === '\\' && i + 1 < len) {
            out += src[i] + src[i + 1];
            i += 2;
          } else {
            out += src[i++];
          }
        }
        if (i < len) out += src[i++];
        continue;
      }

      if (src[i] === '[') {
        let eq = 0;
        let k = i + 1;
        while (k < len && src[k] === '=') { eq++; k++; }
        if (src[k] === '[') {
          const closeSeq = ']' + '='.repeat(eq) + ']';
          const endIdx = src.indexOf(closeSeq, k + 1);
          if (endIdx !== -1) {
            out += src.slice(i, endIdx + closeSeq.length);
            i = endIdx + closeSeq.length;
            continue;
          }
        }
      }

      if (src[i] === '`') {
        i++;
        const parts = [];
        let curLit = '';
        while (i < len && src[i] !== '`') {
          if (src[i] === '\\' && i + 1 < len) {
            curLit += src[i] + src[i + 1];
            i += 2;
            continue;
          }
          if (src[i] === '{') {
            if (curLit.length > 0) {
              parts.push({ type: 'lit', val: escapeDoubleQuoted(curLit) });
              curLit = '';
            }
            i++;
            let braceDepth = 1;
            let exprStart = i;
            while (i < len && braceDepth > 0) {
              if (src[i] === '"' || src[i] === "'" || src[i] === '`') {
                const q = src[i++];
                while (i < len && src[i] !== q) {
                  if (src[i] === '\\' && i + 1 < len) i += 2;
                  else i++;
                }
                if (i < len) i++;
              } else if (src[i] === '{') {
                braceDepth++;
                i++;
              } else if (src[i] === '}') {
                braceDepth--;
                if (braceDepth === 0) break;
                i++;
              } else {
                i++;
              }
            }
            const rawExpr = src.slice(exprStart, i);
            if (i < len && src[i] === '}') i++;
            const expandedInner = LuaLexer.expandInterpolatedStrings(rawExpr);
            parts.push({ type: 'expr', val: `tostring(${expandedInner})` });
            continue;
          }
          curLit += src[i++];
        }
        if (i < len && src[i] === '`') i++;
        if (curLit.length > 0 || parts.length === 0) {
          parts.push({ type: 'lit', val: escapeDoubleQuoted(curLit) });
        }
        if (parts.length === 1 && parts[0].type === 'lit') {
          out += parts[0].val;
        } else {
          out += '(' + parts.map((p) => p.val).join(' .. ') + ')';
        }
        continue;
      }

      out += src[i++];
    }
    return out;
  }

  static tokenize(src, keepComments = false) {
    src = LuaLexer.expandInterpolatedStrings(src);
    const tokens = [];
    let i = 0;
    let line = 1;
    const len = src.length;

    const advanceLines = (str) => {
      for (let k = 0; k < str.length; k++) {
        if (str[k] === '\n') line++;
      }
    };

    while (i < len) {
      const ch = src[i];

      // Whitespace
      if (ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n' || ch === '\f' || ch === '\v') {
        if (ch === '\n') line++;
        i++;
        continue;
      }

      // Comment
      if (ch === '-' && src[i + 1] === '-') {
        const startLine = line;
        const start = i;
        i += 2;
        if (src[i] === '[') {
          let eq = 0;
          let k = i + 1;
          while (k < len && src[k] === '=') { eq++; k++; }
          if (src[k] === '[') {
            const closeSeq = ']' + '='.repeat(eq) + ']';
            const endIdx = src.indexOf(closeSeq, k + 1);
            const raw = endIdx === -1 ? src.slice(start) : src.slice(start, endIdx + closeSeq.length);
            advanceLines(raw);
            i = endIdx === -1 ? len : endIdx + closeSeq.length;
            if (keepComments) tokens.push({ type: 'COMMENT', value: raw, line: startLine });
            continue;
          }
        }
        while (i < len && src[i] !== '\n') i++;
        if (keepComments) {
          tokens.push({ type: 'COMMENT', value: src.slice(start, i), line: startLine });
        }
        continue;
      }

      // Long string [=[...]=]
      if (ch === '[') {
        let eq = 0;
        let k = i + 1;
        while (k < len && src[k] === '=') { eq++; k++; }
        if (src[k] === '[') {
          const startLine = line;
          const start = i;
          const closeSeq = ']' + '='.repeat(eq) + ']';
          const endIdx = src.indexOf(closeSeq, k + 1);
          if (endIdx === -1) {
            throw new Error(`Unfinished long string at line ${startLine}`);
          }
          const raw = src.slice(start, endIdx + closeSeq.length);
          let body = src.slice(k + 1, endIdx);
          if (body.startsWith('\r\n')) body = body.slice(2);
          else if (body.startsWith('\n')) body = body.slice(1);
          advanceLines(raw);
          i = endIdx + closeSeq.length;
          tokens.push({ type: 'STRING', value: body, raw, line: startLine });
          continue;
        }
      }

      // Short string
      if (ch === '"' || ch === "'") {
        const startLine = line;
        const quote = ch;
        const start = i++;
        let rawBody = '';
        while (i < len && src[i] !== quote) {
          if (src[i] === '\\' && i + 1 < len) {
            if (src[i + 1] === '\n') line++;
            rawBody += src[i] + src[i + 1];
            i += 2;
          } else {
            if (src[i] === '\n') {
              throw new Error(`Unfinished string at line ${startLine}`);
            }
            rawBody += src[i++];
          }
        }
        if (i >= len || src[i] !== quote) {
          throw new Error(`Unfinished string at line ${startLine}`);
        }
        i++;
        const raw = src.slice(start, i);
        const unescapedBuf = ConstantEncryption.UnescapeLuaString(rawBody);
        tokens.push({
          type: 'STRING',
          value: bufferToLatin1(unescapedBuf),
          raw,
          line: startLine,
        });
        continue;
      }

      // Number (supports Luau 0b1010_0101, 0xFF_00, 1_000_000.5_5e+2)
      if (
        (ch >= '0' && ch <= '9') ||
        (ch === '.' && src[i + 1] >= '0' && src[i + 1] <= '9')
      ) {
        const startLine = line;
        const start = i;
        let numVal = 0;
        if (ch === '0' && (src[i + 1] === 'b' || src[i + 1] === 'B')) {
          i += 2;
          while (i < len && (src[i] === '0' || src[i] === '1' || src[i] === '_')) i++;
          const cleanBin = src.slice(start + 2, i).replace(/_/g, '');
          numVal = parseInt(cleanBin || '0', 2);
        } else if (ch === '0' && (src[i + 1] === 'x' || src[i + 1] === 'X')) {
          i += 2;
          while (i < len && /[0-9a-fA-F_]/.test(src[i])) i++;
          if (src[i] === '.') {
            i++;
            while (i < len && /[0-9a-fA-F_]/.test(src[i])) i++;
          }
          if (src[i] === 'p' || src[i] === 'P') {
            i++;
            if (src[i] === '+' || src[i] === '-') i++;
            while (i < len && /[0-9_]/.test(src[i])) i++;
          }
          const cleanHex = src.slice(start, i).replace(/_/g, '');
          numVal = parseInt(cleanHex, 16);
        } else {
          while (i < len && /[0-9_]/.test(src[i])) i++;
          if (src[i] === '.' && src[i + 1] !== '.') {
            i++;
            while (i < len && /[0-9_]/.test(src[i])) i++;
          }
          if (src[i] === 'e' || src[i] === 'E') {
            i++;
            if (src[i] === '+' || src[i] === '-') i++;
            while (i < len && /[0-9_]/.test(src[i])) i++;
          }
          const cleanDec = src.slice(start, i).replace(/_/g, '');
          numVal = parseFloat(cleanDec);
        }
        const raw = String(numVal);
        tokens.push({ type: 'NUMBER', value: numVal, raw, line: startLine });
        continue;
      }

      // Identifier or Keyword
      if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch === '_') {
        const startLine = line;
        const start = i++;
        while (
          i < len &&
          ((src[i] >= 'a' && src[i] <= 'z') ||
            (src[i] >= 'A' && src[i] <= 'Z') ||
            (src[i] >= '0' && src[i] <= '9') ||
            src[i] === '_')
        ) {
          i++;
        }
        const word = src.slice(start, i);
        tokens.push({
          type: LUA_KEYWORDS.has(word) ? 'KEYWORD' : 'IDENT',
          value: word,
          raw: word,
          line: startLine,
        });
        continue;
      }

      // Multi-char operators & punctuation (Lua 5.1 + Luau)
      const startLine = line;
      const three = src.slice(i, i + 3);
      if (three === '...' || three === '..=' || three === '//=') {
        tokens.push({ type: 'PUNCT', value: three, raw: three, line: startLine });
        i += 3;
        continue;
      }
      const two = src.slice(i, i + 2);
      if (
        two === '..' || two === '==' || two === '~=' || two === '<=' || two === '>=' ||
        two === '+=' || two === '-=' || two === '*=' || two === '/=' || two === '%=' || two === '^=' ||
        two === '//' || two === '::' || two === '->'
      ) {
        tokens.push({ type: 'PUNCT', value: two, raw: two, line: startLine });
        i += 2;
        continue;
      }

      tokens.push({ type: 'PUNCT', value: ch, raw: ch, line: startLine });
      i++;
    }

    return tokens;
  }

  static stripComments(src) {
    // Strips Lua comments while preserving newlines and string literals intact
    let out = '';
    let i = 0;
    const len = src.length;
    while (i < len) {
      if (src[i] === '-' && src[i + 1] === '-') {
        const start = i;
        i += 2;
        if (src[i] === '[') {
          let eq = 0;
          let k = i + 1;
          while (k < len && src[k] === '=') { eq++; k++; }
          if (src[k] === '[') {
            const closeSeq = ']' + '='.repeat(eq) + ']';
            const endIdx = src.indexOf(closeSeq, k + 1);
            const raw = endIdx === -1 ? src.slice(start) : src.slice(start, endIdx + closeSeq.length);
            for (let c = 0; c < raw.length; c++) {
              if (raw[c] === '\n') out += '\n';
            }
            i = endIdx === -1 ? len : endIdx + closeSeq.length;
            continue;
          }
        }
        while (i < len && src[i] !== '\n') i++;
        continue;
      }
      if (src[i] === '"' || src[i] === "'") {
        const q = src[i];
        out += src[i++];
        while (i < len && src[i] !== q) {
          if (src[i] === '\\' && i + 1 < len) {
            out += src[i] + src[i + 1];
            i += 2;
          } else {
            out += src[i++];
          }
        }
        if (i < len) out += src[i++];
        continue;
      }
      if (src[i] === '[') {
        let eq = 0;
        let k = i + 1;
        while (k < len && src[k] === '=') { eq++; k++; }
        if (src[k] === '[') {
          const closeSeq = ']' + '='.repeat(eq) + ']';
          const endIdx = src.indexOf(closeSeq, k + 1);
          if (endIdx !== -1) {
            out += src.slice(i, endIdx + closeSeq.length);
            i = endIdx + closeSeq.length;
            continue;
          }
        }
      }
      out += src[i++];
    }
    return out;
  }
}

const RESERVED_SHORT_NAMES = new Set([
  'H', 'J', 'K', 'W', 'D', 'S', 'G', 'E', 'X', 'B', 'AZT',
  'z', 'a', 'b', 'c', 'd', 'e', 'f',
]);

const PINNED_LOCAL_NAMES = new Map([
  ['H', 'H'],
  ['AZT', 'AZT'],
  ['_N_Z', 'z'],
  ['_N_A', 'a'],
  ['_N_B', 'b'],
  ['_N_C', 'c'],
  ['_N_D', 'd'],
  ['_N_E', 'e'],
  ['_N_F', 'f'],
  ['_S_DEC', 'S'],
  ['_G_ENV', 'G'],
]);

class LuaMinifier {
  static generateShortName(idx) {
    // Aesthetic 100% digit-free variable naming
    const firstChars = 'Il_ghijkmnopqrstuvwxyABCDEFGLMNPQRTVWXYZ';
    const restChars = 'Il_ghijkmnopqrstuvwxyABCDEFGLMNPQRTVWXYZ';
    let n = idx;
    let name = firstChars[n % firstChars.length];
    n = Math.floor(n / firstChars.length);
    while (n > 0) {
      name += restChars[(n - 1) % restChars.length];
      n = Math.floor((n - 1) / restChars.length);
    }
    if (LUA_KEYWORDS.has(name) || RESERVED_SHORT_NAMES.has(name)) {
      return '_' + name;
    }
    return name;
  }

  static encodeAlpha16(str) {
    let out = '';
    for (let i = 0; i < str.length; i++) {
      const b = str.charCodeAt(i) & 0xff;
      out += String.fromCharCode(65 + (b >> 4), 65 + (b & 15));
    }
    return out;
  }

  static getAlpha3Key(m) {
    const r0 = m % 26;
    const t1 = Math.floor(m / 26);
    const r1 = t1 % 26;
    const r2 = Math.floor(t1 / 26);
    return String.fromCharCode(97 + r2, 97 + r1, 97 + r0);
  }

  static encodeNumsBase26(nums) {
    const base26 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let sb = '';
    for (const num of nums) {
      let v = BigInt(Math.round(Number(num)));
      let s = '';
      do {
        s = base26[Number(v % 26n)] + s;
        v /= 26n;
      } while (v !== 0n);
      sb += base26[s.length] + s;
    }
    return sb;
  }

  static minify(src) {
    const tokens = LuaLexer.tokenize(src, false);
    if (tokens.length === 0) return '';
    return LuaMinifier.compactTokens(tokens);
  }

  static compactTokens(tokens) {
    // Safe, deterministic local-variable minifier + token packer
    const scopes = [new Map()];
    let nameCounter = 0;

    const allocName = (orig) => {
      if (PINNED_LOCAL_NAMES.has(orig)) {
        const pinned = PINNED_LOCAL_NAMES.get(orig);
        scopes[scopes.length - 1].set(orig, pinned);
        return pinned;
      }
      const short = LuaMinifier.generateShortName(nameCounter++);
      scopes[scopes.length - 1].set(orig, short);
      return short;
    };

    const resolveName = (orig) => {
      for (let s = scopes.length - 1; s >= 0; s--) {
        if (scopes[s].has(orig)) return scopes[s].get(orig);
      }
      return null;
    };

    const isIdentOrKeyword = (t) =>
      t && (t.type === 'IDENT' || t.type === 'KEYWORD' || t.type === 'NUMBER');

    const delimStack = [];
    const inTable = () => delimStack.length > 0 && delimStack[delimStack.length - 1] === "{";

    let i = 0;
    while (i < tokens.length) {
      const tok = tokens[i];
      const prev = i > 0 ? tokens[i - 1] : null;
      const next = i + 1 < tokens.length ? tokens[i + 1] : null;

      if (tok.type === 'KEYWORD') {
        if (tok.value === 'local') {
          if (next && next.type === 'KEYWORD' && next.value === 'function') {
            const fnIdent = tokens[i + 2];
            if (fnIdent && fnIdent.type === 'IDENT') {
              fnIdent.raw = allocName(fnIdent.value);
            }
            scopes.push(new Map());
            let j = i + 3;
            if (tokens[j] && tokens[j].value === '(') {
              j++;
              while (j < tokens.length && tokens[j].value !== ')') {
                if (tokens[j].type === 'IDENT') {
                  tokens[j].raw = allocName(tokens[j].value);
                }
                j++;
              }
            }
            i = j + 1;
            continue;
          } else {
            // Collect local variable tokens
            const decls = [];
            let j = i + 1;
            while (j < tokens.length && tokens[j].type === 'IDENT') {
              decls.push(tokens[j]);
              j++;
              if (tokens[j] && tokens[j].value === ',') j++;
              else break;
            }
            if (tokens[j] && tokens[j].value === '=') {
              j++; // skip '='
              let parenDepth = 0;
              while (j < tokens.length) {
                const t = tokens[j];
                if (t.value === '(' || t.value === '{' || t.value === '[') parenDepth++;
                else if (t.value === ')' || t.value === '}' || t.value === ']') {
                  if (parenDepth > 0) parenDepth--;
                  else break;
                } else if (parenDepth === 0) {
                  if (t.value === ';') {
                    j++;
                    break;
                  }
                  if (
                    t.type === 'KEYWORD' &&
                    t.value !== 'and' &&
                    t.value !== 'or' &&
                    t.value !== 'not' &&
                    t.value !== 'true' &&
                    t.value !== 'false' &&
                    t.value !== 'nil' &&
                    t.value !== 'function'
                  ) {
                    break;
                  }
                  const prevT = tokens[j - 1];
                  if (
                    prevT &&
                    (prevT.type === 'IDENT' ||
                      prevT.type === 'NUMBER' ||
                      prevT.type === 'STRING' ||
                      prevT.value === ')' ||
                      prevT.value === '}' ||
                      prevT.value === ']' ||
                      prevT.value === 'true' ||
                      prevT.value === 'false' ||
                      prevT.value === 'nil' ||
                      prevT.value === '...') &&
                    t.type === 'IDENT'
                  ) {
                    break;
                  }
                }

                if (t.type === 'KEYWORD' && t.value === 'function') {
                  break;
                }

                if (t.type === 'IDENT') {
                  const p = tokens[j - 1];
                  const n = tokens[j + 1];
                  const isProp = p && (p.value === '.' || p.value === ':');
                  const isKey = inTable() && n && n.value === '=' && p && (p.value === '{' || p.value === ',' || p.value === ';');
                  if (!isProp && !isKey) {
                    const mapped = resolveName(t.value);
                    if (mapped) t.raw = mapped;
                  }
                }
                j++;
              }
            }
            for (const d of decls) {
              d.raw = allocName(d.value);
            }
            i = j;
            continue;
          }
        }

        if (tok.value === 'function') {
          scopes.push(new Map());
          let j = i + 1;
          while (j < tokens.length && tokens[j].value !== '(') {
            if (tokens[j].type === 'IDENT') {
              const p = tokens[j - 1];
              if (!p || (p.value !== '.' && p.value !== ':')) {
                const mapped = resolveName(tokens[j].value);
                if (mapped) tokens[j].raw = mapped;
              }
            }
            j++;
          }
          if (tokens[j] && tokens[j].value === '(') {
            j++;
            while (j < tokens.length && tokens[j].value !== ')') {
              if (tokens[j].type === 'IDENT') {
                tokens[j].raw = allocName(tokens[j].value);
              }
              j++;
            }
          }
          i = j + 1;
          continue;
        }

        if (tok.value === 'for') {
          const forVars = [];
          let j = i + 1;
          while (j < tokens.length && tokens[j].type === 'IDENT') {
            forVars.push(tokens[j]);
            j++;
            if (tokens[j] && tokens[j].value === ',') j++;
            else break;
          }
          while (j < tokens.length && !(tokens[j].type === 'KEYWORD' && tokens[j].value === 'do')) {
            if (tokens[j].type === 'IDENT') {
              const p = tokens[j - 1];
              const n = tokens[j + 1];
              const isProp = p && (p.value === '.' || p.value === ':');
              const isKey = inTable() && n && n.value === '=' && p && (p.value === '{' || p.value === ',' || p.value === ';');
              if (!isProp && !isKey) {
                const mapped = resolveName(tokens[j].value);
                if (mapped) tokens[j].raw = mapped;
              }
            }
            j++;
          }
          scopes.push(new Map());
          for (const fv of forVars) {
            fv.raw = allocName(fv.value);
          }
          i = j + 1;
          continue;
        }

        if (tok.value === 'do' || tok.value === 'then' || tok.value === 'repeat') {
          scopes.push(new Map());
          i++;
          continue;
        }

        if (tok.value === 'else' || tok.value === 'elseif') {
          if (scopes.length > 1) scopes.pop();
          if (tok.value === 'else') scopes.push(new Map());
          i++;
          continue;
        }

        if (tok.value === 'end') {
          if (scopes.length > 1) scopes.pop();
          i++;
          continue;
        }

        if (tok.value === 'until') {
          i++;
          continue;
        }
      }

      if (tok.type === 'IDENT') {
        const isProp = prev && (prev.value === '.' || prev.value === ':');
        const isKey =
          inTable() && next && next.value === '=' && prev && (prev.value === '{' || prev.value === ',' || prev.value === ';');
        if (!isProp && !isKey) {
          const mapped = resolveName(tok.value);
          if (mapped) tok.raw = mapped;
        }
      }
      i++;
    }

    // Universal Digit-Free & Aesthetic Post-Pass
    const hasNumBlob = tokens.some((t) => t.type === 'STRING' && t.value === '__IB2_NUM_BLOB__');
    const sDec = 'S';
    const gEnv = 'G';
    const nVars = ['z', 'a', 'b', 'c', 'd', 'e', 'f'];

    let finalTokens = tokens;
    if (hasNumBlob) {
      finalTokens = [];
      const distinctNums = [];
      const numMap = new Map();
      let blobTok = null;

      for (let k = 0; k < tokens.length; k++) {
        const tok = tokens[k];
        const nextTok = k + 1 < tokens.length ? tokens[k + 1] : null;

        // 1. Property access .IDENT where IDENT contains digits (e.g. .readu8, .writef32, .Sha256)
        if (
          tok.type === 'PUNCT' &&
          tok.value === '.' &&
          nextTok &&
          nextTok.type === 'IDENT' &&
          /[0-9]/.test(nextTok.raw)
        ) {
          const enc = LuaMinifier.encodeAlpha16(nextTok.value);
          finalTokens.push({
            type: 'PUNCT',
            value: ']',
            raw: `[${sDec}("${enc}")]`,
            line: tok.line,
          });
          k++;
          continue;
        }

        // 2. Global IDENT containing digits (e.g. bit32, UDim2, Path2DControlPoint)
        if (tok.type === 'IDENT' && /[0-9]/.test(tok.raw)) {
          const enc = LuaMinifier.encodeAlpha16(tok.value);
          finalTokens.push({
            type: 'IDENT',
            value: tok.value,
            raw: `${gEnv}[${sDec}("${enc}")]`,
            line: tok.line,
          });
          continue;
        }

        // 3. String literal containing digits or backslash escapes
        if (tok.type === 'STRING') {
          if (tok.value === '__IB2_NUM_BLOB__') {
            blobTok = tok;
            finalTokens.push(tok);
            continue;
          }
          if (/[0-9\\]/.test(tok.raw)) {
            const enc = LuaMinifier.encodeAlpha16(tok.value);
            finalTokens.push({
              type: 'IDENT',
              value: sDec,
              raw: `${sDec}("${enc}")`,
              line: tok.line,
            });
            continue;
          }
          finalTokens.push(tok);
          continue;
        }

        // 4. Number literal -> replace with z..f (for 0..6) or H.<key3> (for >6)
        if (tok.type === 'NUMBER') {
          const val = Math.round(Number(tok.value));
          if (val >= 0 && val <= 6) {
            finalTokens.push({
              type: 'IDENT',
              value: nVars[val],
              raw: nVars[val],
              line: tok.line,
            });
          } else {
            let m = numMap.get(val);
            if (m === undefined) {
              m = distinctNums.length;
              distinctNums.push(val);
              numMap.set(val, m);
            }
            const key3 = LuaMinifier.getAlpha3Key(m);
            finalTokens.push({
              type: 'IDENT',
              value: 'H.' + key3,
              raw: 'H.' + key3,
              line: tok.line,
            });
          }
          continue;
        }

        finalTokens.push(tok);
      }

      if (blobTok) {
        const blobStr = LuaMinifier.encodeNumsBase26(distinctNums);
        blobTok.value = blobStr;
        blobTok.raw = `"${blobStr}"`;
      }
    }

    // Join tokens with minimal whitespace
    let out = '';
    for (let k = 0; k < finalTokens.length; k++) {
      const cur = finalTokens[k];
      const prev = k > 0 ? finalTokens[k - 1] : null;

      if (prev) {
        let needSpace = false;
        if (isIdentOrKeyword(prev) && isIdentOrKeyword(cur)) {
          needSpace = true;
        } else if (prev.type === 'NUMBER' && (cur.value === '..' || cur.value === '...')) {
          needSpace = true;
        } else if (prev.value === '-' && cur.value === '-') {
          needSpace = true;
        } else if (prev.value === '[' && cur.value === '[') {
          needSpace = true;
        }
        if (needSpace) out += ' ';
      }
      out += cur.raw;
    }

    return out;
  }
}

// No-loadstring wrapper compressor (uses VM bytecode compression without loadstring/load)
function lzwWrapCompress(inputStr) {
  return inputStr;
}

// ============================================================================
// 11. Pure-JS Lua 5.1 Parser & Bytecode Compiler (AST -> IronBrew2 Chunk)
// ============================================================================

const BINOP_PRECEDENCE = Object.freeze({
  or: [1, 1],
  and: [2, 2],
  '<': [3, 3], '>': [3, 3], '<=': [3, 3], '>=': [3, 3], '~=': [3, 3], '==': [3, 3],
  '..': [4, 3], // right-associative
  '+': [5, 5], '-': [5, 5],
  '*': [6, 6], '/': [6, 6], '//': [6, 6], '%': [6, 6],
  '^': [8, 7],  // right-associative (higher than unary 7)
});

class LuaParser {
  constructor(tokens) {
    this.tokens = tokens;
    this.pos = 0;
  }

  peek(offset = 0) {
    return this.tokens[this.pos + offset] || null;
  }

  next() {
    return this.tokens[this.pos++] || null;
  }

  eof() {
    return this.pos >= this.tokens.length;
  }

  check(type, value) {
    const t = this.peek();
    if (!t) return false;
    if (type && t.type !== type) return false;
    if (value !== undefined && t.value !== value) return false;
    return true;
  }

  match(type, value) {
    if (this.check(type, value)) {
      return this.next();
    }
    return null;
  }

  expect(type, value) {
    const t = this.next();
    if (!t || (type && t.type !== type) || (value !== undefined && t.value !== value)) {
      const got = t ? `'${t.raw}' at line ${t.line}` : 'EOF';
      throw new Error(`Lua syntax error: expected ${value || type}, got ${got}`);
    }
    return t;
  }

  skipBalanced(openVal, closeVal) {
    this.expect('PUNCT', openVal);
    let depth = 1;
    while (!this.eof() && depth > 0) {
      const tk = this.next();
      if (tk.type === 'PUNCT') {
        if (tk.value === openVal) depth++;
        else if (tk.value === closeVal) depth--;
      }
    }
  }

  skipType() {
    while (this.match('PUNCT', '|') || this.match('PUNCT', '&')) {}

    while (!this.eof()) {
      if (this.check('IDENT', 'typeof')) {
        this.next();
        if (this.check('PUNCT', '(')) this.skipBalanced('(', ')');
      } else if (this.check('PUNCT', '{')) {
        this.skipBalanced('{', '}');
      } else if (this.check('PUNCT', '(')) {
        while (this.check('PUNCT', '(')) {
          this.skipBalanced('(', ')');
        }
      } else if (this.check('PUNCT', '<')) {
        this.skipBalanced('<', '>');
        if (this.check('PUNCT', '(')) this.skipBalanced('(', ')');
      } else if (this.match('PUNCT', '...')) {
        if (
          this.check('IDENT') ||
          this.check('PUNCT', '(') ||
          this.check('PUNCT', '{')
        ) {
          this.skipType();
        }
      } else if (
        this.match('KEYWORD', 'nil') ||
        this.match('KEYWORD', 'true') ||
        this.match('KEYWORD', 'false') ||
        this.match('STRING') ||
        this.match('NUMBER')
      ) {
        // Singleton literal type
      } else if (this.match('IDENT')) {
        while (this.match('PUNCT', '.')) {
          this.expect('IDENT');
        }
        if (this.check('PUNCT', '<')) {
          this.skipBalanced('<', '>');
        }
        this.match('PUNCT', '...');
      } else {
        break;
      }

      while (this.match('PUNCT', '?')) {}
      if (this.match('PUNCT', '->')) {
        this.skipType();
      }
      if (this.match('PUNCT', '|') || this.match('PUNCT', '&')) {
        continue;
      }
      break;
    }
  }

  isBlockFollow() {
    const t = this.peek();
    if (!t) return true;
    if (t.type !== 'KEYWORD') return false;
    return (
      t.value === 'else' ||
      t.value === 'elseif' ||
      t.value === 'end' ||
      t.value === 'until'
    );
  }

  parseChunk() {
    const firstLine = this.peek() ? this.peek().line : 1;
    const block = this.parseBlock();
    if (!this.eof()) {
      const t = this.peek();
      throw new Error(`Unexpected token '${t.raw}' at line ${t.line}`);
    }
    const lastLine = this.tokens.length > 0 ? this.tokens[this.tokens.length - 1].line : firstLine;
    return { type: 'Chunk', body: block, line: firstLine, lastLine };
  }

  parseBlock() {
    const statements = [];
    while (!this.isBlockFollow()) {
      while (this.match('PUNCT', ';')) {}
      if (this.isBlockFollow()) break;
      const stmt = this.parseStatement();
      if (stmt.type !== 'NoopStmt') {
        statements.push(stmt);
      }
      while (this.match('PUNCT', ';')) {}
      if (
        stmt.type === 'ReturnStmt' ||
        stmt.type === 'BreakStmt' ||
        stmt.type === 'ContinueStmt'
      ) {
        break;
      }
    }
    return statements;
  }

  parseStatement() {
    while (this.match('PUNCT', '@')) {
      if (this.check('PUNCT', '[')) {
        this.skipBalanced('[', ']');
      } else if (this.check('IDENT')) {
        this.next();
      }
    }

    const t = this.peek();
    const line = t ? t.line : 1;

    if (
      this.check('IDENT', 'export') &&
      this.peek(1) &&
      this.peek(1).type === 'IDENT' &&
      this.peek(1).value === 'type'
    ) {
      this.next();
      this.next();
      this.expect('IDENT');
      if (this.check('PUNCT', '<')) this.skipBalanced('<', '>');
      this.expect('PUNCT', '=');
      this.skipType();
      return { type: 'NoopStmt', line };
    }

    if (
      this.check('IDENT', 'type') &&
      this.peek(1) &&
      this.peek(1).type === 'IDENT'
    ) {
      this.next();
      this.expect('IDENT');
      if (this.check('PUNCT', '<')) this.skipBalanced('<', '>');
      this.expect('PUNCT', '=');
      this.skipType();
      return { type: 'NoopStmt', line };
    }

    if (
      this.check('IDENT', 'declare') &&
      this.peek(1) &&
      (this.peek(1).value === 'function' || this.peek(1).type === 'IDENT')
    ) {
      this.next();
      if (this.match('KEYWORD', 'function')) {
        this.expect('IDENT');
        if (this.check('PUNCT', '<')) this.skipBalanced('<', '>');
        if (this.check('PUNCT', '(')) this.skipBalanced('(', ')');
        if (this.match('PUNCT', ':')) this.skipType();
      } else if (this.check('IDENT', 'class')) {
        this.next();
        while (!this.eof() && !this.match('KEYWORD', 'end')) this.next();
      } else {
        this.expect('IDENT');
        if (this.match('PUNCT', ':')) this.skipType();
      }
      return { type: 'NoopStmt', line };
    }

    if (this.match('KEYWORD', 'if')) return this.parseIfStmt(line);
    if (this.match('KEYWORD', 'while')) return this.parseWhileStmt(line);
    if (this.match('KEYWORD', 'do')) {
      const body = this.parseBlock();
      this.expect('KEYWORD', 'end');
      return { type: 'DoStmt', body, line };
    }
    if (this.match('KEYWORD', 'for')) return this.parseForStmt(line);
    if (this.match('KEYWORD', 'repeat')) {
      const body = this.parseBlock();
      this.expect('KEYWORD', 'until');
      const cond = this.parseExpr();
      return { type: 'RepeatStmt', body, cond, line };
    }
    if (this.match('KEYWORD', 'function')) return this.parseFuncDeclStmt(false, line);
    if (this.match('KEYWORD', 'local')) {
      while (this.match('PUNCT', '@')) {
        if (this.check('PUNCT', '[')) this.skipBalanced('[', ']');
        else if (this.check('IDENT')) this.next();
      }
      if (this.match('KEYWORD', 'function')) {
        return this.parseFuncDeclStmt(true, line);
      }
      return this.parseLocalStmt(line);
    }
    if (this.match('KEYWORD', 'return')) {
      const values = [];
      if (!this.isBlockFollow() && !this.check('PUNCT', ';')) {
        values.push(...this.parseExprList());
      }
      return { type: 'ReturnStmt', values, line };
    }
    if (this.match('KEYWORD', 'break')) {
      return { type: 'BreakStmt', line };
    }

    if (this.check('IDENT', 'continue')) {
      const nextTok = this.peek(1);
      const isCallOrAssign =
        nextTok &&
        (nextTok.value === '=' ||
          nextTok.value === ',' ||
          nextTok.value === '.' ||
          nextTok.value === ':' ||
          nextTok.value === '(' ||
          nextTok.value === '[' ||
          nextTok.value === '{' ||
          nextTok.type === 'STRING' ||
          nextTok.value === '+=' ||
          nextTok.value === '-=' ||
          nextTok.value === '*=' ||
          nextTok.value === '/=' ||
          nextTok.value === '//=' ||
          nextTok.value === '%=' ||
          nextTok.value === '^=' ||
          nextTok.value === '..=');
      if (!isCallOrAssign) {
        this.next();
        return { type: 'ContinueStmt', line };
      }
    }

    const first = this.parsePrefixExpr();

    const nextPunct = this.peek();
    if (
      nextPunct &&
      nextPunct.type === 'PUNCT' &&
      (nextPunct.value === '+=' ||
        nextPunct.value === '-=' ||
        nextPunct.value === '*=' ||
        nextPunct.value === '/=' ||
        nextPunct.value === '//=' ||
        nextPunct.value === '%=' ||
        nextPunct.value === '^=' ||
        nextPunct.value === '..=')
    ) {
      const opTok = this.next();
      const op = opTok.value.slice(0, -1);
      const value = this.parseExpr();
      return { type: 'CompoundAssignStmt', target: first, op, value, line };
    }

    if (this.check('PUNCT', '=') || this.check('PUNCT', ',')) {
      const targets = [first];
      while (this.match('PUNCT', ',')) {
        targets.push(this.parsePrefixExpr());
      }
      this.expect('PUNCT', '=');
      const values = this.parseExprList();
      return { type: 'AssignStmt', targets, values, line };
    }

    if (first.type !== 'CallExpr' && first.type !== 'MethodCallExpr') {
      throw new Error(`Syntax error at line ${line}: expected assignment or function call`);
    }
    return { type: 'CallStmt', expr: first, line };
  }

  parseIfStmt(line) {
    const clauses = [];
    const firstCond = this.parseExpr();
    this.expect('KEYWORD', 'then');
    const firstBody = this.parseBlock();
    clauses.push({ cond: firstCond, body: firstBody, line });

    while (this.match('KEYWORD', 'elseif')) {
      const cLine = this.peek() ? this.peek().line : line;
      const cond = this.parseExpr();
      this.expect('KEYWORD', 'then');
      const body = this.parseBlock();
      clauses.push({ cond, body, line: cLine });
    }

    let elseBody = null;
    if (this.match('KEYWORD', 'else')) {
      elseBody = this.parseBlock();
    }
    this.expect('KEYWORD', 'end');
    return { type: 'IfStmt', clauses, elseBody, line };
  }

  parseWhileStmt(line) {
    const cond = this.parseExpr();
    this.expect('KEYWORD', 'do');
    const body = this.parseBlock();
    this.expect('KEYWORD', 'end');
    return { type: 'WhileStmt', cond, body, line };
  }

  parseForStmt(line) {
    const firstVar = this.expect('IDENT').value;
    if (this.match('PUNCT', ':')) this.skipType();
    if (this.match('PUNCT', '=')) {
      const init = this.parseExpr();
      this.expect('PUNCT', ',');
      const limit = this.parseExpr();
      let step = { type: 'NumberLiteral', value: 1, line };
      if (this.match('PUNCT', ',')) {
        step = this.parseExpr();
      }
      this.expect('KEYWORD', 'do');
      const body = this.parseBlock();
      this.expect('KEYWORD', 'end');
      return { type: 'ForNumStmt', name: firstVar, init, limit, step, body, line };
    } else {
      const names = [firstVar];
      while (this.match('PUNCT', ',')) {
        names.push(this.expect('IDENT').value);
        if (this.match('PUNCT', ':')) this.skipType();
      }
      this.expect('KEYWORD', 'in');
      const iterators = this.parseExprList();
      this.expect('KEYWORD', 'do');
      const body = this.parseBlock();
      this.expect('KEYWORD', 'end');
      return { type: 'ForInStmt', names, iterators, body, line };
    }
  }

  parseFuncDeclStmt(isLocal, line) {
    const namePath = [this.expect('IDENT').value];
    let methodName = null;
    if (!isLocal) {
      while (this.match('PUNCT', '.')) {
        namePath.push(this.expect('IDENT').value);
      }
      if (this.match('PUNCT', ':')) {
        methodName = this.expect('IDENT').value;
      }
    }
    const fn = this.parseFuncBody(line, methodName !== null);
    return {
      type: 'FuncDeclStmt',
      isLocal,
      namePath,
      methodName,
      params: fn.params,
      isVararg: fn.isVararg,
      body: fn.body,
      line,
      lastLine: fn.lastLine,
    };
  }

  parseFuncBody(line, hasImplicitSelf = false) {
    if (this.check('PUNCT', '<')) {
      this.skipBalanced('<', '>');
    }
    this.expect('PUNCT', '(');
    const params = hasImplicitSelf ? ['self'] : [];
    let isVararg = false;
    if (!this.check('PUNCT', ')')) {
      do {
        if (this.match('PUNCT', '...')) {
          isVararg = true;
          if (this.match('PUNCT', ':')) this.skipType();
          break;
        }
        params.push(this.expect('IDENT').value);
        if (this.match('PUNCT', ':')) this.skipType();
      } while (this.match('PUNCT', ','));
    }
    this.expect('PUNCT', ')');
    if (this.match('PUNCT', ':')) {
      this.skipType();
    }
    const body = this.parseBlock();
    const endTok = this.expect('KEYWORD', 'end');
    return { type: 'FuncExpr', params, isVararg, body, line, lastLine: endTok.line };
  }

  parseLocalStmt(line) {
    const names = [this.expect('IDENT').value];
    if (this.match('PUNCT', ':')) this.skipType();
    while (this.match('PUNCT', ',')) {
      names.push(this.expect('IDENT').value);
      if (this.match('PUNCT', ':')) this.skipType();
    }
    let values = [];
    if (this.match('PUNCT', '=')) {
      values = this.parseExprList();
    }
    return { type: 'LocalStmt', names, values, line };
  }

  parseExprList() {
    const list = [this.parseExpr()];
    while (this.match('PUNCT', ',')) {
      list.push(this.parseExpr());
    }
    return list;
  }

  parseExpr(minPrec = 0) {
    let left = this.parseSimpleOrUnaryExpr();
    while (this.match('PUNCT', '::')) {
      this.skipType();
    }

    while (true) {
      const t = this.peek();
      if (!t) break;
      const prec = BINOP_PRECEDENCE[t.value];
      if (!prec || prec[0] <= minPrec) break;

      const op = this.next().value;
      const right = this.parseExpr(prec[1]);
      left = { type: 'BinaryExpr', op, left, right, line: t.line };
    }

    return left;
  }

  parseSimpleOrUnaryExpr() {
    const t = this.peek();
    if (!t) throw new Error('Unexpected EOF in expression');

    if (this.match('KEYWORD', 'if')) {
      const clauses = [];
      const firstCond = this.parseExpr();
      this.expect('KEYWORD', 'then');
      const firstExpr = this.parseExpr();
      clauses.push({ cond: firstCond, expr: firstExpr, line: t.line });
      while (this.match('KEYWORD', 'elseif')) {
        const cLine = this.peek() ? this.peek().line : t.line;
        const cCond = this.parseExpr();
        this.expect('KEYWORD', 'then');
        const cExpr = this.parseExpr();
        clauses.push({ cond: cCond, expr: cExpr, line: cLine });
      }
      this.expect('KEYWORD', 'else');
      const elseExpr = this.parseExpr();
      return { type: 'IfExpr', clauses, elseExpr, line: t.line };
    }

    if (
      (t.type === 'KEYWORD' && t.value === 'not') ||
      (t.type === 'PUNCT' && (t.value === '-' || t.value === '#'))
    ) {
      this.next();
      const arg = this.parseExpr(7);
      return { type: 'UnaryExpr', op: t.value, arg, line: t.line };
    }

    if (this.match('KEYWORD', 'nil')) return { type: 'NilLiteral', line: t.line };
    if (this.match('KEYWORD', 'true')) return { type: 'BoolLiteral', value: true, line: t.line };
    if (this.match('KEYWORD', 'false')) return { type: 'BoolLiteral', value: false, line: t.line };
    if (this.match('NUMBER')) return { type: 'NumberLiteral', value: t.value, line: t.line };
    if (this.match('STRING')) return { type: 'StringLiteral', value: t.value, line: t.line };
    if (this.match('PUNCT', '...')) return { type: 'VarargExpr', line: t.line };
    if (this.match('KEYWORD', 'function')) return this.parseFuncBody(t.line, false);
    if (this.check('PUNCT', '{')) return this.parseTableExpr();

    return this.parsePrefixExpr();
  }

  parsePrefixExpr() {
    const t = this.peek();
    let expr;
    if (this.match('PUNCT', '(')) {
      const inner = this.parseExpr();
      this.expect('PUNCT', ')');
      expr = { type: 'ParenExpr', expr: inner, line: t.line };
    } else if (this.match('IDENT')) {
      expr = { type: 'IdentExpr', name: t.value, line: t.line };
    } else {
      throw new Error(`Unexpected token '${t ? t.raw : 'EOF'}' at line ${t ? t.line : '?'}`);
    }

    while (true) {
      const next = this.peek();
      if (!next) break;

      if (this.match('PUNCT', '.')) {
        const prop = this.expect('IDENT');
        expr = {
          type: 'IndexExpr',
          base: expr,
          index: { type: 'StringLiteral', value: prop.value, line: prop.line },
          line: prop.line,
        };
      } else if (this.match('PUNCT', '[')) {
        const idxExpr = this.parseExpr();
        this.expect('PUNCT', ']');
        expr = { type: 'IndexExpr', base: expr, index: idxExpr, line: next.line };
      } else if (this.match('PUNCT', ':')) {
        const methodTok = this.expect('IDENT');
        const args = this.parseCallArgs();
        expr = {
          type: 'MethodCallExpr',
          receiver: expr,
          method: methodTok.value,
          args,
          line: methodTok.line,
        };
      } else if (
        this.check('PUNCT', '(') ||
        this.check('PUNCT', '{') ||
        this.check('STRING')
      ) {
        const args = this.parseCallArgs();
        expr = { type: 'CallExpr', func: expr, args, line: next.line };
      } else {
        break;
      }
    }

    return expr;
  }

  parseCallArgs() {
    if (this.match('PUNCT', '(')) {
      const args = [];
      if (!this.check('PUNCT', ')')) {
        args.push(...this.parseExprList());
      }
      this.expect('PUNCT', ')');
      return args;
    }
    if (this.check('PUNCT', '{')) {
      return [this.parseTableExpr()];
    }
    if (this.check('STRING')) {
      const s = this.next();
      return [{ type: 'StringLiteral', value: s.value, line: s.line }];
    }
    throw new Error('Expected function call arguments');
  }

  parseTableExpr() {
    const startTok = this.expect('PUNCT', '{');
    const fields = [];
    while (!this.check('PUNCT', '}')) {
      if (this.match('PUNCT', '[')) {
        const key = this.parseExpr();
        this.expect('PUNCT', ']');
        this.expect('PUNCT', '=');
        const value = this.parseExpr();
        fields.push({ type: 'hash', key, value });
      } else if (this.check('IDENT') && this.peek(1) && this.peek(1).value === '=') {
        const id = this.next();
        this.expect('PUNCT', '=');
        const value = this.parseExpr();
        fields.push({
          type: 'hash',
          key: { type: 'StringLiteral', value: id.value, line: id.line },
          value,
        });
      } else {
        const value = this.parseExpr();
        fields.push({ type: 'array', value });
      }
      if (!this.match('PUNCT', ',') && !this.match('PUNCT', ';')) {
        break;
      }
    }
    this.expect('PUNCT', '}');
    return { type: 'TableExpr', fields, line: startTok.line };
  }
}

class FuncState {
  constructor(parent = null, name = '', line = 0, lastLine = 0) {
    this.parent = parent;
    this.chunk = new Chunk();
    this.chunk.Name = name;
    this.chunk.Line = line;
    this.chunk.LastLine = lastLine;
    this.chunk.StackSize = 2;

    this.locals = []; // [{ name, reg, depth, captured }]
    this.upvalues = []; // [{ name, inStack, index }]
    this.scopeDepth = 0;
    this.freereg = 0;
    this.loopStack = []; // [{ breakJumps: [], scopeDepth }]
    this.constCache = new Map();
  }

  allocReg(count = 1) {
    const r = this.freereg;
    this.freereg += count;
    if (this.freereg > this.chunk.StackSize) {
      this.chunk.StackSize = this.freereg;
    }
    return r;
  }

  setFreeReg(r) {
    this.freereg = r;
  }

  enterScope() {
    this.scopeDepth++;
  }

  leaveScope(line = 1) {
    let needClose = false;
    let minReg = 255;
    while (
      this.locals.length > 0 &&
      this.locals[this.locals.length - 1].depth === this.scopeDepth
    ) {
      const loc = this.locals.pop();
      if (loc.captured) {
        needClose = true;
        if (loc.reg < minReg) minReg = loc.reg;
      }
    }
    this.scopeDepth--;
    if (this.locals.length > 0) {
      this.freereg = this.locals[this.locals.length - 1].reg + 1;
    } else {
      this.freereg = 0;
    }
    if (needClose) {
      this.emitABC(Opcode.Close, minReg, 0, 0, line);
    }
  }

  declareLocal(name) {
    const reg = this.allocReg(1);
    this.locals.push({ name, reg, depth: this.scopeDepth, captured: false });
    return reg;
  }

  resolveLocal(name) {
    for (let i = this.locals.length - 1; i >= 0; i--) {
      if (this.locals[i].name === name) {
        return this.locals[i];
      }
    }
    return null;
  }

  resolveUpvalue(name) {
    for (let i = 0; i < this.upvalues.length; i++) {
      if (this.upvalues[i].name === name) return i;
    }
    if (!this.parent) return -1;

    const parentLocal = this.parent.resolveLocal(name);
    if (parentLocal) {
      parentLocal.captured = true;
      const idx = this.upvalues.length;
      this.upvalues.push({ name, inStack: true, index: parentLocal.reg });
      this.chunk.Upvalues.push(name);
      this.chunk.UpvalueCount = this.upvalues.length;
      return idx;
    }

    const parentUpval = this.parent.resolveUpvalue(name);
    if (parentUpval !== -1) {
      const idx = this.upvalues.length;
      this.upvalues.push({ name, inStack: false, index: parentUpval });
      this.chunk.Upvalues.push(name);
      this.chunk.UpvalueCount = this.upvalues.length;
      return idx;
    }

    return -1;
  }

  getOrAddConst(type, data) {
    const key = `${type}:${type === ConstantType.Number && Object.is(data, -0) ? '-0' : data}`;
    if (this.constCache.has(key)) {
      return this.constCache.get(key);
    }
    const c = new Constant();
    c.Type = type;
    c.Data = data;
    const idx = this.chunk.Constants.length;
    this.chunk.Constants.push(c);
    this.chunk.ConstantMap.set(c, idx);
    const entry = { constant: c, index: idx };
    this.constCache.set(key, entry);
    return entry;
  }

  emitInst(inst, line = 1) {
    inst.Line = line;
    this.chunk.Instructions.push(inst);
    return inst;
  }

  emitABC(op, a, b, c, line = 1, ref0 = null, ref1 = null) {
    const inst = new Instruction(this.chunk, op);
    inst.A = a;
    inst.B = b;
    inst.C = c;
    if (ref0) {
      inst.RefOperands[0] = ref0;
      if (ref0 instanceof Constant || ref0 instanceof Instruction) {
        ref0.BackReferences.push(inst);
      }
    }
    if (ref1) {
      inst.RefOperands[1] = ref1;
      if (ref1 instanceof Constant || ref1 instanceof Instruction) {
        ref1.BackReferences.push(inst);
      }
    }
    return this.emitInst(inst, line);
  }

  emitABx(op, a, bx, line = 1, ref0 = null) {
    const inst = new Instruction(this.chunk, op);
    inst.A = a;
    inst.B = bx;
    inst.C = -1;
    if (ref0) {
      inst.RefOperands[0] = ref0;
      if (ref0 instanceof Constant || ref0 instanceof Instruction) {
        ref0.BackReferences.push(inst);
      }
    }
    return this.emitInst(inst, line);
  }

  emitJmp(targetInst = null, line = 1) {
    const inst = new Instruction(this.chunk, Opcode.Jmp);
    inst.A = 0;
    inst.B = 0;
    inst.C = -1;
    if (targetInst) {
      inst.RefOperands[0] = targetInst;
      targetInst.BackReferences.push(inst);
    }
    return this.emitInst(inst, line);
  }
}

class LuaCompiler {
  static compile(source, chunkName = '@input.lua') {
    const tokens = LuaLexer.tokenize(source, false);
    const parser = new LuaParser(tokens);
    const ast = parser.parseChunk();
    const compiler = new LuaCompiler();
    const rootChunk = compiler.compileFunction(
      null,
      chunkName,
      [],
      true,
      ast.body,
      ast.line,
      ast.lastLine
    );
    // Round-trip through VanillaSerializer -> Deserializer so all instruction encodings,
    // ConstantMap, InstructionMap, FunctionMap, and SetupRefs match luac 100%!
    const luacBytes = new VanillaSerializer(rootChunk).Serialize();
    return new Deserializer(luacBytes).DecodeFile();
  }

  compileFunction(parentState, name, params, isVararg, body, line, lastLine) {
    const fs = new FuncState(parentState, name, line, lastLine);
    fs.chunk.ParameterCount = params.length;
    fs.chunk.VarargFlag = isVararg ? 2 : 0;

    for (const p of params) {
      fs.declareLocal(p);
    }

    this.compileBlock(fs, body);

    // Ensure trailing RETURN 0 1 0
    fs.emitABC(Opcode.Return, 0, 1, 0, lastLine || line);

    fs.chunk.UpdateMappings();
    for (const ins of fs.chunk.Instructions) {
      ins.UpdateRegisters();
    }
    return fs.chunk;
  }

  compileBlock(fs, statements) {
    fs.enterScope();
    for (const stmt of statements) {
      this.compileStmt(fs, stmt);
    }
    fs.leaveScope();
  }

  isMultiRetExpr(expr) {
    return (
      expr.type === 'CallExpr' ||
      expr.type === 'MethodCallExpr' ||
      expr.type === 'VarargExpr'
    );
  }

  compileStmt(fs, stmt) {
    const savedFree = fs.locals.length > 0 ? fs.locals[fs.locals.length - 1].reg + 1 : 0;
    fs.setFreeReg(savedFree);

    switch (stmt.type) {
      case 'DoStmt':
        this.compileBlock(fs, stmt.body);
        break;

      case 'LocalStmt': {
        const nvars = stmt.names.length;
        const nvals = stmt.values.length;
        const baseReg = fs.freereg;

        if (nvals === 0) {
          const rStart = fs.allocReg(nvars);
          fs.emitABC(Opcode.LoadNil, rStart, rStart + nvars - 1, 0, stmt.line);
        } else {
          for (let i = 0; i < nvals; i++) {
            const valExpr = stmt.values[i];
            const isLast = i === nvals - 1;
            if (isLast && nvars > nvals && this.isMultiRetExpr(valExpr)) {
              const needed = nvars - i;
              const r = fs.allocReg(needed);
              this.compileMultiRetExpr(fs, valExpr, r, needed);
            } else if (isLast && nvars < nvals) {
              const r = fs.allocReg(1);
              this.compileExprToReg(fs, valExpr, r);
            } else {
              const r = fs.allocReg(1);
              this.compileExprToReg(fs, valExpr, r);
            }
          }
          if (nvars > nvals && !this.isMultiRetExpr(stmt.values[nvals - 1])) {
            const extra = nvars - nvals;
            const rNil = fs.allocReg(extra);
            fs.emitABC(Opcode.LoadNil, rNil, rNil + extra - 1, 0, stmt.line);
          }
        }

        fs.setFreeReg(baseReg);
        for (let i = 0; i < nvars; i++) {
          fs.declareLocal(stmt.names[i]);
        }
        break;
      }

      case 'AssignStmt': {
        const nvars = stmt.targets.length;
        const nvals = stmt.values.length;

        // Prepare LHS descriptors
        const lhsDesc = [];
        for (const t of stmt.targets) {
          if (t.type === 'IdentExpr') {
            const loc = fs.resolveLocal(t.name);
            if (loc) {
              lhsDesc.push({ kind: 'local', reg: loc.reg, line: t.line });
            } else {
              const upv = fs.resolveUpvalue(t.name);
              if (upv !== -1) {
                lhsDesc.push({ kind: 'upval', idx: upv, line: t.line });
              } else {
                const c = fs.getOrAddConst(ConstantType.String, t.name);
                lhsDesc.push({ kind: 'global', constEntry: c, line: t.line });
              }
            }
          } else if (t.type === 'IndexExpr') {
            const tblReg = fs.allocReg(1);
            this.compileExprToReg(fs, t.base, tblReg);
            const keyRK = this.compileExprToRK(fs, t.index);
            lhsDesc.push({ kind: 'table', tblReg, keyRK, line: t.line });
          } else {
            throw new Error(`Invalid assignment target at line ${t.line}`);
          }
        }

        // Single target optimization when no LHS aliasing risk
        if (nvars === 1 && nvals === 1 && lhsDesc[0].kind === 'local') {
          this.compileExprToReg(fs, stmt.values[0], lhsDesc[0].reg);
          break;
        }

        // Evaluate all RHS into temporary registers
        const valStartReg = fs.freereg;
        for (let i = 0; i < nvals; i++) {
          const valExpr = stmt.values[i];
          const isLast = i === nvals - 1;
          if (isLast && nvars > nvals && this.isMultiRetExpr(valExpr)) {
            const needed = nvars - i;
            const r = fs.allocReg(needed);
            this.compileMultiRetExpr(fs, valExpr, r, needed);
          } else {
            const r = fs.allocReg(1);
            this.compileExprToReg(fs, valExpr, r);
          }
        }
        if (nvars > nvals && (nvals === 0 || !this.isMultiRetExpr(stmt.values[nvals - 1]))) {
          const extra = nvars - nvals;
          const rNil = fs.allocReg(extra);
          fs.emitABC(Opcode.LoadNil, rNil, rNil + extra - 1, 0, stmt.line);
        }

        // Store from temp registers into LHS targets
        for (let i = 0; i < nvars; i++) {
          const srcReg = valStartReg + i;
          const desc = lhsDesc[i];
          if (desc.kind === 'local') {
            if (desc.reg !== srcReg) {
              fs.emitABC(Opcode.Move, desc.reg, srcReg, 0, desc.line);
            }
          } else if (desc.kind === 'upval') {
            fs.emitABC(Opcode.SetUpval, srcReg, desc.idx, 0, desc.line);
          } else if (desc.kind === 'global') {
            fs.emitABx(
              Opcode.SetGlobal,
              srcReg,
              desc.constEntry.index,
              desc.line,
              desc.constEntry.constant
            );
          } else if (desc.kind === 'table') {
            fs.emitABC(
              Opcode.SetTable,
              desc.tblReg,
              desc.keyRK.rk,
              srcReg,
              desc.line,
              desc.keyRK.constRef,
              null
            );
          }
        }
        break;
      }

      case 'CallStmt': {
        const reg = fs.allocReg(1);
        this.compileMultiRetExpr(fs, stmt.expr, reg, 0);
        break;
      }

      case 'FuncDeclStmt': {
        if (stmt.isLocal) {
          const reg = fs.declareLocal(stmt.namePath[0]);
          const fnExpr = {
            type: 'FuncExpr',
            params: stmt.params,
            isVararg: stmt.isVararg,
            body: stmt.body,
            line: stmt.line,
            lastLine: stmt.lastLine,
          };
          this.compileExprToReg(fs, fnExpr, reg);
        } else {
          const fnExpr = {
            type: 'FuncExpr',
            params: stmt.params,
            isVararg: stmt.isVararg,
            body: stmt.body,
            line: stmt.line,
            lastLine: stmt.lastLine,
          };
          const fullPath = stmt.methodName
            ? [...stmt.namePath, stmt.methodName]
            : stmt.namePath;

          if (fullPath.length === 1) {
            const name = fullPath[0];
            const loc = fs.resolveLocal(name);
            if (loc) {
              this.compileExprToReg(fs, fnExpr, loc.reg);
            } else {
              const upv = fs.resolveUpvalue(name);
              const r = fs.allocReg(1);
              this.compileExprToReg(fs, fnExpr, r);
              if (upv !== -1) {
                fs.emitABC(Opcode.SetUpval, r, upv, 0, stmt.line);
              } else {
                const c = fs.getOrAddConst(ConstantType.String, name);
                fs.emitABx(Opcode.SetGlobal, r, c.index, stmt.line, c.constant);
              }
            }
          } else {
            let baseExpr = { type: 'IdentExpr', name: fullPath[0], line: stmt.line };
            for (let i = 1; i < fullPath.length - 1; i++) {
              baseExpr = {
                type: 'IndexExpr',
                base: baseExpr,
                index: { type: 'StringLiteral', value: fullPath[i], line: stmt.line },
                line: stmt.line,
              };
            }
            const tblReg = fs.allocReg(1);
            this.compileExprToReg(fs, baseExpr, tblReg);
            const keyConst = fs.getOrAddConst(
              ConstantType.String,
              fullPath[fullPath.length - 1]
            );
            const valReg = fs.allocReg(1);
            this.compileExprToReg(fs, fnExpr, valReg);
            const keyRK =
              keyConst.index <= 255
                ? { rk: keyConst.index + 256, constRef: keyConst.constant }
                : (() => {
                    const kr = fs.allocReg(1);
                    fs.emitABx(Opcode.LoadConst, kr, keyConst.index, stmt.line, keyConst.constant);
                    return { rk: kr, constRef: null };
                  })();
            fs.emitABC(
              Opcode.SetTable,
              tblReg,
              keyRK.rk,
              valReg,
              stmt.line,
              keyRK.constRef,
              null
            );
          }
        }
        break;
      }

      case 'IfStmt': {
        const endJumps = [];
        for (let i = 0; i < stmt.clauses.length; i++) {
          const clause = stmt.clauses[i];
          const falseJumps = [];
          this.compileCondJump(fs, clause.cond, falseJumps, clause.line);
          this.compileBlock(fs, clause.body);
          if (i < stmt.clauses.length - 1 || stmt.elseBody) {
            endJumps.push(fs.emitJmp(null, clause.line));
          }
          const nextTarget = this.getLabelHere(fs, clause.line);
          for (const fj of falseJumps) {
            fj.RefOperands[0] = nextTarget;
            nextTarget.BackReferences.push(fj);
          }
        }
        if (stmt.elseBody) {
          this.compileBlock(fs, stmt.elseBody);
        }
        if (endJumps.length > 0) {
          const endTarget = this.getLabelHere(fs, stmt.line);
          for (const ej of endJumps) {
            ej.RefOperands[0] = endTarget;
            endTarget.BackReferences.push(ej);
          }
        }
        break;
      }

      case 'CompoundAssignStmt': {
        const t = stmt.target;
        if (t.type === 'IdentExpr') {
          const loc = fs.resolveLocal(t.name);
          if (loc) {
            this.compileCompoundOp(fs, stmt.op, loc.reg, stmt.value, loc.reg, stmt.line);
          } else {
            const upv = fs.resolveUpvalue(t.name);
            const rTmp = fs.allocReg(1);
            if (upv !== -1) {
              fs.emitABC(Opcode.GetUpval, rTmp, upv, 0, stmt.line);
              this.compileCompoundOp(fs, stmt.op, rTmp, stmt.value, rTmp, stmt.line);
              fs.emitABC(Opcode.SetUpval, rTmp, upv, 0, stmt.line);
            } else {
              const c = fs.getOrAddConst(ConstantType.String, t.name);
              fs.emitABx(Opcode.GetGlobal, rTmp, c.index, stmt.line, c.constant);
              this.compileCompoundOp(fs, stmt.op, rTmp, stmt.value, rTmp, stmt.line);
              fs.emitABx(Opcode.SetGlobal, rTmp, c.index, stmt.line, c.constant);
            }
          }
        } else if (t.type === 'IndexExpr') {
          const tblReg = fs.allocReg(1);
          this.compileExprToReg(fs, t.base, tblReg);
          const keyRK = this.compileExprToRK(fs, t.index);
          const valReg = fs.allocReg(1);
          fs.emitABC(Opcode.GetTable, valReg, tblReg, keyRK.rk, stmt.line, null, keyRK.constRef);
          this.compileCompoundOp(fs, stmt.op, valReg, stmt.value, valReg, stmt.line);
          fs.emitABC(Opcode.SetTable, tblReg, keyRK.rk, valReg, stmt.line, keyRK.constRef, null);
        } else {
          throw new Error(`Invalid compound assignment target at line ${stmt.line}`);
        }
        break;
      }

      case 'WhileStmt': {
        const loopStart = this.getLabelHere(fs, stmt.line);
        const falseJumps = [];
        this.compileCondJump(fs, stmt.cond, falseJumps, stmt.line);

        const loopCtx = { breakJumps: [], continueJumps: [], scopeDepth: fs.scopeDepth };
        fs.loopStack.push(loopCtx);
        this.compileBlock(fs, stmt.body);
        fs.loopStack.pop();

        fs.emitJmp(loopStart, stmt.line);
        const loopEnd = this.getLabelHere(fs, stmt.line);
        for (const fj of falseJumps) {
          fj.RefOperands[0] = loopEnd;
          loopEnd.BackReferences.push(fj);
        }
        for (const bj of loopCtx.breakJumps) {
          bj.RefOperands[0] = loopEnd;
          loopEnd.BackReferences.push(bj);
        }
        for (const cj of loopCtx.continueJumps) {
          cj.RefOperands[0] = loopStart;
          loopStart.BackReferences.push(cj);
        }
        break;
      }

      case 'RepeatStmt': {
        const loopStart = this.getLabelHere(fs, stmt.line);
        const loopCtx = { breakJumps: [], continueJumps: [], scopeDepth: fs.scopeDepth };
        fs.loopStack.push(loopCtx);
        fs.enterScope();
        for (const s of stmt.body) {
          this.compileStmt(fs, s);
        }
        const condTarget = this.getLabelHere(fs, stmt.line);
        for (const cj of loopCtx.continueJumps) {
          cj.RefOperands[0] = condTarget;
          condTarget.BackReferences.push(cj);
        }
        const falseJumps = [];
        this.compileCondJump(fs, stmt.cond, falseJumps, stmt.line);
        fs.leaveScope(stmt.line);
        fs.loopStack.pop();

        for (const fj of falseJumps) {
          fj.RefOperands[0] = loopStart;
          loopStart.BackReferences.push(fj);
        }
        if (loopCtx.breakJumps.length > 0) {
          const loopEnd = this.getLabelHere(fs, stmt.line);
          for (const bj of loopCtx.breakJumps) {
            bj.RefOperands[0] = loopEnd;
            loopEnd.BackReferences.push(bj);
          }
        }
        break;
      }

      case 'ForNumStmt': {
        fs.enterScope();
        const rIdx = fs.declareLocal('(for index)');
        const rLim = fs.declareLocal('(for limit)');
        const rStp = fs.declareLocal('(for step)');
        this.compileExprToReg(fs, stmt.init, rIdx);
        this.compileExprToReg(fs, stmt.limit, rLim);
        this.compileExprToReg(fs, stmt.step, rStp);

        const rVar = fs.declareLocal(stmt.name);
        void rVar;
        const forPrep = fs.emitABx(Opcode.ForPrep, rIdx, 0, stmt.line);
        forPrep.InstructionType = InstructionType.AsBx;

        const bodyStart = this.getLabelHere(fs, stmt.line);
        const loopCtx = { breakJumps: [], continueJumps: [], scopeDepth: fs.scopeDepth };
        fs.loopStack.push(loopCtx);
        this.compileBlock(fs, stmt.body);
        fs.loopStack.pop();

        const forLoop = fs.emitABx(Opcode.ForLoop, rIdx, 0, stmt.line, bodyStart);
        forLoop.InstructionType = InstructionType.AsBx;
        forPrep.RefOperands[0] = forLoop;
        forLoop.BackReferences.push(forPrep);

        for (const cj of loopCtx.continueJumps) {
          cj.RefOperands[0] = forLoop;
          forLoop.BackReferences.push(cj);
        }

        if (loopCtx.breakJumps.length > 0) {
          const loopEnd = this.getLabelHere(fs, stmt.line);
          for (const bj of loopCtx.breakJumps) {
            bj.RefOperands[0] = loopEnd;
            loopEnd.BackReferences.push(bj);
          }
        }
        fs.leaveScope(stmt.line);
        break;
      }

      case 'ForInStmt': {
        fs.enterScope();
        const rGen = fs.declareLocal('(for generator)');
        const rState = fs.declareLocal('(for state)');
        const rCtrl = fs.declareLocal('(for control)');
        void rState;
        void rCtrl;

        const niter = stmt.iterators.length;
        for (let i = 0; i < niter; i++) {
          const isLast = i === niter - 1;
          const expr = stmt.iterators[i];
          if (isLast && i < 3 && this.isMultiRetExpr(expr)) {
            this.compileMultiRetExpr(fs, expr, rGen + i, 3 - i);
          } else if (i < 3) {
            this.compileExprToReg(fs, expr, rGen + i);
          } else {
            const tmp = fs.allocReg(1);
            this.compileExprToReg(fs, expr, tmp);
          }
        }
        if (niter < 3 && !this.isMultiRetExpr(stmt.iterators[niter - 1])) {
          fs.emitABC(Opcode.LoadNil, rGen + niter, rGen + 2, 0, stmt.line);
        }

        for (const name of stmt.names) {
          fs.declareLocal(name);
        }

        const jmpToTFor = fs.emitJmp(null, stmt.line);
        const bodyStart = this.getLabelHere(fs, stmt.line);

        const loopCtx = { breakJumps: [], continueJumps: [], scopeDepth: fs.scopeDepth };
        fs.loopStack.push(loopCtx);
        this.compileBlock(fs, stmt.body);
        fs.loopStack.pop();

        const tforInst = fs.emitABC(
          Opcode.TForLoop,
          rGen,
          0,
          stmt.names.length,
          stmt.line
        );
        jmpToTFor.RefOperands[0] = tforInst;
        tforInst.BackReferences.push(jmpToTFor);

        for (const cj of loopCtx.continueJumps) {
          cj.RefOperands[0] = tforInst;
          tforInst.BackReferences.push(cj);
        }

        fs.emitJmp(bodyStart, stmt.line);

        if (loopCtx.breakJumps.length > 0) {
          const loopEnd = this.getLabelHere(fs, stmt.line);
          for (const bj of loopCtx.breakJumps) {
            bj.RefOperands[0] = loopEnd;
            loopEnd.BackReferences.push(bj);
          }
        }
        fs.leaveScope(stmt.line);
        break;
      }

      case 'BreakStmt': {
        if (fs.loopStack.length === 0) {
          throw new Error(`'break' outside loop at line ${stmt.line}`);
        }
        const topLoop = fs.loopStack[fs.loopStack.length - 1];
        topLoop.breakJumps.push(fs.emitJmp(null, stmt.line));
        break;
      }

      case 'ContinueStmt': {
        if (fs.loopStack.length === 0) {
          throw new Error(`'continue' outside loop at line ${stmt.line}`);
        }
        const topLoop = fs.loopStack[fs.loopStack.length - 1];
        topLoop.continueJumps.push(fs.emitJmp(null, stmt.line));
        break;
      }

      case 'ReturnStmt': {
        const nret = stmt.values.length;
        if (nret === 0) {
          fs.emitABC(Opcode.Return, 0, 1, 0, stmt.line);
        } else {
          const retBase = fs.freereg;
          for (let i = 0; i < nret; i++) {
            const v = stmt.values[i];
            const isLast = i === nret - 1;
            if (isLast && this.isMultiRetExpr(v)) {
              const r = fs.allocReg(1);
              this.compileMultiRetExpr(fs, v, r, -1); // -1 => multiret (C=0)
              fs.emitABC(Opcode.Return, retBase, 0, 0, stmt.line);
              return;
            } else {
              const r = fs.allocReg(1);
              this.compileExprToReg(fs, v, r);
            }
          }
          fs.emitABC(Opcode.Return, retBase, nret + 1, 0, stmt.line);
        }
        break;
      }
    }
  }

  compileCompoundOp(fs, op, srcReg, rhsExpr, destReg, line = 1) {
    const savedFree = Math.max(fs.freereg, destReg + 1, srcReg + 1);
    if (op === '//') {
      const rReg = fs.allocReg(1);
      this.compileExprToReg(fs, rhsExpr, rReg);
      const tmpReg = fs.allocReg(1);
      fs.emitABC(Opcode.Mod, tmpReg, srcReg, rReg, line);
      fs.emitABC(Opcode.Sub, srcReg, srcReg, tmpReg, line);
      fs.emitABC(Opcode.Div, destReg, srcReg, rReg, line);
    } else if (op === '..') {
      const startReg = fs.allocReg(2);
      fs.emitABC(Opcode.Move, startReg, srcReg, 0, line);
      this.compileExprToReg(fs, rhsExpr, startReg + 1);
      fs.emitABC(Opcode.Concat, destReg, startReg, startReg + 1, line);
    } else {
      const rRK = this.compileExprToRK(fs, rhsExpr);
      const opMap = {
        '+': Opcode.Add,
        '-': Opcode.Sub,
        '*': Opcode.Mul,
        '/': Opcode.Div,
        '%': Opcode.Mod,
        '^': Opcode.Pow,
      };
      fs.emitABC(opMap[op], destReg, srcReg, rRK.rk, line, null, rRK.constRef);
    }
    fs.setFreeReg(savedFree);
  }

  getLabelHere(fs, line = 1) {
    // Emit a no-op MOVE R0 R0 that serves as a stable jump target instruction reference
    const r = 0;
    return fs.emitABC(Opcode.Move, r, r, 0, line);
  }

  compileCondJump(fs, condExpr, falseJumps, line) {
    // Emits instructions that fall through when `condExpr` is truthy,
    // and jump (appended to `falseJumps`) when `condExpr` is falsy.
    if (condExpr.type === 'UnaryExpr' && condExpr.op === 'not') {
      const trueJumps = [];
      this.compileCondJumpTrue(fs, condExpr.arg, trueJumps, line);
      falseJumps.push(...trueJumps);
      return;
    }

    if (condExpr.type === 'BinaryExpr') {
      const op = condExpr.op;
      if (op === '==' || op === '~=' || op === '<' || op === '<=' || op === '>' || op === '>=') {
        const leftRK = this.compileExprToRK(fs, condExpr.left);
        const rightRK = this.compileExprToRK(fs, condExpr.right);
        let opc = Opcode.Eq;
        let a = 0;
        let bRK = leftRK;
        let cRK = rightRK;

        if (op === '==') { opc = Opcode.Eq; a = 0; }
        else if (op === '~=') { opc = Opcode.Eq; a = 1; }
        else if (op === '<') { opc = Opcode.Lt; a = 0; }
        else if (op === '<=') { opc = Opcode.Le; a = 0; }
        else if (op === '>') { opc = Opcode.Lt; a = 0; bRK = rightRK; cRK = leftRK; }
        else if (op === '>=') { opc = Opcode.Le; a = 0; bRK = rightRK; cRK = leftRK; }

        fs.emitABC(opc, a, bRK.rk, cRK.rk, line, bRK.constRef, cRK.constRef);
        falseJumps.push(fs.emitJmp(null, line));
        return;
      }

      if (op === 'and') {
        this.compileCondJump(fs, condExpr.left, falseJumps, line);
        this.compileCondJump(fs, condExpr.right, falseJumps, line);
        return;
      }

      if (op === 'or') {
        const trueJumps = [];
        this.compileCondJumpTrue(fs, condExpr.left, trueJumps, line);
        this.compileCondJump(fs, condExpr.right, falseJumps, line);
        const bodyTarget = this.getLabelHere(fs, line);
        for (const tj of trueJumps) {
          tj.RefOperands[0] = bodyTarget;
          bodyTarget.BackReferences.push(tj);
        }
        return;
      }
    }

    const r = fs.allocReg(1);
    this.compileExprToReg(fs, condExpr, r);
    // OpTest (C == 0): if Stk[A] then InstrPoint=InstrPoint+1 (skips JMP) else InstrPoint=InstrPoint+Inst[OP_B] (takes JMP)
    fs.emitABC(Opcode.Test, r, 0, 0, line);
    falseJumps.push(fs.emitJmp(null, line));
  }

  compileCondJumpTrue(fs, condExpr, trueJumps, line) {
    // Falls through when `condExpr` is FALSY, jumps to `trueJumps` when `condExpr` is TRUTHY
    const r = fs.allocReg(1);
    this.compileExprToReg(fs, condExpr, r);
    // OpTestC (C == 1): if not Stk[A] then InstrPoint=InstrPoint+1 (skips JMP) else jumps
    fs.emitABC(Opcode.Test, r, 0, 1, line);
    trueJumps.push(fs.emitJmp(null, line));
  }

  compileExprToRK(fs, expr) {
    if (expr.type === 'NumberLiteral') {
      const c = fs.getOrAddConst(ConstantType.Number, expr.value);
      if (c.index <= 255) return { rk: c.index + 256, constRef: c.constant };
    } else if (expr.type === 'StringLiteral') {
      const c = fs.getOrAddConst(ConstantType.String, expr.value);
      if (c.index <= 255) return { rk: c.index + 256, constRef: c.constant };
    } else if (expr.type === 'BoolLiteral') {
      const c = fs.getOrAddConst(ConstantType.Boolean, expr.value);
      if (c.index <= 255) return { rk: c.index + 256, constRef: c.constant };
    } else if (expr.type === 'IdentExpr') {
      const loc = fs.resolveLocal(expr.name);
      if (loc) return { rk: loc.reg, constRef: null };
    }
    const r = fs.allocReg(1);
    this.compileExprToReg(fs, expr, r);
    return { rk: r, constRef: null };
  }

  compileMultiRetExpr(fs, expr, destReg, numResults) {
    // numResults:
    //   -1 => multiret (C = 0)
    //    0 => 0 results (C = 1)
    //   >0 => N results (C = numResults + 1)
    const cVal = numResults === -1 ? 0 : numResults + 1;

    if (expr.type === 'VarargExpr') {
      const bVal = numResults === -1 ? 0 : numResults;
      fs.emitABC(Opcode.VarArg, destReg, bVal, 0, expr.line);
      return;
    }

    if (expr.type === 'CallExpr') {
      this.compileExprToReg(fs, expr.func, destReg);
      const nargs = expr.args.length;
      let bVal = nargs + 1;
      for (let i = 0; i < nargs; i++) {
        const arg = expr.args[i];
        const argReg = destReg + 1 + i;
        if (argReg >= fs.freereg) fs.allocReg(argReg - fs.freereg + 1);
        const isLast = i === nargs - 1;
        if (isLast && this.isMultiRetExpr(arg)) {
          this.compileMultiRetExpr(fs, arg, argReg, -1);
          bVal = 0;
        } else {
          this.compileExprToReg(fs, arg, argReg);
        }
      }
      fs.emitABC(Opcode.Call, destReg, bVal, cVal, expr.line);
      fs.setFreeReg(destReg + (numResults > 0 ? numResults : 1));
      return;
    }

    if (expr.type === 'MethodCallExpr') {
      if (destReg + 1 >= fs.freereg) fs.allocReg(destReg + 2 - fs.freereg);
      const recvReg = fs.allocReg(1);
      this.compileExprToReg(fs, expr.receiver, recvReg);
      const mConst = fs.getOrAddConst(ConstantType.String, expr.method);
      const mRK =
        mConst.index <= 255
          ? { rk: mConst.index + 256, constRef: mConst.constant }
          : (() => {
              const r = fs.allocReg(1);
              fs.emitABx(Opcode.LoadConst, r, mConst.index, expr.line, mConst.constant);
              return { rk: r, constRef: null };
            })();
      fs.emitABC(Opcode.Self, destReg, recvReg, mRK.rk, expr.line, null, mRK.constRef);

      const nargs = expr.args.length;
      let bVal = nargs + 2; // includes implicit self at destReg + 1
      for (let i = 0; i < nargs; i++) {
        const arg = expr.args[i];
        const argReg = destReg + 2 + i;
        if (argReg >= fs.freereg) fs.allocReg(argReg - fs.freereg + 1);
        const isLast = i === nargs - 1;
        if (isLast && this.isMultiRetExpr(arg)) {
          this.compileMultiRetExpr(fs, arg, argReg, -1);
          bVal = 0;
        } else {
          this.compileExprToReg(fs, arg, argReg);
        }
      }
      fs.emitABC(Opcode.Call, destReg, bVal, cVal, expr.line);
      fs.setFreeReg(destReg + (numResults > 0 ? numResults : 1));
      return;
    }

    this.compileExprToReg(fs, expr, destReg);
  }

  compileExprToReg(fs, expr, destReg) {
    const savedFree = Math.max(fs.freereg, destReg + 1);

    switch (expr.type) {
      case 'ParenExpr':
        this.compileExprToReg(fs, expr.expr, destReg);
        break;

      case 'IfExpr': {
        const endJumps = [];
        for (let i = 0; i < expr.clauses.length; i++) {
          const clause = expr.clauses[i];
          const falseJumps = [];
          this.compileCondJump(fs, clause.cond, falseJumps, clause.line);
          this.compileExprToReg(fs, clause.expr, destReg);
          endJumps.push(fs.emitJmp(null, clause.line));
          const nextLbl = this.getLabelHere(fs, clause.line);
          for (const fj of falseJumps) {
            fj.RefOperands[0] = nextLbl;
            nextLbl.BackReferences.push(fj);
          }
        }
        this.compileExprToReg(fs, expr.elseExpr, destReg);
        const endLbl = this.getLabelHere(fs, expr.line);
        for (const ej of endJumps) {
          ej.RefOperands[0] = endLbl;
          endLbl.BackReferences.push(ej);
        }
        break;
      }

      case 'NilLiteral':
        fs.emitABC(Opcode.LoadNil, destReg, destReg, 0, expr.line);
        break;

      case 'BoolLiteral':
        fs.emitABC(Opcode.LoadBool, destReg, expr.value ? 1 : 0, 0, expr.line);
        break;

      case 'NumberLiteral': {
        const c = fs.getOrAddConst(ConstantType.Number, expr.value);
        fs.emitABx(Opcode.LoadConst, destReg, c.index, expr.line, c.constant);
        break;
      }

      case 'StringLiteral': {
        const c = fs.getOrAddConst(ConstantType.String, expr.value);
        fs.emitABx(Opcode.LoadConst, destReg, c.index, expr.line, c.constant);
        break;
      }

      case 'VarargExpr':
        this.compileMultiRetExpr(fs, expr, destReg, 1);
        break;

      case 'IdentExpr': {
        const loc = fs.resolveLocal(expr.name);
        if (loc) {
          if (loc.reg !== destReg) {
            fs.emitABC(Opcode.Move, destReg, loc.reg, 0, expr.line);
          }
        } else {
          const upv = fs.resolveUpvalue(expr.name);
          if (upv !== -1) {
            fs.emitABC(Opcode.GetUpval, destReg, upv, 0, expr.line);
          } else {
            const c = fs.getOrAddConst(ConstantType.String, expr.name);
            fs.emitABx(Opcode.GetGlobal, destReg, c.index, expr.line, c.constant);
          }
        }
        break;
      }

      case 'IndexExpr': {
        const baseReg = fs.allocReg(1);
        this.compileExprToReg(fs, expr.base, baseReg);
        const keyRK = this.compileExprToRK(fs, expr.index);
        fs.emitABC(
          Opcode.GetTable,
          destReg,
          baseReg,
          keyRK.rk,
          expr.line,
          null,
          keyRK.constRef
        );
        break;
      }

      case 'CallExpr':
      case 'MethodCallExpr':
        this.compileMultiRetExpr(fs, expr, destReg, 1);
        break;

      case 'FuncExpr': {
        const subChunk = this.compileFunction(
          fs,
          '',
          expr.params,
          expr.isVararg,
          expr.body,
          expr.line,
          expr.lastLine
        );
        const protoIdx = fs.chunk.Functions.length;
        fs.chunk.Functions.push(subChunk);
        fs.chunk.FunctionMap.set(subChunk, protoIdx);

        fs.emitABx(Opcode.Closure, destReg, protoIdx, expr.line, subChunk);
        // Emit upvalue binding pseudo-instructions (MOVE for in-stack local, GETUPVAL for parent upval)
        // Find the FuncState upvalues we recorded on subChunk
        const subUpvals = subChunk._compilerUpvalues || [];
        for (const uv of subUpvals) {
          if (uv.inStack) {
            fs.emitABC(Opcode.Move, 0, uv.index, 0, expr.line);
          } else {
            fs.emitABC(Opcode.GetUpval, 0, uv.index, 0, expr.line);
          }
        }
        break;
      }

      case 'TableExpr': {
        const arrayFields = expr.fields.filter((f) => f.type === 'array');
        const hashFields = expr.fields.filter((f) => f.type === 'hash');
        fs.emitABC(
          Opcode.NewTable,
          destReg,
          Math.min(arrayFields.length, 50),
          Math.min(hashFields.length, 50),
          expr.line
        );

        // Populate hash fields first
        for (const hf of hashFields) {
          const kRK = this.compileExprToRK(fs, hf.key);
          const vRK = this.compileExprToRK(fs, hf.value);
          fs.emitABC(
            Opcode.SetTable,
            destReg,
            kRK.rk,
            vRK.rk,
            expr.line,
            kRK.constRef,
            vRK.constRef
          );
          fs.setFreeReg(savedFree);
        }

        // Populate array fields in batches of 50 using SETLIST
        if (arrayFields.length > 0) {
          let batchIndex = 1;
          let countInBatch = 0;
          for (let i = 0; i < arrayFields.length; i++) {
            const af = arrayFields[i].value;
            const elemReg = destReg + 1 + countInBatch;
            if (elemReg >= fs.freereg) fs.allocReg(elemReg - fs.freereg + 1);
            const isLast = i === arrayFields.length - 1;
            if (isLast && this.isMultiRetExpr(af)) {
              this.compileMultiRetExpr(fs, af, elemReg, -1);
              fs.emitABC(Opcode.SetList, destReg, 0, batchIndex, expr.line);
              countInBatch = 0;
            } else {
              this.compileExprToReg(fs, af, elemReg);
              countInBatch++;
              if (countInBatch === 50 || isLast) {
                fs.emitABC(Opcode.SetList, destReg, countInBatch, batchIndex, expr.line);
                batchIndex++;
                countInBatch = 0;
                fs.setFreeReg(savedFree);
              }
            }
          }
        }
        break;
      }

      case 'UnaryExpr': {
        const rArg = fs.allocReg(1);
        this.compileExprToReg(fs, expr.arg, rArg);
        let op = Opcode.Unm;
        if (expr.op === 'not') op = Opcode.Not;
        else if (expr.op === '#') op = Opcode.Len;
        fs.emitABC(op, destReg, rArg, 0, expr.line);
        break;
      }

      case 'BinaryExpr': {
        const op = expr.op;
        if (op === '//') {
          const lReg = fs.allocReg(1);
          this.compileExprToReg(fs, expr.left, lReg);
          const rReg = fs.allocReg(1);
          this.compileExprToReg(fs, expr.right, rReg);
          const tmpReg = fs.allocReg(1);
          fs.emitABC(Opcode.Mod, tmpReg, lReg, rReg, expr.line);
          fs.emitABC(Opcode.Sub, tmpReg, lReg, tmpReg, expr.line);
          fs.emitABC(Opcode.Div, destReg, tmpReg, rReg, expr.line);
          break;
        }
        if (op === '+' || op === '-' || op === '*' || op === '/' || op === '%' || op === '^') {
          const lRK = this.compileExprToRK(fs, expr.left);
          const rRK = this.compileExprToRK(fs, expr.right);
          const opMap = {
            '+': Opcode.Add,
            '-': Opcode.Sub,
            '*': Opcode.Mul,
            '/': Opcode.Div,
            '%': Opcode.Mod,
            '^': Opcode.Pow,
          };
          fs.emitABC(
            opMap[op],
            destReg,
            lRK.rk,
            rRK.rk,
            expr.line,
            lRK.constRef,
            rRK.constRef
          );
          break;
        }

        if (op === '..') {
          // Flatten chained a .. b .. c into consecutive registers
          const parts = [];
          let cur = expr;
          while (cur.type === 'BinaryExpr' && cur.op === '..') {
            parts.push(cur.left);
            cur = cur.right;
          }
          parts.push(cur);

          const startReg = fs.allocReg(parts.length);
          for (let i = 0; i < parts.length; i++) {
            this.compileExprToReg(fs, parts[i], startReg + i);
          }
          fs.emitABC(
            Opcode.Concat,
            destReg,
            startReg,
            startReg + parts.length - 1,
            expr.line
          );
          break;
        }

        if (op === '==' || op === '~=' || op === '<' || op === '<=' || op === '>' || op === '>=') {
          const falseJumps = [];
          this.compileCondJump(fs, expr, falseJumps, expr.line);
          const trueLoad = fs.emitABC(Opcode.LoadBool, destReg, 1, 1, expr.line);
          const falseLoad = fs.emitABC(Opcode.LoadBool, destReg, 0, 0, expr.line);
          for (const fj of falseJumps) {
            fj.RefOperands[0] = falseLoad;
            falseLoad.BackReferences.push(fj);
          }
          void trueLoad;
          break;
        }

        if (op === 'and') {
          // Evaluate left into destReg; if falsy, skip right and keep destReg
          this.compileExprToReg(fs, expr.left, destReg);
          // OpTestC (C=1): if not Stk[destReg] then skip JMP (so jump is taken when Stk[destReg] IS truthy? Wait:
          // OpTest (C=0): if Stk[destReg] then InstrPoint=InstrPoint+1 (skips JMP, evaluates right) else jumps to end!
          fs.emitABC(Opcode.Test, destReg, 0, 0, expr.line);
          const jmpEnd = fs.emitJmp(null, expr.line);
          this.compileExprToReg(fs, expr.right, destReg);
          const endLbl = this.getLabelHere(fs, expr.line);
          jmpEnd.RefOperands[0] = endLbl;
          endLbl.BackReferences.push(jmpEnd);
          break;
        }

        if (op === 'or') {
          // Evaluate left into destReg; if truthy, jump to end; else evaluate right into destReg
          this.compileExprToReg(fs, expr.left, destReg);
          // OpTestC (C=1): if not Stk[destReg] then InstrPoint=InstrPoint+1 (skips JMP, evaluates right) else jumps to end!
          fs.emitABC(Opcode.Test, destReg, 0, 1, expr.line);
          const jmpEnd = fs.emitJmp(null, expr.line);
          this.compileExprToReg(fs, expr.right, destReg);
          const endLbl = this.getLabelHere(fs, expr.line);
          jmpEnd.RefOperands[0] = endLbl;
          endLbl.BackReferences.push(jmpEnd);
          break;
        }
        break;
      }
    }

    fs.setFreeReg(savedFree);
  }
}

// Ensure FuncState stores upvalue descriptors on chunk so Closure emission can read them
const _origCompileFunction = LuaCompiler.prototype.compileFunction;
LuaCompiler.prototype.compileFunction = function (
  parentState,
  name,
  params,
  isVararg,
  body,
  line,
  lastLine
) {
  const fs = new FuncState(parentState, name, line, lastLine);
  fs.chunk.ParameterCount = params.length;
  fs.chunk.VarargFlag = isVararg ? 2 : 0;

  for (const p of params) {
    fs.declareLocal(p);
  }

  this.compileBlock(fs, body);
  fs.emitABC(Opcode.Return, 0, 1, 0, lastLine || line);

  fs.chunk._compilerUpvalues = fs.upvalues;
  fs.chunk.UpdateMappings();
  for (const ins of fs.chunk.Instructions) {
    ins.UpdateRegisters();
  }
  return fs.chunk;
};

// ============================================================================
// 12. Main IB2 Obfuscator Class & CLI Entrypoint (Program.cs)
// ============================================================================

class IB2 {
  static ObfuscateSource(sourceText, settings = new ObfuscationSettings(), options = {}) {
    console.log('Stripping comments & expanding Luau interpolated strings...');
    const stripped = LuaLexer.expandInterpolatedStrings(LuaLexer.stripComments(sourceText));

    console.log('Encrypting constants...');
    const encryptedSrc = new ConstantEncryption(settings, stripped).EncryptStrings();

    console.log('Compiling...');
    let lChunk;
    if (options.luacPath) {
      const tmpIn = path.join(options.tempDir || '.', '_ib2_tmp_in.lua');
      const tmpOut = path.join(options.tempDir || '.', '_ib2_tmp_out.luac');
      fs.writeFileSync(tmpIn, latin1ToBuffer(encryptedSrc));
      try {
        child_process.execFileSync(options.luacPath, ['-o', tmpOut, tmpIn], {
          stdio: 'pipe',
        });
        const luacBuf = fs.readFileSync(tmpOut);
        lChunk = new Deserializer(luacBuf).DecodeFile();
      } finally {
        if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
        if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
      }
    } else {
      lChunk = LuaCompiler.compile(encryptedSrc, '@input.lua');
    }

    return IB2.ObfuscateChunk(lChunk, settings);
  }

  static ObfuscateChunk(lChunk, settings = new ObfuscationSettings()) {
    console.log('Obfuscating...');
    if (settings.ControlFlow) {
      const cf = new CFContext(lChunk);
      cf.DoChunks();
    }

    console.log('Serializing...');
    const context = new ObfuscationContext(lChunk);
    let vm = new Generator(context).GenerateVM(settings);

    console.log('Minifying & applying aesthetic numberless transform...');
    vm = LuaMinifier.minify(vm);

    console.log('Watermark...');
    return VMStrings.Watermark + vm;
  }

  static Obfuscate(workingDir, inputPath, settings = new ObfuscationSettings(), options = {}) {
    if (!fs.existsSync(inputPath)) {
      throw new Error(`Invalid input file: ${inputPath}`);
    }

    console.log('Checking file...');
    const rawBuf = fs.readFileSync(inputPath);

    // Check if input is already compiled Lua 5.1 bytecode (\x1bLua\x51)
    if (
      rawBuf.length >= 5 &&
      rawBuf[0] === 0x1b &&
      rawBuf[1] === 0x4c &&
      rawBuf[2] === 0x75 &&
      rawBuf[3] === 0x61 &&
      rawBuf[4] === 0x51
    ) {
      const lChunk = new Deserializer(rawBuf).DecodeFile();
      return IB2.ObfuscateChunk(lChunk, settings);
    }

    const sourceText = bufferToLatin1(rawBuf);
    return IB2.ObfuscateSource(sourceText, settings, {
      ...options,
      tempDir: workingDir,
    });
  }
}

function printHelp() {
  console.log(`Usage:
  node cli/main.js <input.lua|input.luac> [options]

Options:
  -o, --out <file>                 Output file path (default: out.lua)
  --vm-compress                    Enable LZW Base36 bytecode compression (default: true)
  --no-vm-compress                 Disable LZW Base36 bytecode compression
  --runtime-decode <mode>          Roblox Runtime Decode Payload mode:
                                     lzw              - Classic IronBrew2 Base36 LZW (default)
                                     encoding-service - Roblox EncodingService:Base64Decode + buffer + bit32
                                     http-service     - Roblox HttpService:JSONDecode 32-bit stream + bit32
                                     hybrid           - Combo HttpService + EncodingService SHA-256 + buffer
                                     roblox-only      - 4-Stage Roblox-Service-Only (JSON + Base64 + Zstd + SHA256 KDF)
                                     path2d           - 5-Stage Path2D Geometry 1024-Byte Rotating Key + Zstd + SHA256 + Custom Buffer/Table API
  --roblox-only                    Shortcut for --runtime-decode roblox-only --roblox-strict
  --path2d-layer, --path2d         Enable Final Layer Path2D 1024-byte rotating key + Custom Buffer/Table API
  --roblox-strict                  Require real Roblox Engine services (anti-offline Lua 5.1 dumper)
  --place-lock <PlaceId>           Bind Roblox-only SHA-256 KDF key to game.PlaceId
  --game-lock <GameId>             Bind Roblox-only SHA-256 KDF key to game.GameId
  --wrap-compress                  Wrap entire generated VM in outer LZW loader (Lua/compress.lua)
  --encrypt-strings                Encrypt all string constants with inline XOR decryptors
  --encrypt-important-strings      Encrypt strings containing http/function/metatable/local
  --decrypt-table-len <n>          Max XOR key table length for string decryptor (default: 500)
  --control-flow                   Enable control-flow obfuscation & inlining (default: true)
  --no-control-flow                Disable control-flow obfuscation
  --mutate                         Enable virtual opcode mutations (default: true)
  --no-mutate                      Disable virtual opcode mutations
  --max-mutations <n>              Maximum number of mutated opcodes (default: 300)
  --super-operators                Enable Mega & Mini super-operators (default: true)
  --no-super-operators             Disable super-operators
  --max-mega <n>                   Max Mega super-operators (default: 200)
  --max-mini <n>                   Max Mini super-operators (default: 150)
  --preserve-line-info             Preserve source line numbers for error reporting
  --no-minify                      Skip Lua variable renaming & whitespace minification
  --luac <path>                    Optional path to external luac 5.1 binary
  -h, --help                       Show this help message
`);
}

function runCli(argv) {
  const args = argv.slice(2);
  if (args.length === 0 || args.includes('-h') || args.includes('--help')) {
    printHelp();
    process.exit(args.length === 0 ? 1 : 0);
  }

  const settings = new ObfuscationSettings();
  let inputFile = null;
  let outputFile = 'out.lua';
  let luacPath = null;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    switch (arg) {
      case '-o':
      case '--out':
      case '--output':
        outputFile = args[++i];
        break;
      case '--vm-compress':
      case '--bytecode-compress':
        settings.BytecodeCompress = true;
        break;
      case '--no-vm-compress':
      case '--no-bytecode-compress':
        settings.BytecodeCompress = false;
        break;
      case '--runtime-decode':
      case '--roblox-decode':
        settings.RuntimeDecodeMode = args[++i] || 'hybrid';
        break;
      case '--roblox-only':
      case '--roblox-exclusive':
        settings.RuntimeDecodeMode = 'roblox-only';
        settings.RobloxStrict = true;
        break;
      case '--path2d':
      case '--path2d-layer':
        settings.RuntimeDecodeMode = 'path2d';
        settings.Path2DLayer = true;
        settings.RobloxStrict = true;
        break;
      case '--roblox-strict':
        settings.RobloxStrict = true;
        break;
      case '--place-lock':
        settings.PlaceLock = args[++i];
        break;
      case '--game-lock':
        settings.GameLock = args[++i];
        break;
      case '--wrap-compress':
      case '--lzw-wrap':
        settings.WrapCompress = true;
        break;
      case '--encrypt-strings':
        settings.EncryptStrings = true;
        break;
      case '--no-encrypt-strings':
        settings.EncryptStrings = false;
        break;
      case '--encrypt-important-strings':
        settings.EncryptImportantStrings = true;
        break;
      case '--decrypt-table-len':
        settings.DecryptTableLen = parseInt(args[++i], 10) || 500;
        break;
      case '--control-flow':
        settings.ControlFlow = true;
        break;
      case '--no-control-flow':
        settings.ControlFlow = false;
        break;
      case '--mutate':
        settings.Mutate = true;
        break;
      case '--no-mutate':
        settings.Mutate = false;
        break;
      case '--max-mutations':
        settings.MaxMutations = parseInt(args[++i], 10) || 300;
        break;
      case '--super-operators':
        settings.SuperOperators = true;
        break;
      case '--no-super-operators':
        settings.SuperOperators = false;
        break;
      case '--max-mega':
        settings.MaxMegaSuperOperators = parseInt(args[++i], 10) || 200;
        break;
      case '--max-mini':
        settings.MaxMiniSuperOperators = parseInt(args[++i], 10) || 150;
        break;
      case '--preserve-line-info':
        settings.PreserveLineInfo = true;
        break;
      case '--minify':
        settings.MinifyOutput = true;
        break;
      case '--no-minify':
        settings.MinifyOutput = false;
        break;
      case '--luac':
        luacPath = args[++i];
        break;
      default:
        if (!arg.startsWith('-') && !inputFile) {
          inputFile = arg;
        } else {
          console.error(`Unknown argument: ${arg}`);
          process.exit(1);
        }
        break;
    }
  }

  if (!inputFile) {
    console.error('ERR: Missing input Lua file.');
    printHelp();
    process.exit(1);
  }

  try {
    const outLua = IB2.Obfuscate(process.cwd(), inputFile, settings, { luacPath });
    fs.writeFileSync(outputFile, latin1ToBuffer(outLua));
    console.log(`Done! Output written to ${outputFile}`);
  } catch (err) {
    console.error('ERR: ' + (err && err.stack ? err.stack : err));
    process.exit(1);
  }
}

if (require.main === module) {
  runCli(process.argv);
}

module.exports = {
  ConstantType,
  InstructionType,
  Opcode,
  Constant,
  Instruction,
  Chunk,
  Deserializer,
  Serializer,
  VanillaSerializer,
  ObfuscationSettings,
  ObfuscationContext,
  ConstantEncryption,
  Decryptor,
  CFContext,
  CFGenerator,
  RuntimePayloadEncoder,
  Generator,
  VMStrings,
  LuaLexer,
  LuaParser,
  LuaCompiler,
  LuaMinifier,
  IB2,
};
