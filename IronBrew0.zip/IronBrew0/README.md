# IronBrew0 v0.002

Modular Lua/Luau obfuscation framework.

## Roblox executor – max protection

```bash
# Strongest current pipeline: rename + encrypted constants + custom bytecode + embedded VM
lua cli.lua yourscript.lua --preset executor -o protected.lua

# Same thing explicitly:
lua cli.lua yourscript.lua --vm --rename --minify --single-line -o protected.lua

# maximum preset == executor VM path
lua cli.lua yourscript.lua --preset maximum -o protected.lua
```

Output is a **self-contained** script: custom bytecode blob + interpreter.  
No plain locals/control-flow to env-log — logic lives in the numeric opcode stream.

## CLI

```
lua cli.lua <input.lua> [options]

  -o, --output <file>
  --preset <name>     minimum|maximum|lua51|lua53|luajit|roblox|luau|executor
  --minify / --no-minify
  --rename / --no-rename
  --control-flow      AST state-machine flattening (non-VM path)
  --vm                Custom bytecode + embedded VM (recommended for executors)
  --single-line
  --ir
  --config <file.json>
  --verbose
```

## Pipeline

```
Source → Lexer → Parser → AST → Rename
  ├─ (default) Minify → Lua source
  ├─ (--control-flow) Flatten → Minify → Lua source
  └─ (--vm / preset executor|maximum)
         → IR → Bytecode (optional XOR string constants)
         → Embed VM loader → single self-contained script
```

## Status

| Phase | Feature                    | Status |
|-------|----------------------------|--------|
| 1–3   | Lexer/Parser/AST, Rename, Minify | Done |
| 4     | IR                         | Done |
| 5     | Control-flow flattening    | Done |
| 6     | Custom bytecode            | Done |
| 7     | Embedded VM                | Done |
| 8     | Anti-tamper                | Planned |
| 9     | Presets (basic)            | Done |

## Note on protection strength

AST control-flow alone is easy to read/env-log (as you saw).  
`--vm` / `--preset executor` is the real step up for executor targets: the payload is opcode numbers + a small interpreter, not structured Lua.

Still v0.002 — not production-grade anti-tamper yet.
