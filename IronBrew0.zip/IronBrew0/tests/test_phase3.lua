#!/usr/bin/env lua
-- IronBrew0 Phase 3 tests: Minification

package.path = "./?.lua;./?/init.lua;" .. package.path
local IronBrew0 = require("src.init")

local passed, failed = 0, 0
local function ok(c, m) if c then passed=passed+1 else failed=failed+1; print("FAIL: "..(m or"")) end end

print("=== IronBrew0 Phase 3 Tests ===\n")

-- Example from the spec
do
    local src = [[
local function hello(name)
    print("Hello, " .. name)
end

hello("World")
]]
    local out, err = IronBrew0.obfuscate(src, { rename = true, minify = true, singleLine = true })
    ok(err == nil, "no errors")
    ok(out ~= nil, "got output")
    ok(not out:find("\n"), "single line")
    ok(not out:find("  "), "no double spaces (aggressive)")
    -- must still be valid Lua
    local r = IronBrew0.parse(out)
    ok(#r.errors == 0, "minified code parses")
    print("  Minified example: " .. (out or ""):sub(1, 120) .. "...")
end

-- Rename + minify pipeline
do
    local src = "local foo = 1\nlocal bar = foo + 2\nprint(bar)"
    local out = IronBrew0.obfuscate(src, { rename = true, minify = true })
    ok(out:find("print"), "print kept")
    ok(not out:find("foo"), "foo renamed")
    local r = IronBrew0.parse(out)
    ok(#r.errors == 0, "pipeline output valid")
end

-- Preserve string content
do
    local src = [[local s = "Hello, World!" print(s)]]
    local out = IronBrew0.obfuscate(src, { rename = true, minify = true })
    ok(out:find("Hello, World!"), "string content preserved")
end

print(string.format("\nResults: %d passed, %d failed", passed, failed))
if failed > 0 then os.exit(1) else print("Phase 3 OK") end
