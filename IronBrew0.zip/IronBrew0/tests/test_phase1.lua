#!/usr/bin/env lua
-- IronBrew0 Phase 1 tests: Lexer + Parser + AST

package.path = "./?.lua;./?/init.lua;" .. package.path

local IronBrew0 = require("src.init")

local passed = 0
local failed = 0

local function assertEq(a, b, msg)
    if a == b then
        passed = passed + 1
        return true
    else
        failed = failed + 1
        print("FAIL: " .. (msg or "") .. " | expected " .. tostring(b) .. " got " .. tostring(a))
        return false
    end
end

local function assertTrue(cond, msg)
    if cond then
        passed = passed + 1
        return true
    else
        failed = failed + 1
        print("FAIL: " .. (msg or "assertion failed"))
        return false
    end
end

print("=== IronBrew0 Phase 1 Tests ===\n")

-- Test 1: Simple identifier
do
    local r = IronBrew0.parse("local x = 1")
    assertTrue(#r.errors == 0, "no parse errors")
    assertEq(r.ast.kind, "Chunk", "root is Chunk")
    assertEq(#r.ast.body, 1, "one statement")
    assertEq(r.ast.body[1].kind, "LocalStatement", "local statement")
    assertEq(r.ast.body[1].variables[1].name, "x", "var name x")
    assertEq(r.ast.body[1].init[1].value, 1, "init value 1")
end

-- Test 2: Function
do
    local src = [[
local function hello(name)
    print("Hello, " .. name)
end
hello("World")
]]
    local r = IronBrew0.parse(src)
    assertTrue(#r.errors == 0, "function parse ok")
    assertEq(#r.ast.body, 2, "two statements")
    assertEq(r.ast.body[1].kind, "FunctionDeclaration", "function decl")
    assertTrue(r.ast.body[1].isLocal, "is local")
    assertEq(r.ast.body[1].name.name, "hello", "function name")
    assertEq(r.ast.body[1].params[1].name, "name", "param name")
end

-- Test 3: If / while / for
do
    local src = [[
if a then
    b = 1
elseif c then
    d = 2
else
    e = 3
end
while true do break end
for i = 1, 10 do end
for k, v in pairs(t) do end
]]
    local r = IronBrew0.parse(src)
    assertTrue(#r.errors == 0, "control flow parse ok")
    assertEq(#r.ast.body, 4, "four statements")
    assertEq(r.ast.body[1].kind, "IfStatement", "if")
    assertEq(r.ast.body[2].kind, "WhileStatement", "while")
    assertEq(r.ast.body[3].kind, "ForNumericStatement", "numeric for")
    assertEq(r.ast.body[4].kind, "ForGenericStatement", "generic for")
end

-- Test 4: Table and call
do
    local src = [[local t = {a = 1, [2] = "x", 3} t:foo(1, 2)]]
    local r = IronBrew0.parse(src)
    assertTrue(#r.errors == 0, "table/call parse ok")
end

-- Test 5: Round-trip pretty print roughly works
do
    local src = 'local function hello(name)\n    print("Hello, " .. name)\nend\nhello("World")\n'
    local r = IronBrew0.parse(src)
    local out = IronBrew0.printAst(r.ast)
    assertTrue(#out > 10, "printer produces output")
    local r2 = IronBrew0.parse(out)
    assertTrue(#r2.errors == 0, "re-parse of printed AST ok")
end

-- Test 6: Comments are stripped
do
    local src = "-- comment\nlocal x = 1 -- trailing\n--[[ long\ncomment ]]\n"
    local r = IronBrew0.parse(src)
    assertTrue(#r.errors == 0, "comments stripped")
    assertEq(#r.ast.body, 1, "only one real statement")
end

-- Test 7: Strings preserved
do
    local src = 'local s = "hello\\nworld" local l = [[long string]]'
    local r = IronBrew0.parse(src)
    assertTrue(#r.errors == 0, "strings ok")
end

print(string.format("\nResults: %d passed, %d failed", passed, failed))
if failed > 0 then
    os.exit(1)
else
    print("Phase 1 OK")
end
