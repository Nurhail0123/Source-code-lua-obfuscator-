-- Verify per-build VM structural divergence + basic semantic correctness
package.path = "./?.lua;./?/init.lua;" .. package.path
local L = require("src.init")

local samples = {
  "print(40+2)",
  "local function f(x) return x*2 end print(f(21))",
  "local t={a=1,b=2} print(t.a+t.b)",
  "for i=1,3 do end print('ok')",
}

local function fp(s)
  local n = 0
  for i = 1, math.min(#s, 8000) do
    n = (n + (s:byte(i) or 0) * (i % 97)) % 1000000007
  end
  return n
end

local fails = 0
for si, src in ipairs(samples) do
  local outs = {}
  for seed = 10, 12 do
    local out, err = L.obfuscate(src, {
      preset = "executor",
      fatVM = false,
      antiTamper = false,
      scrambleOps = true,
      seed = seed,
      singleLine = true,
    })
    if not out then
      print("FAIL obfuscate", si, seed, err and err[1])
      fails = fails + 1
    else
      outs[#outs + 1] = out
      local ok, e = pcall(assert(load(out)))
      if not ok then
        print("FAIL run", si, seed, tostring(e):sub(1, 80))
        fails = fails + 1
      end
    end
  end
  if #outs >= 2 and outs[1] == outs[2] then
    print("FAIL identical builds", si)
    fails = fails + 1
  elseif #outs >= 2 then
    print("OK sample", si, "fps", fp(outs[1]), fp(outs[2]), fp(outs[3] or ""))
  end
end

-- modules present
for _, m in ipairs({
  "src.VM.Build.RandomSource",
  "src.VM.Build.OpcodeGenerator",
  "src.VM.Build.ConstantEncoder",
  "src.VM.Build.SerializerGenerator",
  "src.VM.Build.IntegrityGenerator",
  "src.VM.Build.HandlerGenerator",
}) do
  local ok = pcall(require, m)
  print(ok and "OK module" or "FAIL module", m)
  if not ok then fails = fails + 1 end
end

if fails > 0 then
  print("FAILED", fails)
  os.exit(1)
end
print("ALL PASSED")
