#!/usr/bin/env lua
package.path = "./?.lua;./?/init.lua;" .. package.path
local IB = require("src.init")
local passed, failed = 0, 0
local function ok(c, m)
  if c then passed = passed + 1 else failed = failed + 1; print("FAIL:", m) end
end

print("=== IronBrew0 Phase 6/7 VM Tests ===\n")

do
  local src = "print(10+20)"
  local out = IB.obfuscate(src, { vm = true, rename = true })
  ok(out and out:find("ironbrew0"), "emits IB header")
  ok(out and out:find("return%(function"), "wraps in function")
  local fn, err = load(out)
  ok(fn ~= nil, "load VM script: " .. tostring(err))
  -- capture print
  local printed
  local old = print
  print = function(v) printed = v end
  if fn then fn() end
  print = old
  ok(printed == 30, "print(10+20) => 30 got " .. tostring(printed))
end

do
  local src = [[
local function mul(a,b) return a*b end
print(mul(6,7))
]]
  local out = IB.obfuscate(src, { preset = "executor" })
  local printed
  local old = print
  print = function(v) printed = v end
  local fn = assert(load(out))
  fn()
  print = old
  ok(printed == 42, "executor preset mul => 42 got " .. tostring(printed))
end

do
  local src = 'print("hi")'
  local out = IB.obfuscate(src, { vm = true, encryptConstants = true })
  ok(out:find("{%d+") or out:find("ironbrew0"), "string pool or header present")
  local printed
  local old = print
  print = function(v) printed = v end
  assert(load(out))()
  print = old
  ok(printed == "hi", "encrypted string loads")
end

print(string.format("\nResults: %d passed, %d failed", passed, failed))
if failed > 0 then os.exit(1) else print("Phase 6/7 OK") end
