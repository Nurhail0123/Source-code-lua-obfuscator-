#!/usr/bin/env lua
-- IronBrew0 Phase 2 tests: Scope analysis + Identifier renaming

package.path = "./?.lua;./?/init.lua;" .. package.path

local IronBrew0 = require("src.init")

local passed, failed = 0, 0

local function assertTrue(cond, msg)
    if cond then passed = passed + 1
    else failed = failed + 1; print("FAIL: " .. (msg or "")) end
end

local function assertEq(a, b, msg)
    if a == b then passed = passed + 1
    else failed = failed + 1; print("FAIL: " .. (msg or "") .. " expected " .. tostring(b) .. " got " .. tostring(a)) end
end

print("=== IronBrew0 Phase 2 Tests ===\n")

-- Test 1: Basic local rename
do
    local src = [[
local foo = 1
local bar = foo + 2
print(bar)
]]
    local r = IronBrew0.parse(src)
    assertTrue(#r.errors == 0, "parse ok")
    IronBrew0.rename(r.ast)
    local out = IronBrew0.printAst(r.ast)
    -- foo and bar should be renamed to short names, print stays
    assertTrue(not out:find("foo"), "foo renamed")
    assertTrue(not out:find("bar"), "bar renamed")
    assertTrue(out:find("print"), "print preserved")
    -- re-parse must succeed
    local r2 = IronBrew0.parse(out)
    assertTrue(#r2.errors == 0, "renamed code re-parses")
end

-- Test 2: Function params and nested scopes
do
    local src = [[
local function hello(name)
    local msg = "Hello, " .. name
    print(msg)
end
hello("World")
]]
    local r = IronBrew0.parse(src)
    IronBrew0.rename(r.ast)
    local out = IronBrew0.printAst(r.ast)
    assertTrue(not out:find("hello") or out:find("function"), "hello may be renamed")
    assertTrue(not out:find("name"), "param renamed")
    assertTrue(not out:find("msg"), "local msg renamed")
    assertTrue(out:find("print"), "print preserved")
    local r2 = IronBrew0.parse(out)
    assertTrue(#r2.errors == 0, "nested rename re-parses")
end

-- Test 3: Globals and Roblox names not renamed
do
    local src = [[
local x = game.Workspace
local y = Vector3.new(1, 2, 3)
print(typeof(y))
]]
    local r = IronBrew0.parse(src)
    IronBrew0.rename(r.ast)
    local out = IronBrew0.printAst(r.ast)
    assertTrue(out:find("game"), "game preserved")
    assertTrue(out:find("Workspace") or out:find("workspace"), "Workspace preserved as member")
    assertTrue(out:find("Vector3"), "Vector3 preserved")
    assertTrue(out:find("typeof"), "typeof preserved")
    assertTrue(out:find("print"), "print preserved")
end

-- Test 4: Shadowing works
do
    local src = [[
local a = 1
do
    local a = 2
    print(a)
end
print(a)
]]
    local r = IronBrew0.parse(src)
    IronBrew0.rename(r.ast)
    local out = IronBrew0.printAst(r.ast)
    local r2 = IronBrew0.parse(out)
    assertTrue(#r2.errors == 0, "shadowing rename ok")
end

-- Test 5: Table keys (string) not treated as variables
do
    local src = [[local t = {foo = 1, ["bar"] = 2} print(t.foo)]]
    local r = IronBrew0.parse(src)
    IronBrew0.rename(r.ast)
    local out = IronBrew0.printAst(r.ast)
    assertTrue(out:find("foo"), "table key foo preserved")
    assertTrue(out:find("bar") or out:find('"bar"'), "string key preserved")
end

print(string.format("\nResults: %d passed, %d failed", passed, failed))
if failed > 0 then os.exit(1) else print("Phase 2 OK") end
