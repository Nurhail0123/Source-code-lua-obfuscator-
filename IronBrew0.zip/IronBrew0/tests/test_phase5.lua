#!/usr/bin/env lua
-- IronBrew0 Phase 5: Control-flow flattening tests

package.path = "./?.lua;./?/init.lua;" .. package.path
local IB = require("src.init")

local passed, failed = 0, 0
local function ok(c, m)
    if c then passed = passed + 1
    else failed = failed + 1; print("FAIL: " .. (m or "")) end
end

print("=== IronBrew0 Phase 5 Tests ===\n")

-- 1. Flattening produces a state machine and still parses
do
    local src = [[
local function demo(x)
    local a = x + 1
    local b = a * 2
    print(b)
    return b
end
demo(10)
]]
    local out, err = IB.obfuscate(src, {
        rename = true,
        minify = true,
        controlFlow = true,
        singleLine = true,
        minStatements = 2,
    })
    ok(err == nil and out ~= nil, "obfuscate with CF ok")
    ok(out:find("while"), "contains while dispatcher")
    ok(out:find("=="), "contains state comparisons")
    local r = IB.parse(out)
    ok(#r.errors == 0, "flattened code re-parses")
    print("  Sample: " .. (out or ""):sub(1, 160) .. "...")
end

-- 2. Semantic smoke: evaluate flattened code via load
do
    local src = [[
local function add(x, y)
    local s = x + y
    return s
end
return add(3, 4)
]]
    local out = IB.obfuscate(src, {
        rename = true,
        minify = true,
        controlFlow = true,
        minStatements = 2,
    })
    ok(out ~= nil, "got output for eval test")
    local fn, loadErr = load(out, "cf_test")
    ok(fn ~= nil, "load flattened code: " .. tostring(loadErr))
    if fn then
        local okCall, result = pcall(fn)
        ok(okCall, "execute flattened code")
        ok(result == 7, "result is 7 (got " .. tostring(result) .. ")")
    end
end

-- 3. Preset maximum enables CF
do
    local src = "local x=1 local y=x+2 print(y)"
    local out = IB.obfuscate(src, { preset = "maximum" })
    ok(out ~= nil, "maximum preset works")
    ok(out:find("while"), "maximum applies CF")
end

-- 4. Preset minimum does not force CF
do
    local src = "local x=1 local y=x+2 print(y)"
    local out = IB.obfuscate(src, { preset = "minimum", controlFlow = false })
    ok(out ~= nil, "minimum preset works")
    ok(not out:find("while true"), "minimum without CF stays linear")
end

-- 5. String content preserved
do
    local src = [[
local function hello(name)
    print("Hello, " .. name)
end
hello("World")
]]
    local out = IB.obfuscate(src, { rename = true, minify = true, controlFlow = false })
    ok(out:find("Hello,"), "string content preserved")
end

-- 6. Roblox names survive CF + rename
do
    local src = [[
local function run()
    local p = game.Players.LocalPlayer
    print(typeof(p))
end
run()
]]
    local out = IB.obfuscate(src, { preset = "roblox", controlFlow = true })
    ok(out ~= nil, "roblox preset ok")
    ok(out:find("game"), "game preserved")
    ok(out:find("typeof"), "typeof preserved")
end

print(string.format("\nResults: %d passed, %d failed", passed, failed))
if failed > 0 then os.exit(1) else print("Phase 5 OK") end
