-- Lightcore v1.4 macro preprocessor (source-level, before parse)
local MacroPass = {}

local function line_at(src, pos)
    local n = 1
    for i = 1, math.min(pos, #src) do
        if src:sub(i, i) == "\n" then n = n + 1 end
    end
    return n
end

-- Strip `if not LC_OBFUSCATED then ... else ... end` keeping else branch when present,
-- or dropping the whole then-branch when no else.
local function strip_not_obfuscated_blocks(src)
    -- iterative simple pattern: if not LC_OBFUSCATED then <then> else <else> end
    local out = src
    local changed = true
    local guard = 0
    while changed and guard < 50 do
        changed = false
        guard = guard + 1
        local s, e, thenb, elseb = out:find(
            "if%s+not%s+LC_OBFUSCATED%s+then(.-)else(.-)end"
        )
        if s then
            out = out:sub(1, s - 1) .. elseb .. out:sub(e + 1)
            changed = true
        else
            s, e, thenb = out:find("if%s+not%s+LC_OBFUSCATED%s+then(.-)end")
            if s then
                out = out:sub(1, s - 1) .. out:sub(e + 1)
                changed = true
            end
        end
        -- if LC_OBFUSCATED then X else Y end → X
        s, e, thenb, elseb = out:find("if%s+LC_OBFUSCATED%s+then(.-)else(.-)end")
        if s then
            out = out:sub(1, s - 1) .. thenb .. out:sub(e + 1)
            changed = true
        else
            s, e, thenb = out:find("if%s+LC_OBFUSCATED%s+then(.-)end")
            if s then
                out = out:sub(1, s - 1) .. thenb .. out:sub(e + 1)
                changed = true
            end
        end
    end
    return out
end

function MacroPass.apply(src, options)
    options = options or {}
    if type(src) ~= "string" then return src end

    -- Fold LC_OBFUSCATED branches BEFORE replacing the identifier
    src = strip_not_obfuscated_blocks(src)

    -- LC_LINE → line number (as number literal)
    do
        local pieces = {}
        local last = 1
        for s, e in src:gmatch("()LC_LINE()") do
            local after = src:sub(e, e)
            if after ~= "(" then
                pieces[#pieces + 1] = src:sub(last, s - 1)
                pieces[#pieces + 1] = tostring(line_at(src, s))
                last = e
            end
        end
        pieces[#pieces + 1] = src:sub(last)
        src = table.concat(pieces)
    end

    -- Remaining LC_OBFUSCATED → true
    src = src:gsub("([^%w_])LC_OBFUSCATED([^%w_(])", "%1true%2")
    src = src:gsub("^LC_OBFUSCATED([^%w_(])", "true%1")
    src = src:gsub("([^%w_])LC_OBFUSCATED$", "%1true")

    -- LC_ENCSTR("...") or LC_ENCSTR('...') → keep string (VM encrypts pool); strip call
    src = src:gsub('LC_ENCSTR%s*%(%s*([\'"])(.-)%1%s*%)', function(q, body)
        return q .. body .. q
    end)
    -- LC_ENCNUM(n) → n
    src = src:gsub("LC_ENCNUM%s*%(%s*([%d%.]+)%s*%)", "%1")
    -- LC_OPAQUE(x) → x
    src = src:gsub("LC_OPAQUE%s*%((.-)%)", function(inner)
        return "(" .. inner .. ")"
    end)
    -- LC_CRASH() → error with short message
    src = src:gsub("LC_CRASH%s*%(%s*%)", 'error("e",0)')

    -- LC_NO_VIRTUALIZE / LC_VIRTUALIZE markers → comments removed (options.noVirtualize from panel)
    src = src:gsub("LC_NO_VIRTUALIZE%s*%(%s*%)", "")
    src = src:gsub("LC_VIRTUALIZE%s*%(%s*%)", "")

    -- LC_JIT_MAX / LC_VM_MAX as no-op markers
    src = src:gsub("LC_JIT_MAX%s*%(%s*%)", "")
    src = src:gsub("LC_VM_MAX%s*%(%s*%)", "")

    return src
end

return MacroPass
