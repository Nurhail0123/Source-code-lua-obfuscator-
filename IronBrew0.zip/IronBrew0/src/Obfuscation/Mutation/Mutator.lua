-- Lightcore IR mutations: equivalent rewrites that change bytecode shape
local IR = require("src.IR.IR")

local Mutator = {}

local function rng(seed)
    local s = (tonumber(seed) or os.time()) % 2147483647
    if s <= 0 then s = 1 end
    return function(a, b)
        s = (s * 48271) % 2147483647
        if not a then return s end
        if not b then return (s % a) + 1 end
        return a + (s % (b - a + 1))
    end
end

local function addConst(proto, value)
    for i, k in ipairs(proto.constants) do
        if k.value == value and type(k.value) == type(value) then
            return i
        end
    end
    proto.constants[#proto.constants + 1] = IR.Constant(value)
    return #proto.constants
end

function Mutator.mutateCode(proto, rand, intensity)
    intensity = intensity or 1.0
    local code = proto.code or {}
    local out = {}
    local maxStack = proto.maxStack or 8

    local function emit(op, a, b, c, meta)
        out[#out + 1] = IR.Instruction(op, a, b, c, meta)
    end

    for _, ins in ipairs(code) do
        local op = ins.op
        local roll = (rand(1000) / 1000)

        if op == IR.Op.LOADK and roll < 0.35 * intensity then
            local ki = ins.b or (ins.meta and ins.meta.k)
            local kv = ki and proto.constants[ki] and proto.constants[ki].value
            if type(kv) == "number" and kv == math.floor(kv) and math.abs(kv) < 1e6 then
                local delta = rand(-7, 7)
                if delta ~= 0 then
                    local k2 = addConst(proto, kv - delta)
                    local kd = addConst(proto, delta)
                    local tmp = math.min(maxStack + 2, 250)
                    emit(IR.Op.LOADK, ins.a, k2, nil, { k = k2 })
                    emit(IR.Op.LOADK, tmp, kd, nil, { k = kd })
                    emit(IR.Op.ADD, ins.a, ins.a, tmp)
                    goto continue
                end
            end
        end

        if op == IR.Op.MOVE and roll < 0.25 * intensity then
            local tmp = math.min((proto.maxStack or 8) + 3, 250)
            emit(IR.Op.MOVE, tmp, ins.b)
            emit(IR.Op.MOVE, ins.a, tmp)
            goto continue
        end

        if op == IR.Op.ADD and roll < 0.2 * intensity then
            local z = addConst(proto, 0)
            local tmp = math.min((proto.maxStack or 8) + 4, 250)
            emit(IR.Op.LOADK, tmp, z, nil, { k = z })
            emit(IR.Op.ADD, ins.a, ins.b, ins.c)
            emit(IR.Op.ADD, ins.a, ins.a, tmp)
            goto continue
        end

        if op == IR.Op.LOADBOOL and ins.b == true and roll < 0.2 * intensity then
            emit(IR.Op.LOADNIL, ins.a)
            emit(IR.Op.NOT, ins.a, ins.a)
            emit(IR.Op.NOT, ins.a, ins.a)
            goto continue
        end

        if roll < 0.15 * intensity and op ~= IR.Op.RETURN and op ~= IR.Op.JMP then
            local r = ins.a or 0
            if type(r) == "number" and r >= 0 then
                emit(IR.Op.MOVE, r, r)
            end
        end

        emit(op, ins.a, ins.b, ins.c, ins.meta)
        ::continue::
    end

    proto.code = out
    if (proto.maxStack or 0) < (maxStack + 6) then
        proto.maxStack = maxStack + 6
    end
end

function Mutator.mutateProto(proto, rand, intensity)
    if not proto then return end
    Mutator.mutateCode(proto, rand, intensity)
    for _, child in ipairs(proto.prototypes or {}) do
        Mutator.mutateProto(child, rand, intensity)
    end
end

function Mutator.mutate(mod, options)
    options = options or {}
    local intensity = tonumber(options.intensity) or 1.0
    local rand = rng(options.seed)
    if mod.main then
        Mutator.mutateProto(mod.main, rand, intensity)
    end
    for _, p in ipairs(mod.prototypes or {}) do
        if p ~= mod.main then
            Mutator.mutateProto(p, rand, intensity)
        end
    end
    return mod
end

return Mutator
