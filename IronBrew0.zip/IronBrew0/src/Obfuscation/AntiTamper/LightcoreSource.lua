return [====[
coroutine.wrap(function()
	local detections = {}
	local FAKE_CODE = [==[
--[[
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠋⠉⣿⠉⠉⣿⠀⠐⡏⠉⠉⢻⡏⠉⠉⢿⢰⡏⠉⠉⢹⡀⡏⠉⢉⠉⠙⢷
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠀⠀⢺⠀⠀⣚⣀⣠⡇⠀⠀⠘⠁⠀⠀⣻⣼⠀⢰⡀⠈⣇⡇⠀⢸⡇⠀⢸⡇
⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⢿⠀⠀⣻⠀⠀⣿⢉⣽⡇⠀⢧⠀⠀⡇⠀⢼⡿⠀⢸⡇⠀⢿⡇⠀⢸⡇⠀⢸⣇⡀
⠀⠀⠀⠀⠀⠀⢠⣾⠏⠀⢸⡄⠀⢿⠀⠀⣿⣡⠴⡇⠀⣹⠀⢠⡇⠀⢺⡇⠀⢀⡅⠀⢸⡇⠀⠸⠇⠀⢸⡏
⠀⠀⠀⠀⠀⢠⣿⠃⠀⠀⢈⡷⢤⣀⣠⣼⠧⠖⠚⢧⡤⠼⢧⠼⢧⡤⠽⢤⡤⠼⠧⣤⣬⢧⡤⢤⠤⠤⢾⡁
Protected using lightcore
]]
local detected = 67
local dtc = "haha"
if detected then
	dtc
end
]==]
	local ok = pcall(function()
		local a = tonumber(os.date("%S"))
		task.wait(1.1)
		local b = tonumber(os.date("%S"))
		if not a or not b or a == b then
			detections[#detections + 1] = "clock-frozen"
		end
		local da = workspace.DistributedGameTime
		task.wait(0.5)
		local db = workspace.DistributedGameTime
		if type(da) ~= "number" or type(db) ~= "number" or db <= da then
			detections[#detections + 1] = "distributed-time-frozen"
		end
		local RunService = game:GetService("RunService")
		local hits = 0
		local connection = RunService.Heartbeat:Connect(function()
			hits = hits + 1
		end)
		task.wait(0.4)
		connection:Disconnect()
		if hits <= 0 then
			detections[#detections + 1] = "heartbeat-frozen"
		end
	end)
	if not ok then
		detections[#detections + 1] = "detector-runtime"
	end
	if #detections > 0 then
		pcall(function()
			if type(loadstring) == "function" then
				local fn = loadstring(FAKE_CODE)
				if type(fn) == "function" then
					fn()
				end
			end
		end)
		local reason = "tamper"
		if #detections > 0 then
			reason = detections[1]
			if detections[2] then
				reason = detections[1] .. "," .. detections[2]
			end
		end
		error("Lightcore integrity check failed: " .. tostring(reason), 0)
	end

]====]
