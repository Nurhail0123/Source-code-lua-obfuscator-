-- IronBrew0 v0.009 - Anti-tamper as IR (runs inside VM, not host plaintext)

local IR = require("src.IR.IR")

local ATIR = {}

-- Full AT body compiled through the same pipeline as user code.
-- Host-side probes removed from VM bootstrap; this is the only AT surface.
local AT_SOURCE = [=[
do
  if not ((3 + 4) == 7) then
    error("e", 0)
  end
  if not ((10 * 2) == 20) then
    error("e", 0)
  end
  if not ((9 - 3) == 6) then
    error("e", 0)
  end
  if not ((8 / 2) == 4) then
    error("e", 0)
  end
  if not ((5 % 2) == 1) then
    error("e", 0)
  end
  if type(1) ~= "number" then
    error("e", 0)
  end
  if type("x") ~= "string" then
    error("e", 0)
  end
  if type(type) ~= "function" then
    error("e", 0)
  end
  -- Part hierarchy (Roblox); skip if Instance missing
  if type(Instance) == "table" and type(Instance.new) == "function" then
    local ok, part = pcall(Instance.new, "Part")
    if ok and part then
      if part.ClassName ~= "Part" then
        error("e", 0)
      end
      if type(part.IsA) == "function" then
        if not part:IsA("BasePart") or not part:IsA("Instance") then
          error("e", 0)
        end
      end
      if type(part.CanQuery) == "boolean" then
        part.CanQuery = false
        if part.CanQuery ~= false then
          error("e", 0)
        end
        part.CanQuery = true
      end
      if type(part.Destroy) == "function" then
        part:Destroy()
      end
    end
    local ok2, frame = pcall(Instance.new, "Frame")
    if ok2 and frame then
      if frame.ClassName ~= "Frame" then
        error("e", 0)
      end
      if type(frame.IsA) == "function" and not frame:IsA("GuiObject") then
        error("e", 0)
      end
      if type(frame.Destroy) == "function" then
        frame:Destroy()
      end
    end
  end
end
]=]

function ATIR.compilePure(options)
    options = options or {}
    local ok, init = pcall(require, "src.init")
    if ok and init.parse and init.compileIR then
        local res = init.parse(AT_SOURCE, options)
        if res.errors and #res.errors > 0 then
            error("ATIR parse: " .. tostring(res.errors[1].message or res.errors[1]))
        end
        return init.compileIR(res.ast, options)
    end
    local Parser = require("src.Parser.Parser")
    local Compiler = require("src.IR.Compiler")
    local parser = Parser.new()
    local ast, errs = parser:parse(AT_SOURCE)
    if type(ast) == "table" and ast.kind == nil and ast.ast then
        ast = ast.ast
    end
    if errs and type(errs) == "table" and #errs > 0 and not errs.kind then
        error("ATIR parse failed")
    end
    return Compiler.new(options):compile(ast)
end

local function isReturn(ins)
    return ins and ins.op == IR.Op.RETURN
end

function ATIR.mergeInto(module, options)
    options = options or {}
    local main = module.main
    if not main then return module end

    local ok, atMod = pcall(ATIR.compilePure, options)
    if not ok or not atMod then
        return module
    end
    local atMain = atMod.main or (atMod.prototypes and atMod.prototypes[1])
    if not atMain or not atMain.code or #atMain.code == 0 then
        return module
    end

    -- Flatten AT nested protos into module.prototypes so CLOSURE indices resolve
    module.prototypes = module.prototypes or {}
    local protoBase = #module.prototypes
    local atProtos = atMod.prototypes or {}
    -- collect all AT protos except main (main is inlined into user main)
    local function collect(p, list, seen)
        if not p or seen[p] then return end
        seen[p] = true
        for _, sub in ipairs(p.prototypes or {}) do
            collect(sub, list, seen)
        end
        list[#list + 1] = p
    end
    local ordered = {}
    collect(atMain, ordered, {})
    -- ordered ends with atMain; nested come first if DFS postorder - use preorder for CLOSURE indices
    -- Compiler usually stores prototypes in module.prototypes with CLOSURE B as index
    -- Safer: append every proto from atMod.prototypes list if present
    if #atProtos > 0 then
        for _, p in ipairs(atProtos) do
            module.prototypes[#module.prototypes + 1] = p
        end
    else
        for _, p in ipairs(ordered) do
            if p ~= atMain then
                module.prototypes[#module.prototypes + 1] = p
            end
        end
    end

    main.constants = main.constants or {}
    local base = #main.constants
    for _, k in ipairs(atMain.constants or {}) do
        main.constants[#main.constants + 1] = k
    end

    local function remapIns(ins)
        local op = ins.op
        if op == IR.Op.LOADK or op == IR.Op.GETGLOBAL or op == IR.Op.SETGLOBAL then
            if type(ins.b) == "number" and ins.b > 0 then
                ins.b = ins.b + base
            end
        end
        if op == IR.Op.CLOSURE and type(ins.b) == "number" then
            ins.b = ins.b + protoBase
        end
        return ins
    end

    local atCode = {}
    for _, ins in ipairs(atMain.code) do
        if not isReturn(ins) then
            atCode[#atCode + 1] = remapIns({
                op = ins.op, a = ins.a, b = ins.b, c = ins.c, meta = ins.meta
            })
        end
    end

    local body = main.code or {}
    local merged = {}
    for i = 1, #atCode do merged[i] = atCode[i] end
    for i = 1, #body do merged[#merged + 1] = body[i] end
    main.code = merged

    if atMain.maxStack and main.maxStack then
        main.maxStack = math.max(main.maxStack or 0, atMain.maxStack or 0)
    end
    return module
end

return ATIR
