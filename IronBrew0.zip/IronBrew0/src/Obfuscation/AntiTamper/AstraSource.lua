-- compat: prefer LightcoreSource
return require("src.Obfuscation.AntiTamper.LightcoreSource")
