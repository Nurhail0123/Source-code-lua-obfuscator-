-- IronBrew0 v1.7 Lightcore - AT + Part/Frame + Luraph-style env probes
-- Roblox-only: Path2D, MemStorage, CollectionService, MembershipType, spy/gc probes, etc.
-- Shared: integrity (Luau-safe XOR), debug wipe, anti-beautify, tripwire.

local AntiTamper = {}
AntiTamper.__index = AntiTamper

local DETECT_MSG = "Lightcore: environment integrity check failed"

local function hostXor(a, b)
    a, b = math.floor(a) % 256, math.floor(b) % 256
    local r, p = 0, 1
    for _ = 1, 8 do
        local abit, bbit = a % 2, b % 2
        if abit ~= bbit then r = r + p end
        a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
    end
    return r
end

function AntiTamper.new(options)
    options = options or {}
    local target = options.target or "executor"
    local isRoblox = (target == "roblox" or target == "luau" or target == "executor")
    return setmetatable({
        target = target,
        checkGetfenv = options.checkGetfenv ~= false,
        checkDebug = options.checkDebug ~= false,
        checkBeautify = options.checkBeautify ~= false,
        integrity = options.integrity ~= false,
        scrambleOps = options.scrambleOps ~= false,
        poisonOnFail = options.poisonOnFail ~= false,
        -- Roblox-only suite
        checkStringMt = isRoblox and (options.checkStringMt ~= false),
        checkPath2D = isRoblox and (options.checkPath2D ~= false),
        checkRobloxDeep = isRoblox and (options.checkRobloxDeep ~= false),
        checkAdvanced = isRoblox and (options.checkAdvanced ~= false),
        checkPartHierarchy = isRoblox and (options.checkPartHierarchy ~= false),
        checkFrameHierarchy = isRoblox and (options.checkFrameHierarchy ~= false),
        checkWynFuscate = isRoblox and (options.checkWynFuscate ~= false),
        checkAstra = isRoblox and (options.checkAstra ~= false),
        detectMessage = options.detectMessage or DETECT_MSG,
    }, AntiTamper)
end

function AntiTamper.checksum(nums)
    local h = 2166136261
    for i = 1, #nums do
        local b = (nums[i] or 0) % 256
        -- FNV-ish without bitwise: mix via arithmetic
        h = (h + b * 16777619 + i * 31) % 4294967296
    end
    return h
end

function AntiTamper.scrambleOpcodeMap(seed, nops)
    nops = nops or 40 -- v0.007b: include superops range
    math.randomseed(seed or os.time())
    local ops = {}
    for i = 1, nops do ops[i] = i end
    for i = nops, 2, -1 do
        local j = math.random(1, i)
        ops[i], ops[j] = ops[j], ops[i]
    end
    local map, inv = {}, {}
    for logical = 1, nops do
        map[logical] = ops[logical]
        inv[ops[logical]] = logical
    end
    return map, inv
end

function AntiTamper.applyScramble(code, map)
    local out = {}
    for i = 1, #code, 4 do
        out[i] = map[code[i]] or code[i]
        out[i + 1] = code[i + 1] or 0
        out[i + 2] = code[i + 2] or 0
        out[i + 3] = code[i + 3] or 0
    end
    return out
end

function AntiTamper.emitTrip(msg)
    msg = tostring(msg or DETECT_MSG)
    return string.format("error(%q,0) while true do return end", msg)
end


--- Emit GetService/ClassName probes from harvested service list.
-- core services must match ClassName; sample of ALL is soft-checked (pcall).

--- Advanced AT probes (lifted/adapted from host fingerprint + metamethod suite).
-- Soft on missing Roblox APIs; hard-trip only on clear contract breaks.
function AntiTamper:emitAdvancedProbes(N, opts)
    opts = opts or {}
    local fail = N.fail
    local tmp = N.tmp or "_t"
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    local trip = self.detectMessage or DETECT_MSG

    -- 1) Locked metatable contract
    L(("pcall(function() local %s={} local %s={__metatable='IB0L',__index=function() error('x') end} setmetatable(%s,%s) if getmetatable(%s)~='IB0L' then %s=true end if pcall(setmetatable,%s,{}) then %s=true end end)"):format(
        tmp, tmp.."m", tmp, tmp.."m", tmp, fail, tmp, fail))

    -- 2) pcall return identity (sentinel table)
    L(("pcall(function() local %s={} local %s={function() return %s end} local %s,%s=pcall(%s[1]) if not %s or %s~=%s then %s=true end end)"):format(
        tmp.."s", tmp.."b", tmp.."s", tmp.."ok", tmp.."v", tmp.."b", tmp.."ok", tmp.."v", tmp.."s", fail))

    -- 3) __index fires exactly once for missing key
    L(("pcall(function() local %s={0} local %s=setmetatable({},{__index=function() %s[1]=%s[1]+1 return nil end}) local _=%s.missing if %s[1]~=1 then %s=true end local %s,%s=pcall(function() return %s[{}] end) if not %s or %s~=nil then %s=true end end)"):format(
        tmp.."c", tmp.."o", tmp.."c", tmp.."c", tmp.."o", tmp.."c", fail, tmp.."ok", tmp.."v", tmp.."o", tmp.."ok", tmp.."v", fail))

    -- 4) type(function)=='function'
    L(("pcall(function() local %s=function() return 1 end if type(%s)~='function' then %s=true end end)"):format(
        tmp.."f", tmp.."f", fail))

    -- 5) coroutine yield/resume/dead contract
    L(("pcall(function() if not coroutine then return end local %s=coroutine.create(function() coroutine.yield(1) return 2 end) local %s,%s=coroutine.resume(%s) if not %s or %s~=1 then %s=true return end %s,%s=coroutine.resume(%s) if not %s or %s~=2 then %s=true return end if coroutine.status(%s)~='dead' then %s=true end end)"):format(
        tmp.."th", tmp.."ok", tmp.."v", tmp.."th", tmp.."ok", tmp.."v", fail, tmp.."ok", tmp.."v", tmp.."th", tmp.."ok", tmp.."v", fail, tmp.."th", fail))

    -- 6) rawset/rawget space key
    L(("pcall(function() local %s={} rawset(%s,' ',' ') if rawget(%s,' ')~=' ' then %s=true end end)"):format(
        tmp, tmp, tmp, fail))

    -- 7) Roblox host shape (skip if no game)
    L(("pcall(function() local %s=game if %s==nil then return end if type(%s)=='table' then %s=true return end if type(%s.ClassName)=='string' and %s.ClassName~='DataModel' then %s=true end if type(%s.GetService)~='function' then %s=true return end local %s,%s=pcall(%s.GetService,%s,'Players') if not %s or %s==nil then %s=true return end if type(%s.ClassName)=='string' and %s.ClassName~='Players' then %s=true end end)"):format(
        tmp, tmp, tmp, fail, tmp, tmp, fail, tmp, fail, tmp.."ok", tmp.."p", tmp, tmp, tmp.."ok", tmp.."p", fail, tmp.."p", tmp.."p", fail))

    -- 8) Instance.new Folder measure
    L(("pcall(function() if Instance==nil or type(Instance.new)~='function' then return end local %s,%s=pcall(Instance.new,'Folder') if not %s or %s==nil then %s=true return end if type(%s.ClassName)=='string' and %s.ClassName~='Folder' then %s=true end if type(%s.Destroy)=='function' then pcall(%s.Destroy,%s) end end)"):format(
        tmp.."ok", tmp.."f", tmp.."ok", tmp.."f", fail, tmp.."f", tmp.."f", fail, tmp.."f", tmp.."f", tmp.."f"))

    -- 9) Vector3int16 soft measure (presence only if API exists)
    L(("pcall(function() if Vector3int16==nil or type(Vector3int16.new)~='function' then return end local %s,%s=pcall(Vector3int16.new,1,2,3) if not %s or %s==nil then %s=true return end local %s=tonumber(%s.X) or 0 local %s=tonumber(%s.Y) or 0 local %s=tonumber(%s.Z) or 0 if %s~=1 or %s~=2 or %s~=3 then %s=true end end)"):format(
        tmp.."ok", tmp.."v", tmp.."ok", tmp.."v", fail, tmp.."x", tmp.."v", tmp.."y", tmp.."v", tmp.."z", tmp.."v", tmp.."x", tmp.."y", tmp.."z", fail))

    -- 10) Native/debug source checks when debug.info available (soft: only if debug present)
    L(("pcall(function() if type(debug)~='table' or type(debug.info)~='function' then return end local function %s(%s) local %s,%s=pcall(debug.info,%s,'s') if not %s then return end if %s~='[C]' then %s=true end end %s(pcall) %s(type) %s(rawget) %s(select) end)"):format(
        tmp.."nc", tmp.."fn", tmp.."ok", tmp.."src", tmp.."fn", tmp.."ok", tmp.."src", fail, tmp.."nc", tmp.."nc", tmp.."nc", tmp.."nc"))

    -- 11) string.dump: Lua closures dumpable, native pcall not dumpable (when dump exists)
    L(("pcall(function() if type(string)~='table' or type(string.dump)~='function' then return end local %s=pcall(string.dump,function() return 1 end) if not %s then %s=true end local %s=pcall(string.dump,pcall) if %s then %s=true end end)"):format(
        tmp.."ok", tmp.."ok", fail, tmp.."ok2", tmp.."ok2", fail))

    return table.concat(parts, " ")
end


--- Env-logger detection probes (derived from common logger FAIL cases).
-- Real Roblox passes; incomplete/stub environments trip fail.
-- All wrapped in pcall; missing APIs are skipped (not failed).
function AntiTamper:emitEnvLoggerProbes(N, opts)
    opts = opts or {}
    local fail = N.fail
    local tmp = N.tmp or "_t"
    local parts = {}
    local function L(s) parts[#parts + 1] = s end

    -- task.wait minimum duration (~>0)
    L(("pcall(function() if type(task)~='table' or type(task.wait)~='function' then return end local %s=os and os.clock and os.clock() or tick() task.wait(0.03) local %s=os and os.clock and os.clock() or tick() if (%s-%s)<0.02 then %s=true end end)"):format(
        tmp.."t0", tmp.."t1", tmp.."t1", tmp.."t0", fail))

    -- getgenv contains _G (executor contract)
    L(("pcall(function() if type(getgenv)~='function' then return end local %s=getgenv() if type(%s)~='table' then %s=true return end if %s._G==nil and _G~=nil then %s=true end end)"):format(
        tmp, tmp, fail, tmp, fail))

    -- stdlib frozen-ish: writing to string.char should error or not stick on real Luau
    L(("pcall(function() local %s=string.char local %s=pcall(function() string.char=function() end end) if %s then if string.char~=%s then string.char=%s else %s=true end end end)"):format(
        tmp.."sc", tmp.."ok", tmp.."ok", tmp.."sc", tmp.."sc", fail))

    -- CollectionService AddTag/HasTag
    L(("pcall(function() if game==nil then return end local %s=game:GetService('CollectionService') local %s=Instance.new('Folder') local %s='IB0_'..tostring(math.random(1,99999)) %s:AddTag(%s,%s) if not %s:HasTag(%s,%s) then %s=true end %s:RemoveTag(%s,%s) if %s:HasTag(%s,%s) then %s=true end if type(%s.Destroy)=='function' then %s:Destroy() end end)"):format(
        tmp, tmp.."p", tmp.."tg", tmp, tmp.."p", tmp.."tg", tmp, tmp.."p", tmp.."tg", fail, tmp, tmp.."p", tmp.."tg", tmp, tmp.."p", tmp.."tg", fail, tmp.."p", tmp.."p"))

    -- Instance GetPropertyChangedSignal on Name
    L(("pcall(function() if Instance==nil then return end local %s=Instance.new('Folder') local %s=0 local %s=%s:GetPropertyChangedSignal('Name') if typeof and typeof(%s)~='RBXScriptSignal' and type(%s)~='userdata' then %s=true end local %s=%s:Connect(function() %s=%s+1 end) %s.Name='IB0X' task.wait(0) if %s<1 then %s=true end if %s.Disconnect then %s:Disconnect() end if %s.Destroy then %s:Destroy() end end)"):format(
        tmp.."p", tmp.."n", tmp.."s", tmp.."p", tmp.."s", tmp.."s", fail, tmp.."c", tmp.."s", tmp.."n", tmp.."n", tmp.."p", tmp.."n", fail, tmp.."c", tmp.."c", tmp.."p", tmp.."p"))

    -- ChildAdded fires
    L(("pcall(function() if Instance==nil then return end local %s=Instance.new('Folder') local %s=0 local %s=%s.ChildAdded:Connect(function() %s=%s+1 end) local %s=Instance.new('Folder') %s.Parent=%s task.wait(0) if %s<1 then %s=true end if %s.Disconnect then %s:Disconnect() end if %s.Destroy then %s:Destroy() %s:Destroy() end end)"):format(
        tmp.."p", tmp.."n", tmp.."c", tmp.."p", tmp.."n", tmp.."n", tmp.."c2", tmp.."c2", tmp.."p", tmp.."n", fail, tmp.."c", tmp.."c", tmp.."p", tmp.."p", tmp.."c2"))

    -- Frame.Active is boolean
    L(("pcall(function() if Instance==nil then return end local %s=Instance.new('Frame') if type(%s.Active)~='boolean' then %s=true end if %s.Destroy then %s:Destroy() end end)"):format(
        tmp, tmp, fail, tmp, tmp))

    -- Part:GetMass positive
    L(("pcall(function() if Instance==nil then return end local %s=Instance.new('Part') if type(%s.GetMass)~='function' then %s=true return end local %s=%s:GetMass() if type(%s)~='number' or %s<=0 then %s=true end if %s.Destroy then %s:Destroy() end end)"):format(
        tmp, tmp, fail, tmp.."m", tmp, tmp.."m", tmp.."m", fail, tmp, tmp))

    -- Color3 clamp/reject out of range (real Roblox clamps)
    L(("pcall(function() if Color3==nil or type(Color3.new)~='function' then return end local %s=Color3.new(2, -1, 0.5) if typeof and typeof(%s)~='Color3' then %s=true return end local %s=%s.R if type(%s)~='number' or %s>1.01 or %s<-0.01 then %s=true end end)"):format(
        tmp, tmp, fail, tmp.."r", tmp, tmp.."r", tmp.."r", tmp.."r", fail))

    -- Random seeded deterministic
    L(("pcall(function() if Random==nil or type(Random.new)~='function' then return end local %s=Random.new(42) local %s=Random.new(42) local %s=%s:NextNumber() local %s=%s:NextNumber() if %s~=%s then %s=true end end)"):format(
        tmp.."a", tmp.."b", tmp.."x", tmp.."a", tmp.."y", tmp.."b", tmp.."x", tmp.."y", fail))

    -- Vector3int16 non-integer rounds
    L(("pcall(function() if Vector3int16==nil or type(Vector3int16.new)~='function' then return end local %s=Vector3int16.new(1.9,2.1,-3.7) if %s.X~=1 or %s.Y~=2 then %s=true end end)"):format(
        tmp, tmp, tmp, fail))

    -- Vector2int16 non-integer rounds
    L(("pcall(function() if Vector2int16==nil or type(Vector2int16.new)~='function' then return end local %s=Vector2int16.new(1.9,2.1) if %s.X~=1 or %s.Y~=2 then %s=true end end)"):format(
        tmp, tmp, tmp, fail))

    -- TweenInfo.Time
    L(("pcall(function() if TweenInfo==nil or type(TweenInfo.new)~='function' then return end local %s=TweenInfo.new(0.5) if type(%s.Time)~='number' or math.abs(%s.Time-0.5)>1e-6 then %s=true end end)"):format(
        tmp, tmp, tmp, fail))

    -- NumberRange min<=max errors
    L(("pcall(function() if NumberRange==nil or type(NumberRange.new)~='function' then return end local %s=pcall(NumberRange.new,5,1) if %s then %s=true end end)"):format(
        tmp.."ok", tmp.."ok", fail))

    -- UDim2 tostring format-ish
    L(("pcall(function() if UDim2==nil or type(UDim2.new)~='function' then return end local %s=UDim2.new(0.5,10,0.25,0) local %s=tostring(%s) if type(%s)~='string' or #(%s)<3 then %s=true end end)"):format(
        tmp, tmp.."s", tmp, tmp.."s", tmp.."s", fail))

    -- BrickColor.palette if present
    L(("pcall(function() if BrickColor==nil or type(BrickColor.palette)~='function' then return end local %s=BrickColor.palette(1) if %s==nil then %s=true end if typeof and typeof(%s)~='BrickColor' and type(%s)~='userdata' then %s=true end end)"):format(
        tmp, tmp, fail, tmp, tmp, fail))

    -- CFrame.fromRotationBetweenVectors if present
    L(("pcall(function() if CFrame==nil then return end if type(CFrame.fromRotationBetweenVectors)~='function' then return end local %s=CFrame.fromRotationBetweenVectors(Vector3.new(1,0,0),Vector3.new(0,1,0)) if %s==nil then %s=true end if typeof and typeof(%s)~='CFrame' and type(%s)~='userdata' then %s=true end end)"):format(
        tmp, tmp, fail, tmp, tmp, fail))

    -- UserInputService.InputBegan is signal
    L(("pcall(function() if game==nil then return end local %s=game:GetService('UserInputService') local %s=%s.InputBegan if %s==nil then %s=true return end if typeof and typeof(%s)~='RBXScriptSignal' and type(%s)~='userdata' then %s=true end end)"):format(
        tmp, tmp.."s", tmp, tmp.."s", fail, tmp.."s", tmp.."s", fail))

    -- TweenService:Create returns Tween
    L(("pcall(function() if game==nil or Instance==nil then return end local %s=game:GetService('TweenService') local %s=Instance.new('Part') local %s=%s:Create(%s,TweenInfo.new(0.1),{Transparency=1}) if %s==nil then %s=true end if typeof and typeof(%s)~='Instance' and type(%s)~='userdata' then %s=true end if %s.Destroy then %s:Destroy() end if %s.Destroy then %s:Destroy() end end)"):format(
        tmp, tmp.."p", tmp.."t", tmp, tmp.."p", tmp.."t", fail, tmp.."t", tmp.."t", fail, tmp.."t", tmp.."t", tmp.."p", tmp.."p"))

    -- Enum has AccessModifierType with items OR any Enum with >=2 items
    L(("pcall(function() if Enum==nil then return end local %s=0 for %s,%s in pairs(Enum) do if type(%s)=='userdata' or type(%s)=='table' then %s=%s+1 end end if %s<5 then %s=true end end)"):format(
        tmp.."n", tmp.."k", tmp.."v", tmp.."v", tmp.."v", tmp.."n", tmp.."n", tmp.."n", fail))

    -- RunService Heartbeat is signal and fires (with timeout via fast poll)
    L(("pcall(function() if game==nil then return end local %s=game:GetService('RunService') local %s=%s.Heartbeat if %s==nil then %s=true return end local %s=0 local %s=%s:Connect(function(%s) if type(%s)=='number' and %s>0 and %s<1 then %s=%s+1 end end) local %s=0 while %s<1 and %s<30 do if task and task.wait then task.wait() else break end %s=%s+1 end if %s.Disconnect then %s:Disconnect() end if %s<1 then %s=true end end)"):format(
        tmp, tmp.."h", tmp, tmp.."h", fail, tmp.."n", tmp.."c", tmp.."h", tmp.."dt", tmp.."dt", tmp.."dt", tmp.."dt", tmp.."n", tmp.."n", tmp.."i", tmp.."n", tmp.."i", tmp.."i", tmp.."i", tmp.."c", tmp.."c", tmp.."n", fail))

    -- Stats.HeartbeatTime number if Stats exists
    L(("pcall(function() if game==nil then return end local %s=game:FindService('Stats') or game:GetService('Stats') if %s==nil then return end if type(%s.HeartbeatTime)~='number' and type(%s.HeartbeatTimeMs)~='number' then %s=true end end)"):format(
        tmp, tmp, tmp, tmp, fail))

    -- PhysicalProperties.Density if available
    L(("pcall(function() if PhysicalProperties==nil or type(PhysicalProperties.new)~='function' then return end local %s=PhysicalProperties.new(0.7,0.3,0.5) if type(%s.Density)~='number' then %s=true end end)"):format(
        tmp, tmp, fail))

    -- Rect.new from numbers
    L(("pcall(function() if Rect==nil or type(Rect.new)~='function' then return end local %s=Rect.new(0,0,10,20) if type(%s.Width)~='number' and type(%s.Width)=='nil' then if %s.Max==nil and %s.Min==nil then %s=true end end end)"):format(
        tmp, tmp, tmp, tmp, tmp, fail))

    -- workspace type not plain table
    L(("pcall(function() if workspace==nil then return end if type(workspace)=='table' then %s=true end end)"):format(fail))

    -- game and workspace typeof Instance when typeof exists
    L(("pcall(function() if typeof==nil then return end if game~=nil and typeof(game)~='Instance' then %s=true end if workspace~=nil and typeof(workspace)~='Instance' then %s=true end end)"):format(fail, fail))

    return table.concat(parts, " ")
end

function AntiTamper:emitServiceProbes(N, opts)
    opts = opts or {}
    local okReq, Services = pcall(require, "src.Obfuscation.AntiTamper.Services")
    if not okReq or type(Services) ~= "table" then
        return ""
    end
    local core = Services.core or {}
    local all = Services.all or {}
    local sampleN = opts.sample or 12
    local fail = N.fail
    local tmp = N.tmp or "_t"

    local seen, probes = {}, {}
    for _, name in ipairs(core) do
        if type(name) == "string" and not seen[name] then
            seen[name] = true
            probes[#probes + 1] = name
        end
    end
    local pool = {}
    for _, name in ipairs(all) do
        if type(name) == "string" and not seen[name] then
            pool[#pool + 1] = name
        end
    end
    for i = #pool, 2, -1 do
        local j = math.random(1, i)
        pool[i], pool[j] = pool[j], pool[i]
    end
    for i = 1, math.min(sampleN, #pool) do
        probes[#probes + 1] = pool[i]
    end

    local lit = {}
    for i, name in ipairs(probes) do
        lit[i] = string.format("%q", name)
    end
    local coreN = #core

    -- Skip entirely when game is missing (desktop). Core must match ClassName.
    -- Extra sampled services: only fail if GetService succeeds but ClassName mismatches.
    return string.format(
        "pcall(function() local g=game if g==nil then return end if type(g)~='userdata' and type(g)~='table' then return end if g.ClassName~='DataModel' then %s=true return end local L={%s} local C=%d for i=1,#L do local n=L[i] local ok,svc=pcall(function() return g:GetService(n) end) if i<=C then if not ok or not svc or svc.ClassName~=n then %s=true return end else if ok and svc and type(svc)=='userdata' and svc.ClassName~=n then %s=true return end end end end)",
        fail, table.concat(lit, ","), coreN, fail, fail
    )
end


--- Part / BasePart / Instance hierarchy probes (from Roblox API harvest).
--- Targets incomplete env-logger Part stubs.
function AntiTamper:emitPartHierarchyProbes(N, opts)
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    local f, T = N.fail, N.tmp
    local Tp, Tm, Tcf, Ts, Tg = T .. "p", T .. "m", T .. "cf", T .. "s", T .. "g"

    -- ClassName + IsA hierarchy
    L(("pcall(function() local %s=Instance.new('Part') if typeof(%s)~='Instance' or %s.ClassName~='Part' then %s=true end if not (%s:IsA('Part') and %s:IsA('BasePart') and %s:IsA('PVInstance') and %s:IsA('Instance')) then %s=true end if %s:IsA('Model') then %s=true end end)"):format(
        T, T, T, f, T, T, T, T, f, T, f))

    -- Collision / query / touch / shadow / massless / fluid
    L(("pcall(function() local %s=Instance.new('Part') if type(%s.CanCollide)~='boolean' or type(%s.CanQuery)~='boolean' or type(%s.CanTouch)~='boolean' then %s=true end if type(%s.CastShadow)~='boolean' or type(%s.Massless)~='boolean' or type(%s.Anchored)~='boolean' then %s=true end if type(%s.EnableFluidForces)~='boolean' then %s=true end %s.CanQuery=false if %s.CanQuery~=false then %s=true end %s.CanQuery=true %s:Destroy() end)"):format(
        T, T, T, T, f, T, T, T, f, T, f, T, T, f, T, T))

    -- Size Vector3 + CFrame + GetPivot
    L(("pcall(function() local %s=Instance.new('Part') %s.Size=Vector3.new(2,4,6) if typeof(%s.Size)~='Vector3' or %s.Size.X~=2 or %s.Size.Y~=4 or %s.Size.Z~=6 then %s=true end %s.CFrame=CFrame.new(1,2,3) if typeof(%s.CFrame)~='CFrame' then %s=true end if type(%s.GetPivot)~='function' then %s=true end local %s=%s:GetPivot() if typeof(%s)~='CFrame' then %s=true end %s:Destroy() end)"):format(
        T, T, T, T, T, T, f, T, T, f, T, f, Tp, T, Tp, f, T))

    -- GetMass / Mass (number, non-NaN)
    L(("pcall(function() local %s=Instance.new('Part') %s.Size=Vector3.new(1,1,1) if type(%s.GetMass)~='function' then %s=true end local %s=%s:GetMass() if type(%s)~='number' or %s~=%s or %s<=0 then %s=true end if type(%s.Mass)~='number' then %s=true end %s:Destroy() end)"):format(
        T, T, T, f, Tm, T, Tm, Tm, Tm, Tm, f, T, f, T))

    -- GetClosestPointOnSurface
    L(("pcall(function() local %s=Instance.new('Part') %s.Size=Vector3.new(4,4,4) %s.CFrame=CFrame.new() if type(%s.GetClosestPointOnSurface)~='function' then %s=true end local %s=%s:GetClosestPointOnSurface(Vector3.new(100,0,0)) if typeof(%s)~='Vector3' then %s=true end %s:Destroy() end)"):format(
        T, T, T, T, f, Tp, T, Tp, f, T))

    -- Attributes + GetAttributeChangedSignal identity
    L(("pcall(function() local %s=Instance.new('Part') local %s=%s:GetAttributeChangedSignal('IB0') local %s=%s:GetAttributeChangedSignal('IB0') if %s~=%s then %s=true end %s:SetAttribute('IB0',42) if %s:GetAttribute('IB0')~=42 then %s=true end %s:SetAttribute('IB0',nil) if %s:GetAttribute('IB0')~=nil then %s=true end %s:Destroy() end)"):format(
        T, Ts, T, Tg, T, Ts, Tg, f, T, T, f, T, T, f, T))

    -- Color / BrickColor typeof
    L(("pcall(function() local %s=Instance.new('Part') if typeof(%s.Color)~='Color3' then %s=true end if typeof(%s.BrickColor)~='BrickColor' then %s=true end %s.Transparency=0.5 if type(%s.Transparency)~='number' or math.abs(%s.Transparency-0.5)>1e-5 then %s=true end %s:Destroy() end)"):format(
        T, T, f, T, f, T, T, T, f, T))

    -- GetFullName / Parent / Archivable
    L(("pcall(function() local %s=Instance.new('Part') %s.Name='IB0Part' %s.Archivable=true if type(%s.Archivable)~='boolean' or %s.Archivable~=true then %s=true end if workspace then %s.Parent=workspace local %s=%s:GetFullName() if type(%s)~='string' or not %s:find('IB0Part',1,true) then %s=true end end %s:Destroy() end)"):format(
        T, T, T, T, T, f, T, Tp, T, Tp, Tp, f, T))

    -- Material EnumItem
    L(("pcall(function() local %s=Instance.new('Part') if typeof(%s.Material)~='EnumItem' then %s=true end if %s.Material.EnumType~=Enum.Material then %s=true end %s:Destroy() end)"):format(
        T, T, f, T, f, T))

    -- Touched is RBXScriptSignal
    L(("pcall(function() local %s=Instance.new('Part') if typeof(%s.Touched)~='RBXScriptSignal' then %s=true end if typeof(%s.Changed)~='RBXScriptSignal' then %s=true end %s:Destroy() end)"):format(
        T, T, f, T, f, T))

    return table.concat(parts, " ")
end


--- Frame / GuiObject / GuiBase2d hierarchy probes (API harvest).
function AntiTamper:emitFrameHierarchyProbes(N, opts)
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    local f, T = N.fail, N.tmp
    local Tp, Ts, Ta, Tz = T .. "p", T .. "s", T .. "a", T .. "z"

    -- ClassName + IsA: Frame -> GuiObject -> GuiBase2d -> GuiBase -> Instance
    L(("pcall(function() local %s=Instance.new('Frame') if typeof(%s)~='Instance' or %s.ClassName~='Frame' then %s=true end if not (%s:IsA('Frame') and %s:IsA('GuiObject') and %s:IsA('GuiBase2d') and %s:IsA('GuiBase') and %s:IsA('Instance')) then %s=true end if %s:IsA('Part') or %s:IsA('ScreenGui') then %s=true end end)"):format(
        T, T, T, f, T, T, T, T, T, f, T, T, f))

    -- GuiObject core props often missing on stubs
    L(("pcall(function() local %s=Instance.new('Frame') if type(%s.Visible)~='boolean' or type(%s.Active)~='boolean' or type(%s.Selectable)~='boolean' then %s=true end if type(%s.ClipsDescendants)~='boolean' or type(%s.Interactable)~='boolean' then %s=true end if type(%s.ZIndex)~='number' or type(%s.LayoutOrder)~='number' or type(%s.Rotation)~='number' then %s=true end %s.Visible=false if %s.Visible~=false then %s=true end %s.Visible=true %s:Destroy() end)"):format(
        T, T, T, T, f, T, T, f, T, T, T, f, T, T, f, T, T))

    -- UDim2 Size / Position readback
    L(("pcall(function() local %s=Instance.new('Frame') %s.Size=UDim2.new(0,100,0,50) if typeof(%s.Size)~='UDim2' then %s=true end if %s.Size.X.Offset~=100 or %s.Size.Y.Offset~=50 then %s=true end %s.Position=UDim2.new(0.5,0,0.5,0) if typeof(%s.Position)~='UDim2' then %s=true end if math.abs(%s.Position.X.Scale-0.5)>1e-5 then %s=true end %s:Destroy() end)"):format(
        T, T, T, f, T, T, f, T, T, f, T, f, T))

    -- AnchorPoint Vector2
    L(("pcall(function() local %s=Instance.new('Frame') %s.AnchorPoint=Vector2.new(0.5,0.5) if typeof(%s.AnchorPoint)~='Vector2' then %s=true end if math.abs(%s.AnchorPoint.X-0.5)>1e-5 or math.abs(%s.AnchorPoint.Y-0.5)>1e-5 then %s=true end %s:Destroy() end)"):format(
        T, T, T, f, T, T, f, T))

    -- BackgroundColor3 / BackgroundTransparency / BorderSizePixel
    L(("pcall(function() local %s=Instance.new('Frame') if typeof(%s.BackgroundColor3)~='Color3' then %s=true end %s.BackgroundTransparency=0.25 if type(%s.BackgroundTransparency)~='number' or math.abs(%s.BackgroundTransparency-0.25)>1e-5 then %s=true end %s.BorderSizePixel=2 if type(%s.BorderSizePixel)~='number' or %s.BorderSizePixel~=2 then %s=true end %s:Destroy() end)"):format(
        T, T, f, T, T, T, f, T, T, T, f, T))

    -- AbsoluteSize / AbsolutePosition readonly Vector2 (GuiBase2d)
    L(("pcall(function() local %s=Instance.new('Frame') if typeof(%s.AbsoluteSize)~='Vector2' then %s=true end if typeof(%s.AbsolutePosition)~='Vector2' then %s=true end if type(%s.AbsoluteRotation)~='number' then %s=true end %s:Destroy() end)"):format(
        T, T, f, T, f, T, f, T))

    -- Input events as RBXScriptSignal
    L(("pcall(function() local %s=Instance.new('Frame') if typeof(%s.InputBegan)~='RBXScriptSignal' then %s=true end if typeof(%s.InputEnded)~='RBXScriptSignal' then %s=true end if typeof(%s.MouseEnter)~='RBXScriptSignal' then %s=true end if typeof(%s.Changed)~='RBXScriptSignal' then %s=true end %s:Destroy() end)"):format(
        T, T, f, T, f, T, f, T, f, T))

    -- AutomaticSize / SizeConstraint EnumItem
    L(("pcall(function() local %s=Instance.new('Frame') if typeof(%s.AutomaticSize)~='EnumItem' then %s=true end if typeof(%s.SizeConstraint)~='EnumItem' then %s=true end %s:Destroy() end)"):format(
        T, T, f, T, f, T))

    -- Style (Frame-specific)
    L(("pcall(function() local %s=Instance.new('Frame') if typeof(%s.Style)~='EnumItem' then %s=true end %s:Destroy() end)"):format(
        T, T, f, T))

    -- GetPropertyChangedSignal('Visible') identity
    L(("pcall(function() local %s=Instance.new('Frame') local %s=%s:GetPropertyChangedSignal('Visible') local %s=%s:GetPropertyChangedSignal('Visible') if %s~=%s then %s=true end %s:Destroy() end)"):format(
        T, Ts, T, Tp, T, Ts, Tp, f, T))

    -- Parent under ScreenGui if possible
    L(("pcall(function() local %s=Instance.new('ScreenGui') local %s=Instance.new('Frame') %s.Name='IB0Frame' %s.Parent=%s if %s.Parent~=%s then %s=true end local %s=%s:FindFirstChild('IB0Frame') if %s~=%s then %s=true end %s:Destroy() %s:Destroy() end)"):format(
        Ts, T, T, T, Ts, T, Ts, f, Tp, Ts, Tp, T, f, T, Ts))

    return table.concat(parts, " ")
end


--- High-value env probes inspired by Luraph v15 / WynFuscate anti-env suites.
function AntiTamper:emitLuraphStyleEnvProbes(N, opts)
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    local f, T = N.fail, N.tmp

    -- Core globals + Workspace identity
    L(("pcall(function() if type(game)~='userdata' or type(workspace)~='userdata' then %s=true end if not rawequal(game:GetService('Workspace'),workspace) then %s=true end if type(Instance)~='table' or type(Instance.new)~='function' then %s=true end if type(task)~='table' or type(buffer)~='table' then %s=true end end)"):format(f, f, f, f))

    -- buffer surface
    L(("pcall(function() if not buffer or type(buffer.create)~='function' then %s=true return end local %s=buffer.create(8) buffer.writeu8(%s,0,0xFE) if buffer.readu8(%s,0)~=0xFE then %s=true end buffer.writeu16(%s,1,0xBEEF) if buffer.readu16(%s,1)~=0xBEEF then %s=true end local %s=buffer.fromstring('IB0') if buffer.tostring(%s)~='IB0' then %s=true end end)"):format(
        f, T, T, T, f, T, T, f, T.."s", T.."s", f))

    -- table.freeze if present
    L(("pcall(function() if type(table.freeze)~='function' then return end local %s=table.freeze({a=1}) if type(table.isfrozen)=='function' and not table.isfrozen(%s) then %s=true end if pcall(function() %s.a=2 end) then %s=true end end)"):format(T, T, f, T, f))

    -- bit32
    L(("pcall(function() if type(bit32)~='table' then return end if bit32.bxor(0x12345678,0xFFFFFFFF)~=0xEDCBA987 then %s=true end end)"):format(f))

    -- Signal identity: Event same semantic, not rawequal userdata
    L(("pcall(function() local %s=Instance.new('BindableEvent') local %s=%s.Event local %s=%s.Event if %s~=%s then %s=true end if rawequal(%s,%s) then %s=true end if typeof(%s)~='RBXScriptSignal' then %s=true end local %s=%s:Connect(function()end) if not %s.Connected then %s=true end %s:Disconnect() if %s.Connected then %s=true end %s:Destroy() end)"):format(
        T, T.."a", T, T.."b", T, T.."a", T.."b", f, T.."a", T.."b", f, T.."a", f, T.."c", T.."a", T.."c", f, T.."c", T.."c", f, T))

    -- task C metadata via debug.info when available
    L(("pcall(function() if type(debug)~='table' or type(debug.info)~='function' or type(task)~='table' then return end local %s,%s,%s=debug.info(task.wait,'sln') if %s~='[C]' then %s=true end if type(task.spawn)~='function' or type(task.defer)~='function' then %s=true end end)"):format(
        T, T.."l", T.."n", T, f, f))

    -- Random deterministic sample (not full stream - one seed check)
    L(("pcall(function() if type(Random)~='table' or type(Random.new)~='function' then return end local %s=Random.new(1515359100) local %s=%s:NextInteger(532,1117) if %s~=763 then %s=true end end)"):format(T, T.."r", T, T.."r", f))

    -- vector.create if present
    L(("pcall(function() if type(vector)~='table' or type(vector.create)~='function' then return end local %s=vector.create(1,2,3) if typeof(%s)~='Vector3' then %s=true end end)"):format(T, T, f))

    -- legacy wait must not alias task.wait when both exist
    L(("pcall(function() if type(task)~='table' or type(task.wait)~='function' then return end local %s=rawget(_G,'wait') or (getfenv and rawget(getfenv(0),'wait')) if type(%s)=='function' and rawequal(%s,task.wait) then %s=true end end)"):format(T, T, T, f))

    return table.concat(parts, " ")
end


--- WynFuscate-style anti-env (softened for real executors).
-- Hard-fail only on clear stub/env-logger breaks. Stack sampling is observe-only.
function AntiTamper:emitWynFuscateProbes(N, opts)
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    local f = N.fail

    -- 1) Core Roblox surface (real executors pass; pure stubs fail)
    L(("pcall(function() if game==nil or type(game)==type({}) then %s=true end local ni=Instance and Instance.new if type(ni)~='function' then %s=true end local gs=game and game.GetService if type(gs)~='function' then %s=true end local ok,pl=pcall(gs,game,'Players') if not ok or pl==nil or type(pl)==type({}) then %s=true end end)"):format(f,f,f,f))

    -- 2) Native [C] for a few core funcs — only trip if MOST fail (hooked env loggers)
    L(("pcall(function() local info=debug and debug.info if type(info)~='function' then return end local bad=0 local function cn(v) if type(v)~='function' then return end local ok,src=pcall(info,v,'s') if not ok or (src~='[C]' and src~='C') then bad=bad+1 end end cn(pcall) cn(type) cn(error) cn(info) if bad>=3 then %s=true end end)"):format(f))

    -- 3) restorefunction when present (never fails — best-effort unhook)
    L([=[pcall(function() if type(getgenv)~='function' then return end local ok,env=pcall(getgenv) if not ok or type(env)~='table' then return end local restore=rawget(env,'restorefunction') if type(restore)~='function' then return end local function one(v) if v then pcall(restore,v) end end one(string and string.byte) one(setmetatable) one(pcall) one(rawget) one(rawset) one(pairs) one(type) end)]=])

    -- 4) makeSeed fingerprint (side effect only, never fails)
    L([=[pcall(function() local vok,vec=pcall(function() local T=Vector3int16 return T and T.new and T.new(1,2,3) end) local vv=0 if vok and vec then vv=(vec.X or 0)*31+(vec.Y or 0)*17+(vec.Z or 0)*13 end end)]=])

    return table.concat(parts, " ")
end

--- Lightcore marker + ASCII art (replaces ironb2 bait). Safe no-op outside executors.
function AntiTamper:emitLightcoreMarker(N, opts)
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    -- install getgenv.radium stub + ascii longstring bait (does not return early)
    L([=[pcall(function() local genv=getgenv and getgenv() if type(genv)=='table' then genv['radium']=function()end end end)]=])
    -- table tostring identity probe (elysium-style); only flags fail, never aborts host chunk
    L([=[pcall(function() local _=string.sub(tostring({}),8,15) end)]=])
    return table.concat(parts, " ")
end

--- ASCII banner emitted when AT trips (printed then error).
function AntiTamper:emitLightcoreAsciiFail()
    -- Single-line embed so anti-beautify newline count stays low
    return "pcall(print,\"                        .@%(/*,.......      ...,,*/(#%&@@.\n                     (*   ,/(#%%&&@@@@&%((////(((##%###((/**,,.     ,//(&.\n                   /* .%@@@@@@@@%,  .(&@@@&&&&&&@@@@@@&#(*,........*%@@@(.  ,#.\n                 */ .&@@@@@@@*  (%,   *(&&@@@@@&%(*,.             .,*(#%(*@@&*  *,\n                #, /@@@@@@* *&( ,&&/.,/#%&&@@@&(&@@@@@@@@@@@@#*,.....,/&@@@@@@@@( .%\n               #  #@@@@@*/@% .#%./(,.,/*,//*,.,/(*@@@@@@@@@@@@%@@@@@@@@@#.#@@@@@@&. %\n              /  &@@@@@@@@(%@# *&&*&@@@@#/&@@@@/%%.,%@@@@@@@%/@@&(,  ,,,...  *%@@@# *\n            #  .&@@@@@@@@@@@,((%@@@@@#.    ,&@@#@@&* .&@@@@@&,.#@@@@/&@@%(@@@&(/,(&, /,\n         (/   (@&&&%&@@@&/, ,@#(@@@@,        #@@/,&@& /@@@@@,%#%@@@@@(     *@@@@@&,%%. .\n        /  #/,#@@@&#(//#@@@/ %@@@&@@@(.    ,&@@(.*/*  %@@*   %@@@@@@%       (@@&(*...%&.\n         ///@@&,  (&@@#,   /@/ ,*&@@@@#&@@%#%((%@&* /@@@@@@&. #@@@#&@@@&%%@@@@@@&,/(*@/#\n        %%.&@# .&@@@# /@@@@%&@@@&/.   ,/((/*,  ./&@@@@@@@@@@,*&(./%@@#*&@@@(#(....,&#*@/\n        @%.&& .&@@@&*    /&@@@@@@@@@@@@@@@@&@@#/(%@@@@@@@@@@&,  (@@@@@@@@@@@@/,@@@@@#.&*\n        &&,%% .&*    /@@@(.  ,(@@@@@&/(////#( /&@@@@@@@@@@@@@@@(  ,&@@@@@@@@&, (@@&*/@(/\n        .%*#@( /@@@@( *@@@@@@/     *%@@@@@@@&.,@& ,#, .&@@@@@@# .#*%&/,#@@@@*   *@@&/*&*\n         .&/.#@@@@@@@,   *&@@%.,&@@&(,    ,(%@%&@@@@@@@@@(.*,  /@@@@@@@@@&,      %@@@@..\n        @* .%@@@@@@@@(       .   (@@@@@@@@(       .*(%&@@@@@@@@@@@@&(,  ./.*@%   /@@% ./\n          @* .&@@@@@@&.             ./&@@@*.&@@@@@@@&, ,**,.    .,*(&(.%@@# %@*  ,@@% ,#\n            &, /@@@@@@*                    .#@@@@@@@@*.%@@@@@(,@@@@@@& ,%(.      .&@% ,#\n              / *@@@@@#                                                           %@&.,#\n              (( .&@@@@*                                                          #@&.,#\n               .&. ,&@@@,                                                         (@&.,#\n                  #. .%@@* /@@/                                                   /@&.,(\n                    ./  #@%. %@&,,#,                                              /@@,./\n                      *(  #@%. . (@@@@@%/,                                        /@@,.*\n                        //  %@&, *@@@@@@@@( (@%/.                                 #@@, (\n                          #* .&@@#. (@@@@&.*@@@@@@@@%. */.                  *..%*.&@@, /\n                            @* .%@@@%, ,/ .@@@@@@@@@@,.%@@@@@% .&@@@* #@&..&@*,* %@@&. *\n                               /  *&@@@@%,   *(&@@@@&. #@@@@@* #@@@% (@@* ,.   /@@@@* (\n                                 @#. .#@@@@@@&(,.                      .,*(%&@@@@@&..(\n                                     &(.   ./%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@(. ((\n                                          ,#/*.       ..,,,,,,,,....          ,/#\")"
end


--- ASTRA-derived Roblox integrity probes (compact). Soft-skip if API missing.
function AntiTamper:emitAstraProbes(N, opts)
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    local f = N.fail

    -- Core runtime
    L(("pcall(function() if type(pcall)~='function' or type(type)~='function' or type(tostring)~='function' then %s=true end end)"):format(f))

    -- TweenService linear GetValue
    L(("pcall(function() local ts=game:GetService('TweenService') if not ts or type(ts.GetValue)~='function' then %s=true return end if ts:GetValue(0,Enum.EasingStyle.Linear,Enum.EasingDirection.In)~=0 then %s=true end if ts:GetValue(1,Enum.EasingStyle.Linear,Enum.EasingDirection.Out)~=1 then %s=true end local m=ts:GetValue(0.375,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut) if math.abs(m-0.375)>=1e-9 then %s=true end end)"):format(f,f,f,f))

    -- Actor hierarchy
    L(("pcall(function() local a=Instance.new('Actor') a.Parent=workspace if a:GetActor()~=a then %s=true end local c=Instance.new('Folder') c.Parent=a if c:GetActor()~=a then %s=true end local u=Instance.new('Folder') if u:GetActor()~=nil then %s=true end u:Destroy() c:Destroy() a:Destroy() end)"):format(f,f,f))

    -- BindableEvent
    L(("pcall(function() local e=Instance.new('BindableEvent') local fired,ra,rb=false,nil,nil e.Event:Connect(function(a,b) fired=true ra=a rb=b end) e:Fire(73,'ok') if task and task.wait then task.wait() end if not(fired and ra==73 and rb=='ok') then %s=true end e:Destroy() end)"):format(f))

    -- BindableFunction
    L(("pcall(function() local fn=Instance.new('BindableFunction') local inv=false fn.OnInvoke=function(a,b) inv=true return a,b end local a,b=fn:Invoke(73,'ok') if not(inv and a==73 and b=='ok') then %s=true end fn:Destroy() end)"):format(f))

    -- CollectionService
    L(("pcall(function() local cs=game:GetService('CollectionService') local folder=Instance.new('Folder') folder.Parent=workspace local added,removed=false,false cs:GetInstanceAddedSignal('CLD_TG'):Connect(function(i) if i==folder then added=true end end) cs:GetInstanceRemovedSignal('CLD_TG'):Connect(function(i) if i==folder then removed=true end end) cs:AddTag(folder,'CLD_TG') if task and task.wait then task.wait() end local found=false for _,i in ipairs(cs:GetTagged('CLD_TG')) do if i==folder then found=true break end end if not(added and found) then %s=true end cs:RemoveTag(folder,'CLD_TG') if task and task.wait then task.wait() end if not(removed and not cs:HasTag(folder,'CLD_TG')) then %s=true end folder:Destroy() end)"):format(f,f))

    -- Attribute + Name signals + Clone
    L(("pcall(function() local folder=Instance.new('Folder') local at,nm=false,false folder:GetAttributeChangedSignal('CLD_A'):Connect(function() at=true end) folder.Changed:Connect(function(p) if p=='Name' then nm=true end end) folder:SetAttribute('CLD_A',1) folder.Name='CLD_O' if task and task.wait then task.wait() end if not at then %s=true end if not nm then %s=true end local ch=Instance.new('Folder') ch.Name='CLD_C' ch.Parent=folder local cl=folder:Clone() if not cl:FindFirstChild('CLD_C') then %s=true end cl:Destroy() folder:Destroy() end)"):format(f,f,f))

    -- Terrain exists
    L(("pcall(function() if workspace.Terrain==nil then %s=true end end)"):format(f))

    -- SkateboardController props
    L(("pcall(function() local c=Instance.new('SkateboardController') c.Steer=1 c.Throttle=1 if c.Steer~=1 or c.Throttle~=1 then %s=true end c:Destroy() end)"):format(f))

    -- Handshake mix (deterministic)
    L(("pcall(function() local function u32(n) n=tonumber(n) or 0 n=n%%4294967296 if n<0 then n=n+4294967296 end return n end local function bx(a,b) if bit32 then return bit32.bxor(u32(a),u32(b)) end local r,bit=0,1 a,b=u32(a),u32(b) for _=1,32 do if a%%2~=b%%2 then r=r+bit end a=math.floor(a/2) b=math.floor(b/2) bit=bit*2 end return u32(r) end local function rs(v,n) if bit32 then return bit32.rshift(u32(v),n) end return math.floor(u32(v)/(2^n)) end local function mix(x) x=u32(x) x=bx(x,rs(x,16)) x=u32(x*0x7FEB352D) x=bx(x,rs(x,15)) x=u32(x*0x846CA68B) x=bx(x,rs(x,16)) return u32(x) end local a,b=mix(12345),mix(12345) if bx(a,b)~=0 then %s=true end if mix(0)~=0 then %s=true end end)"):format(f,f))

    return table.concat(parts, " ")
end

function AntiTamper:emitPrelude(N, opts)
    opts = opts or {}
    local parts = {}
    local function L(s) parts[#parts + 1] = s end
    local trip = AntiTamper.emitTrip(self.detectMessage)

    L(("%s=false"):format(N.fail))

    -- ========== ROBLOX ONLY ==========
    if self.checkStringMt then
        -- Luau strings normally HAVE __index (methods). Only flag hook/log in tostring of __index.
        L(("do local %s=getmetatable('') if %s and %s.__index then local %s=%s.__index if type(%s)=='function' then local %s=tostring(%s) if type(%s)=='string' and (%s:find('hook',1,true) or %s:find('log',1,true) or %s:find('spy',1,true)) then %s=true end end end end"):format(
            N.tmp, N.tmp, N.tmp,
            N.tmp.."i", N.tmp, N.tmp.."i",
            N.tmp.."s", N.tmp.."i", N.tmp.."s", N.tmp.."s", N.tmp.."s", N.tmp.."s", N.fail))
    end

    if self.checkPath2D then
        -- Only validate when Path2DControlPoint exists (client). Missing API = skip, not fail.
        L(("pcall(function() local %s=Path2DControlPoint if type(%s)=='table' and type(%s.new)=='function' then local %s,%s={},false for %s,%s in next,{[1]={UDim2.new(15,15,15,15),UDim2.new(0,0,0,0),UDim2.new(0,0,0,0)},[2]={UDim2.new(15,15,15,15),UDim2.new(15,15,15,15),UDim2.new(0,0,0,0)},[3]={UDim2.new(15,15,15,15),UDim2.new(15,15,15,15),UDim2.new(15,15,15,15)}} do local %s=%s.new(table.unpack(%s)) if %s.Position~=%s[1] or %s.LeftTangent~=%s[2] or %s.RightTangent~=%s[3] then %s=true break end table.insert(%s,%s) end if %s then %s=true end if %s[1]==%s[2] or %s[2]==%s[3] or %s[3]==%s[1] then %s=true end end end)"):format(
            N.tmp, N.tmp, N.tmp,
            N.tmp.."o", N.tmp.."e", N.tmp.."i", N.tmp.."v",
            N.tmp.."p", N.tmp, N.tmp.."v",
            N.tmp.."p", N.tmp.."v", N.tmp.."p", N.tmp.."v", N.tmp.."p", N.tmp.."v", N.tmp.."e",
            N.tmp.."o", N.tmp.."p",
            N.tmp.."e", N.fail,
            N.tmp.."o", N.tmp.."o", N.tmp.."o", N.tmp.."o", N.tmp.."o", N.tmp.."o", N.fail))
    end

    if self.checkRobloxDeep then
        L(self:emitServiceProbes(N, opts))
        if self.checkPartHierarchy then
            L(self:emitPartHierarchyProbes(N, opts))
        end
        if self.checkFrameHierarchy then
            L(self:emitFrameHierarchyProbes(N, opts))
        end
        L(self:emitLightcoreMarker(N, opts))
        L(self:emitLuraphStyleEnvProbes(N, opts))
        if self.checkWynFuscate then
            L(self:emitWynFuscateProbes(N, opts))
        end
        if self.checkAstra then
            L(self:emitAstraProbes(N, opts))
        end
        -- Math / MemStorage log probe
        L(("pcall(function() local %s=game:GetService('MemStorageService') local %s=math.log(100,10) %s:SetItem('IB0',tostring(%s)) local %s=tonumber(%s:GetItem('IB0')) if %s==nil or math.abs(%s-2)>1e-5 then %s=true end end)"):format(
            N.tmp, N.tmp.."l", N.tmp, N.tmp.."l", N.tmp.."b", N.tmp, N.tmp.."b", N.tmp.."b", N.fail))
        -- CollectionService tag roundtrip
        L(("pcall(function() local %s=game:GetService('CollectionService') local %s='IB0_'..tostring(math.floor(math.log(8,2)*1000)) local %s=Instance.new('Part') %s.Parent=workspace %s:AddTag(%s,%s) local %s=%s:GetTagged(%s) if type(%s)~='table' or #%s~=1 or %s[1]~=%s then %s=true end %s:RemoveTag(%s,%s) if #%s:GetTagged(%s)~=0 then %s=true end %s:Destroy() end)"):format(
            N.tmp, N.tmp.."t", N.tmp.."p", N.tmp.."p", N.tmp, N.tmp.."p", N.tmp.."t",
            N.tmp.."g", N.tmp, N.tmp.."t", N.tmp.."g", N.tmp.."g", N.tmp.."g", N.tmp.."p", N.fail,
            N.tmp, N.tmp.."p", N.tmp.."t", N.tmp, N.tmp.."t", N.fail, N.tmp.."p"))
        -- SoundService DistanceFactor
        L(("pcall(function() local %s=game:GetService('SoundService').DistanceFactor if %s<=0 then %s=true end local %s=%s*math.pi local %s=%s/math.pi if math.abs(%s-%s)>1e-5 then %s=true end end)"):format(
            N.tmp, N.tmp, N.fail, N.tmp.."v", N.tmp, N.tmp.."r", N.tmp.."v", N.tmp.."r", N.tmp, N.fail))
        -- MembershipType shape
        L(("pcall(function() local %s=game:GetService('Players').LocalPlayer local %s=%s.MembershipType if typeof(%s)~='EnumItem' then %s=true end if %s.EnumType~=Enum.MembershipType then %s=true end local %s=%s.Value if type(%s)~='number' or (%s~=0 and %s~=4) then %s=true end end)"):format(
            N.tmp, N.tmp.."m", N.tmp, N.tmp.."m", N.fail, N.tmp.."m", N.fail, N.tmp.."v", N.tmp.."m", N.tmp.."v", N.tmp.."v", N.tmp.."v", N.fail))
        -- MarketplaceService PromptPremiumPurchase
        L(("pcall(function() if typeof(game:GetService('MarketplaceService').PromptPremiumPurchase)~='function' then %s=true end end)"):format(N.fail))
        -- getfenv name scan for hook/closure
        L(("pcall(function() local %s=0 for %s,%s in next,getfenv() do local %s=tostring(%s):lower() if %s:find('hook',1,true) or %s:find('closure',1,true) then %s=%s+1 end end if %s~=0 then %s=true end end)"):format(
            N.tmp, N.tmp.."k", N.tmp.."v", N.tmp.."s", N.tmp.."k", N.tmp.."s", N.tmp.."s", N.tmp, N.tmp, N.tmp, N.fail))
        -- Core instance sanity
        L(("pcall(function() if game.ClassName~='DataModel' or workspace.ClassName~='Workspace' then %s=true end if typeof(Enum.Material.Plastic)~='EnumItem' then %s=true end if typeof(game.Changed)~='RBXScriptSignal' then %s=true end local %s=Instance.new('Part') if typeof(%s)~='Instance' or %s.ClassName~='Part' then %s=true end %s:Destroy() local %s=CFrame.new(1,2,3) if %s.X~=1 or %s.Y~=2 or %s.Z~=3 then %s=true end end)"):format(
            N.fail, N.fail, N.fail, N.tmp, N.tmp, N.tmp, N.fail, N.tmp, N.tmp.."c", N.tmp.."c", N.tmp.."c", N.tmp.."c", N.fail))
        -- Camera ray
        L(("pcall(function() local %s=workspace.CurrentCamera:ScreenPointToRay(100,100) if typeof(%s.Origin)~='Vector3' then %s=true end end)"):format(N.tmp, N.tmp, N.fail))
        -- CFrame point transform
        L(("pcall(function() local %s=CFrame.new(5,2,1) local %s=Vector3.new(1,0,0) local %s=%s:PointToObjectSpace(%s:PointToWorldSpace(%s)) if (%s-%s).Magnitude>=1e-6 then %s=true end end)"):format(
            N.tmp, N.tmp.."p", N.tmp.."o", N.tmp, N.tmp, N.tmp.."p", N.tmp.."o", N.tmp.."p", N.fail))
        -- Font name
        L(("pcall(function() if Enum.Font.SourceSans.Name~='SourceSans' then %s=true end end)"):format(N.fail))
        -- Lighting clock
        L(("pcall(function() local %s=game:GetService('Lighting') local %s=%s.ClockTime %s.ClockTime=12 local %s=%s.ClockTime==12 %s.ClockTime=%s if not %s then %s=true end end)"):format(
            N.tmp, N.tmp.."o", N.tmp, N.tmp, N.tmp.."k", N.tmp, N.tmp, N.tmp.."o", N.tmp.."k", N.fail))
        -- ContentProvider BaseUrl (client should be roblox.com)
        L(("pcall(function() local %s,%s=pcall(function() return game:GetService('ContentProvider').BaseUrl end) if %s and type(%s)=='string' then local %s=%s:lower() if not (%s:find('roblox.com',1,true) or %s:find('roblox.cn',1,true)) then %s=true end end end)"):format(
            N.tmp.."ok", N.tmp.."u", N.tmp.."ok", N.tmp.."u", N.tmp.."l", N.tmp.."u", N.tmp.."l", N.tmp.."l", N.fail))
        -- PhysicsSettings integrity (settings() service)
        L(("pcall(function() if type(settings)~='function' then return end local %s=settings():GetService('PhysicsSettings') if not %s then return end if %s.ShowDecompositionGeometry==true then %s=true end if %s.AllowSleep==false then %s=true end end)"):format(
            N.tmp, N.tmp, N.tmp, N.fail, N.tmp, N.fail))
        -- Attribute signal identity + set/get/delete (Roblox Instance attrs)
        L(("pcall(function() local p=Instance.new('Part') local s1=p:GetAttributeChangedSignal('IB0AT') local s2=p:GetAttributeChangedSignal('IB0AT') if s1~=s2 then %s=true end local fired=0 local conn=s1:Connect(function() fired=fired+1 end) p:SetAttribute('IB0AT',1337) if p:GetAttribute('IB0AT')~=1337 then %s=true end if typeof(conn)~='RBXScriptConnection' and type(conn)~='userdata' then %s=true end p:SetAttribute('IB0AT',nil) if p:GetAttribute('IB0AT')~=nil then %s=true end if conn.Disconnect then conn:Disconnect() end p:Destroy() end)"):format(
            N.fail, N.fail, N.fail, N.fail))
        -- SYNC-style condensed integrity (legit-Roblox safe)
        L(("pcall(function() local a=assert local e=error local p=pcall local ty=type local tg=typeof if a~=assert or e~=error or p~=pcall or ty~=type then %s=true end if select('#',(function(...) return select('#',...),... end)('h',nil,'t'))~=3 then %s=true end local w={} local mt={__index=function(_,k) return 'i:'..tostring(k) end,__newindex=function(_,k,v) w[k]=v end,__add=function(l,r) return rawget(l,'v')+rawget(r,'v') end,__tostring=function() return 'o' end} local L=setmetatable({v=13},mt) local R=setmetatable({v=7},mt) if L.m~='i:m' then %s=true end L.x=41 if w.x~=41 or (L+R)~=20 or tostring(L)~='o' then %s=true end rawset(L,'raw',53) if rawget(L,'raw')~=53 or not rawequal(L,L) then %s=true end if game~=nil then if ty(game)~='userdata' or (tg and tg(game)~='Instance') or game.ClassName~='DataModel' then %s=true end local rs2=game:GetService('RunService') if not rs2 or (tg and tg(rs2)~='Instance') or rs2.ClassName~='RunService' then %s=true end end do local gm=getmetatable(game) if ty(gm)=='string' and gm~='The metatable is locked' then %s=true end end if ty(bit32)=='table' then if bit32.bxor(0x55AA55AA,0x0F0F0F0F)~=0x5AA55AA5 or bit32.band(0x12345678,0x00FF00FF)~=0x00340078 then %s=true end end if buffer and buffer.create and buffer.fromstring then local b=buffer.fromstring(string.char(0,1,127,128,255)) if buffer.len(b)~=5 then %s=true end local c=buffer.create(4) buffer.writeu8(c,0,255) if buffer.readu8(c,0)~=255 then %s=true end end if Random then local rng=Random.new(51018400) local n=rng:NextNumber() if ty(n)~='number' or n~=n then %s=true end end local co=coroutine.create(function(v) local r=coroutine.yield(v+1) return r+2 end) local ok1,y=coroutine.resume(co,9) local ok2,res=coroutine.resume(co,11) if not ok1 or y~=10 or not ok2 or res~=13 then %s=true end local vals={4,1,3} table.insert(vals,2,2) if table.concat(vals,',')~='4,2,1,3' then %s=true end if string.sub('abcdef',2,-2)~='bcde' or tonumber('ff',16)~=255 or math.floor(-1.25)~=-2 then %s=true end local nan=0/0 if not (nan~=nan) or ((-17)%%5)~=3 then %s=true end end)"):format(
            N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail, N.fail))

        -- Continuous math/string probes via spawn (non-blocking)
        L(("pcall(function() if spawn then spawn(function() while true do if math.abs(math.sin(0))>1e-9 then error(%q,0) end if string.len('IronBrew')~=8 then error(%q,0) end if task and task.wait then task.wait(2) else break end end end) end end)"):format(
            self.detectMessage, self.detectMessage))
    end

    -- ========== SHARED ==========
    if self.checkGetfenv then
        L(("do local %s=rawget and rawget(_G,'getfenv') or getfenv if type(%s)=='function' then local %s=%s(0) if type(%s)~='table' then %s=true end end end"):format(
            N.tmp, N.tmp, N.tmp.."e", N.tmp, N.tmp.."e", N.fail))
    end

    if self.checkDebug then
        L(("do local %s=debug if type(%s)=='table' and type(%s.sethook)=='function' then pcall(function() %s.sethook() end) end end"):format(
            N.tmp, N.tmp, N.tmp, N.tmp))
    end

    if self.checkBeautify then
        L(("do local %s=debug and debug.getinfo and debug.getinfo(1,'S') if %s and type(%s.source)=='string' then local %s=0 for _ in %s.source:gmatch('\\n') do %s=%s+1 end if %s>50000 then %s=true end end end"):format(
            N.tmp, N.tmp, N.tmp, N.tmp.."n", N.tmp, N.tmp.."n", N.tmp.."n", N.tmp.."n", N.fail))
    end

    -- Integrity without bitwise ~  (uses arithmetic mix matching checksum())
    if self.integrity and opts.mainHash and opts.protosName and opts.mainIdx then
        L(("do local %s=2166136261 local %s=%s[%d][1] for %s=1,#%s do local %s=(%s[%s] or 0)%%256 %s=(%s+%s*16777619+%s*31)%%4294967296 end if %s~=%u then %s=true end end"):format(
            N.tmp, N.tmp.."c", opts.protosName, opts.mainIdx, N.tmp.."i", N.tmp.."c",
            N.tmp.."b", N.tmp.."c", N.tmp.."i", N.tmp, N.tmp, N.tmp.."b", N.tmp.."i",
            N.tmp, opts.mainHash % 4294967296, N.fail))
    end

    L("if " .. N.fail .. " then " .. self:emitLightcoreAsciiFail() .. " " .. trip .. " end")
    return table.concat(parts, " ")
end

return AntiTamper
