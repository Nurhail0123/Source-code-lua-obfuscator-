-- Host AT disabled by default (was loadstring-decrypted on day-1 dumps).
-- Kept as empty payload so old requires do not crash.
return [====[
do end
]====]
