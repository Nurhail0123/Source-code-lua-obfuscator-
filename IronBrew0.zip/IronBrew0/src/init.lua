-- Lightcore v1.0 - Main module loader

local Lightcore = {
    version = "1.4",
    name = "Lightcore",
}

local function addPath()
    local info = debug.getinfo(1, "S")
    local path = info.source:match("^@(.*/)") or "./"
    package.path = path .. "?.lua;" .. path .. "?/init.lua;" .. package.path
end
addPath()

Lightcore.Token       = require("src.Lexer.Token")
Lightcore.Lexer       = require("src.Lexer.Lexer")
Lightcore.Nodes       = require("src.AST.Nodes")
Lightcore.Printer     = require("src.AST.Printer")
Lightcore.Parser      = require("src.Parser.Parser")
Lightcore.Scope       = require("src.Obfuscation.Rename.Scope")
Lightcore.Renamer     = require("src.Obfuscation.Rename.Renamer")
Lightcore.Minifier    = require("src.Obfuscation.Minify.Minifier")
Lightcore.Flattener   = require("src.Obfuscation.ControlFlow.Flattener")
Lightcore.IR          = require("src.IR.IR")
Lightcore.IRCompiler  = require("src.IR.Compiler")
Lightcore.Presets     = require("src.Presets.Presets")
Lightcore.Encoder     = require("src.VM.Encoder.Encoder")
Lightcore.VMGenerator = require("src.VM.Generator.Generator")

function Lightcore.parse(source, options)
    options = options or {}
    local lexer = Lightcore.Lexer.new(source, options)
    local tokens = lexer:tokenize()
    local parser = Lightcore.Parser.new(tokens, options)
    local ast, errors = parser:parse()
    return {
        ast = ast,
        tokens = tokens,
        errors = errors or {},
        lexerErrors = lexer.errors or {},
    }
end

function Lightcore.printAst(ast, options)
    local printer = Lightcore.Printer.new(options)
    return printer:print(ast)
end

function Lightcore.rename(ast, options)
    local renamer = Lightcore.Renamer.new(options or {})
    return renamer:run(ast, options)
end

function Lightcore.minify(ast, options)
    local minifier = Lightcore.Minifier.new(options or {})
    return minifier:minify(ast)
end

function Lightcore.controlFlow(ast, options)
    local flattener = Lightcore.Flattener.new(options or {})
    return flattener:run(ast)
end

Lightcore.ATIR = require("src.Obfuscation.AntiTamper.ATIR")

function Lightcore.mutate(mod, options)
    local Mutator = require("src.Obfuscation.Mutation.Mutator")
    return Mutator.mutate(mod, options or {})
end

function Lightcore.compileIR(ast, options)
    local comp = Lightcore.IRCompiler.new(options or {})
    return comp:compile(ast)
end

function Lightcore.encodeBytecode(module, options)
    local enc = Lightcore.Encoder.new(options or {})
    return enc:encode(module)
end

function Lightcore.generateVM(bytecode, options)
    local gen = Lightcore.VMGenerator.new(options or {})
    return gen:generate(bytecode)
end

--- High-level pipeline
-- Order: parse → [CF] → rename → [VM path: IR→bytecode→VM] or [minify]
function Lightcore.obfuscate(source, options)
    options = options or {}

    if options.preset then
        local preset = Lightcore.Presets.get(options.preset)
        for k, v in pairs(preset) do
            if options[k] == nil then
                options[k] = v
            end
        end
    end
    if options.controlFlow == nil then options.controlFlow = false end
    if options.vm == nil then options.vm = false end

    -- Stage-2 AT inside encrypted VM blob (not host shell)
    do
        local tgt = tostring(options.target or options.preset or ""):lower()
        local robloxish = tgt:find("roblox", 1, true) or tgt:find("executor", 1, true) or tgt:find("luau", 1, true)
        -- AT runs native on host (Roblox APIs need real Luau, not VM)
        -- see Generator hostAt; do not prepend into bytecode
        if false and options.antiTamper ~= false and options.vm and robloxish then
            local ok, atSrc = pcall(require, "src.Obfuscation.AntiTamper.LightcoreSource")
            if ok and type(atSrc) == "string" and #atSrc > 0 then
                source = atSrc .. "\n" .. source .. "\nend)()\n"
            end
        end
    end

    do
        local ok, MacroPass = pcall(require, "src.Obfuscation.Macros.MacroPass")
        if ok and MacroPass and MacroPass.apply then
            source = MacroPass.apply(source, options)
        end
    end
    local result = Lightcore.parse(source, options)
    if #result.errors > 0 then
        return nil, result.errors
    end
    local ast = result.ast

    -- Control-flow on AST (useful even before VM as extra layer)
    if options.controlFlow and not options.vm then
        -- when VM is on, CF on AST can confuse IR; apply CF only for non-VM path
        Lightcore.controlFlow(ast, {
            intensity     = options.intensity or 1.0,
            minStatements = options.minStatements or 2,
            junkStates    = options.junkStates ~= false,
            stateName     = options.stateName or "__s",
        })
    end

    if options.rename ~= false then
        Lightcore.rename(ast, options)
    end

    -- VM path: AST → IR → bytecode → self-contained loader
    if options.vm then
        local mod = Lightcore.compileIR(ast, options)
        if options.mutate ~= false then
            Lightcore.mutate(mod, {
                intensity = options.mutationIntensity or options.intensity or 1.5,
                seed = options.seed,
            })
        end
        -- v0.007aa: AT as IR prepended into main (same bytecode blob)
        if options.antiTamper ~= false then
            -- v1.3: AT as IR inside VM (no host loadstring blob)
            pcall(function()
                local ATIR = require("src.Obfuscation.AntiTamper.ATIR")
                ATIR.mergeInto(mod, options)
            end)
        end
        local bc = Lightcore.encodeBytecode(mod, {
            encryptConstants = options.encryptConstants ~= false,
            xorKey = options.xorKey or (0x41 + (os.time() % 50)),
        })
        local out = Lightcore.generateVM(bc, {
            minify = options.minify ~= false,
            singleLine = options.singleLine ~= false,
            target = options.target or "executor",
            antiTamper = options.antiTamper ~= false,
            markerVersion = options.markerVersion or options.obfuscationNode or "v1",
            scrambleOps = options.scrambleOps ~= false,
            encryptStrings = options.encryptStrings ~= false,
            seed = options.seed,
            intensity = options.intensity or 1,
            fatVM = options.fatVM ~= false,
            rollingXor = options.rollingXor ~= false,
            base85 = options.base85 ~= false,
            opaqueKeys = options.opaqueKeys ~= false,
            superOps = options.superOps ~= false,
        })
        return out, nil
    end

    local output
    if options.minify ~= false then
        output = Lightcore.minify(ast, {
            singleLine = options.singleLine ~= false,
        })
    else
        output = Lightcore.printAst(ast, options)
    end

    return output, nil
end

return Lightcore
