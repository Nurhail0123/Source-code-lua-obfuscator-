#!/usr/bin/env python3
"""Lightcore API — obfuscate Lua via the local Lightcore engine."""
from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
WEBSITE = ROOT / "website"
LUA = os.environ.get("LUA_BIN", "lua")
MAX_BYTES = int(os.environ.get("LIGHTCORE_MAX_BYTES", str(512_000)))

app = FastAPI(title="Lightcore API", version="1.2")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ObfuscateRequest(BaseModel):
    source: str = Field(..., min_length=1)
    filename: str = "script.lua"
    node: str = "v1"
    target: str = "roblox"
    antiTamper: bool = True
    vm: bool = True
    fatVM: bool = False
    controlFlow: bool = False
    staticEnvironment: bool = True
    vmCompression: bool = False
    disableLineInfo: bool = False
    useDebugLibrary: bool = True
    hardcodeGlobals: bool = False
    compatibilityMode: bool = False
    enableGcFixes: bool = False
    noVirtualize: bool = False
    optimizationLevel: int = 2


def _run_obfuscator(source: str, opts: dict[str, Any]) -> tuple[Optional[str], Optional[str]]:
    if len(source.encode("utf-8")) > MAX_BYTES:
        return None, f"Source too large (max {MAX_BYTES} bytes)"

    node = str(opts.get("node") or "v1")
    if node in ("v1.1", "1.1"):
        node = "v1.2"
    use_vm = bool(opts.get("vm", True)) and not bool(opts.get("noVirtualize"))
    anti = bool(opts.get("antiTamper", True)) and use_vm
    maximum = bool(opts.get("fatVM")) or bool(opts.get("vm"))
    preset = "minimum" if not use_vm else ("maximum" if maximum else "executor")
    target = str(opts.get("target") or "roblox")

    with tempfile.TemporaryDirectory(prefix="lc_api_") as td:
        tin = Path(td) / "in.lua"
        tout = Path(td) / "out.lua"
        tin.write_text(source, encoding="utf-8")
        runner = Path(td) / "run.lua"
        runner.write_text(
            f"""
package.path = [[{ROOT}/?.lua;{ROOT}/?/init.lua;]] .. package.path
local ok, L = pcall(require, "src.init")
if not ok then
  io.stderr:write("require failed: " .. tostring(L) .. "\\n")
  os.exit(2)
end
local f = io.open([[{tin}]], "r")
local src = f:read("*a")
f:close()
local opts = {{
  preset = "{preset}",
  target = "{target}",
  vm = {str(use_vm).lower()},
  antiTamper = {str(anti).lower()},
  fatVM = {str(bool(opts.get("fatVM"))).lower()},
  controlFlow = {str(bool(opts.get("controlFlow"))).lower()},
  scrambleOps = true,
  superOps = true,
  encryptStrings = true,
  rollingXor = true,
  singleLine = true,
  base85 = {str(bool(opts.get("vmCompression"))).lower()},
  minify = true,
  rename = true,
  staticEnvironment = {str(bool(opts.get("staticEnvironment"))).lower()},
  disableLineInfo = {str(bool(opts.get("disableLineInfo"))).lower()},
  useDebugLibrary = {str(bool(opts.get("useDebugLibrary"))).lower()},
  hardcodeGlobals = {str(bool(opts.get("hardcodeGlobals"))).lower()},
  compatibilityMode = {str(bool(opts.get("compatibilityMode"))).lower()},
  enableGcFixes = {str(bool(opts.get("enableGcFixes"))).lower()},
  optimizationLevel = {int(opts.get("optimizationLevel") or 2)},
  obfuscationNode = "{node}",
  markerVersion = "{node}",
}}
if not opts.vm then
  opts.preset = "minimum"
  opts.antiTamper = false
end
local out, errs = L.obfuscate(src, opts)
if not out then
  local msg = "obfuscate failed"
  if type(errs) == "table" and errs[1] then
    msg = tostring(errs[1].message or errs[1])
  end
  io.stderr:write(msg .. "\\n")
  os.exit(1)
end
local o = io.open([[{tout}]], "w")
o:write(out)
o:close()
print("OK")
""",
            encoding="utf-8",
        )
        try:
            proc = subprocess.run(
                [LUA, str(runner)],
                cwd=str(ROOT),
                capture_output=True,
                text=True,
                timeout=120,
            )
        except FileNotFoundError:
            return None, f"Lua binary not found ({LUA}). Set LUA_BIN."
        except subprocess.TimeoutExpired:
            return None, "Obfuscation timed out (120s)."
        if proc.returncode != 0:
            err = (proc.stderr or proc.stdout or "unknown error").strip()
            return None, err[:2000]
        if not tout.exists():
            return None, "No output produced."
        return tout.read_text(encoding="utf-8", errors="replace"), None


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "service": "lightcore",
        "version": "1.2",
        "lua": LUA,
        "root": str(ROOT),
    }


@app.post("/api/obfuscate")
def obfuscate(body: ObfuscateRequest):
    out, err = _run_obfuscator(body.source, body.model_dump())
    if err:
        raise HTTPException(status_code=400, detail=err)
    return {
        "ok": True,
        "filename": Path(body.filename).stem + ".lightcore.lua",
        "size": len(out or ""),
        "output": out,
        "node": body.node if body.node not in ("v1.1", "1.1") else "v1.2",
    }


@app.post("/api/obfuscate/file")
async def obfuscate_file(
    file: UploadFile = File(...),
    node: str = Form("v1"),
    target: str = Form("roblox"),
    antiTamper: str = Form("true"),
    vm: str = Form("true"),
    fatVM: str = Form("false"),
    controlFlow: str = Form("false"),
    staticEnvironment: str = Form("true"),
    vmCompression: str = Form("false"),
    disableLineInfo: str = Form("false"),
    useDebugLibrary: str = Form("true"),
    hardcodeGlobals: str = Form("false"),
    compatibilityMode: str = Form("false"),
    enableGcFixes: str = Form("false"),
    noVirtualize: str = Form("false"),
    optimizationLevel: int = Form(2),
):
    raw = await file.read()
    if len(raw) > MAX_BYTES:
        raise HTTPException(400, f"File too large (max {MAX_BYTES} bytes)")
    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(400, "File must be UTF-8 text")

    def flag(s: str) -> bool:
        return str(s).lower() in ("1", "true", "yes", "on")

    opts = {
        "node": node,
        "target": target,
        "antiTamper": flag(antiTamper),
        "vm": flag(vm),
        "fatVM": flag(fatVM),
        "controlFlow": flag(controlFlow),
        "staticEnvironment": flag(staticEnvironment),
        "vmCompression": flag(vmCompression),
        "disableLineInfo": flag(disableLineInfo),
        "useDebugLibrary": flag(useDebugLibrary),
        "hardcodeGlobals": flag(hardcodeGlobals),
        "compatibilityMode": flag(compatibilityMode),
        "enableGcFixes": flag(enableGcFixes),
        "noVirtualize": flag(noVirtualize),
        "optimizationLevel": optimizationLevel,
    }
    out, err = _run_obfuscator(source, opts)
    if err:
        raise HTTPException(status_code=400, detail=err)
    name = Path(file.filename or "script.lua").stem + ".lightcore.lua"
    return JSONResponse(
        {
            "ok": True,
            "filename": name,
            "size": len(out or ""),
            "output": out,
            "node": opts["node"],
        }
    )


# Static website (index.html is self-contained)
if WEBSITE.is_dir():
    @app.get("/")
    def index():
        return FileResponse(WEBSITE / "index.html")

    # optional assets if present
    if (WEBSITE / "css").is_dir():
        app.mount("/css", StaticFiles(directory=str(WEBSITE / "css")), name="css")
    if (WEBSITE / "js").is_dir():
        app.mount("/js", StaticFiles(directory=str(WEBSITE / "js")), name="js")


def main():
    import uvicorn
    port = int(os.environ.get("PORT", "8080"))
    uvicorn.run("server:app", host="0.0.0.0", port=port, reload=False)


if __name__ == "__main__":
    main()
