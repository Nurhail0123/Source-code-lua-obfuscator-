# Lightcore API

## Local

```bash
# from repo root
pip install -r api/requirements.txt
export LUA_BIN=lua   # or lua5.4
cd api && uvicorn server:app --host 0.0.0.0 --port 8080
```

- `GET  /api/health`
- `POST /api/obfuscate` JSON body
- `POST /api/obfuscate/file` multipart
- `GET  /` website

## Railway

1. New project → Deploy from GitHub (this repo)
2. Builder: Dockerfile
3. Set no secrets required for free public API (optional rate-limit later)
