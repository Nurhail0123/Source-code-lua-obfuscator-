local function process(n)
    local a = n + 1
    local b = a * 2
    local c = b - 3
    print(c)
    return c
end

local result = process(10)
print(result)
