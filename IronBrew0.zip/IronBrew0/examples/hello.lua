local function hello(name)
    print("Hello, " .. name)
end

hello("World")
