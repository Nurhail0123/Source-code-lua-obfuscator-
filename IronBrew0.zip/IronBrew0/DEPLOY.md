# Deploy Lightcore on Railway

Two services from the same repo:

## 1) Web + API (website + obfuscator)

1. Railway → New Project → Deploy from GitHub
2. Settings → Build:
   - Builder: **Dockerfile**
   - Dockerfile path: `Dockerfile`
3. Healthcheck path: `/api/health`
4. Public networking → generate domain

Env (optional):

| Variable | Default |
|----------|---------|
| `PORT` | set by Railway |
| `LUA_BIN` | `lua5.4` |
| `LIGHTCORE_MAX_BYTES` | `512000` |

## 2) Discord bot

1. Same project → **New Service** → same repo
2. Build:
   - Dockerfile path: `Dockerfile.bot`
3. Variables:

| Variable | Required |
|----------|----------|
| `IDK_TOKEN` | **Yes** — Discord bot token |
| `LUA_BIN` | optional (`lua5.4`) |

Enable Message Content Intent + DMs on the Discord application.

## Local full stack

```bash
export IDK_TOKEN="your_discord_bot_token"
docker compose up --build
# website: http://localhost:8080
# bot: runs in parallel
```

## API

- `GET  /api/health`
- `POST /api/obfuscate`
- `POST /api/obfuscate/file`
- `GET  /` — website


## Deploy on Render

### Blueprint (recommended)

1. Push repo to GitHub
2. [Render Dashboard](https://dashboard.render.com) → **New** → **Blueprint**
3. Select repo (uses `render.yaml`)
4. Create services:
   - **lightcore-web** (Docker web) — public URL
   - **lightcore-bot** (Docker worker)
5. On **lightcore-bot** → Environment → set **`IDK_TOKEN`** = Discord bot token
6. Deploy

### Manual (no Blueprint)

**Web**
- New → Web Service → Docker
- Dockerfile path: `Dockerfile`
- Health check path: `/api/health`
- Instance: Free

**Bot**
- New → Background Worker → Docker
- Dockerfile path: `Dockerfile.bot`
- Env: `IDK_TOKEN=...`

### Notes

- Free web services on Render **spin down** after idle; first request can be slow.
- Free workers also sleep on some plans — bot may disconnect; paid always-on is more reliable for Discord.
- Same Dockerfiles work for Railway and Render.


## Deploy on Fly.io

Install CLI: https://fly.io/docs/hands-on/install-flyctl/

```bash
fly auth login
```

### 1) Website + API

```bash
# from repo root
fly apps create lightcore-web   # pick a unique name if taken
fly deploy -c fly.toml -a lightcore-web
fly apps open -a lightcore-web
```

### 2) Discord bot

```bash
fly apps create lightcore-bot
fly secrets set IDK_TOKEN="your_discord_bot_token" -a lightcore-bot
fly deploy -c fly.bot.toml -a lightcore-bot
fly logs -a lightcore-bot
```

Keep bot awake (avoid auto-stop):

```bash
fly scale count 1 -a lightcore-bot
# optional: more RAM if needed
# fly scale memory 512 -a lightcore-bot
```

### Notes

- App names must be **globally unique** on Fly (`lightcore-web-yourname` if taken).
- Free allowance is limited; watch `fly dashboard`.
- Bot needs a running machine 24/7 — don’t set `auto_stop` on the bot app.
