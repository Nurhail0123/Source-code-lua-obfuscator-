#!/usr/bin/env python3
"""
Lightcore Discord bot
- DM a .lua / .luau / .txt file
- Solve captcha (letter keyboard)
- Pick obfuscation options
- Receive obfuscated file in DM
"""

from __future__ import annotations

import asyncio
import io
import os
import random
import string
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import discord
from discord import app_commands
from discord.ui import Button, Select, View
from PIL import Image, ImageDraw, ImageFont

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

# Always load config.py next to this file (works from any cwd)
_BOT_DIR = Path(__file__).resolve().parent
_CFG_PATH = _BOT_DIR / "config.py"
IDK_TOKEN = ""
_CFG_LUA = "lua"
if _CFG_PATH.is_file():
    _ns = {}
    exec(compile(_CFG_PATH.read_text(encoding="utf-8"), str(_CFG_PATH), "exec"), _ns)
    IDK_TOKEN = str(_ns.get("IDK_TOKEN", "") or "")
    _CFG_LUA = str(_ns.get("LUA_BIN", "lua") or "lua")

def _clean_token(t: str) -> str:
    t = (t or "").strip().strip('"').strip("'")
    # ignore placeholders
    bad = ("", "PUT_YOUR_BOT_TOKEN_HERE", "your_bot_token", "YOUR_TOKEN", "changeme")
    if t.lower() in {b.lower() for b in bad}:
        return ""
    if t.startswith("PUT_") or t.startswith("YOUR_"):
        return ""
    return t

TOKEN = (
    _clean_token(os.environ.get("IDK_TOKEN", ""))
    or _clean_token(os.environ.get("DISCORD_TOKEN", ""))
    or _clean_token(os.environ.get("LIGHTCORE_BOT_TOKEN", ""))
    or _clean_token(IDK_TOKEN)
)
# Path to IronBrew0 / Lightcore project root (parent of discord_bot/)
ROOT = _BOT_DIR.parent
CLI = ROOT / "cli.lua"
LUA = os.environ.get("LUA_BIN", _CFG_LUA or "lua")
MAX_FILE_BYTES = 512_000  # 512 KB
CAPTCHA_LEN = 5
CAPTCHA_TTL_SEC = 180

# ---------------------------------------------------------------------------
# Captcha
# ---------------------------------------------------------------------------

def _font(size: int = 36) -> ImageFont.ImageFont:
    for name in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    ):
        if Path(name).exists():
            return ImageFont.truetype(name, size)
    return ImageFont.load_default()


def generate_captcha(code: str) -> bytes:
    """Draw a high-contrast, human-readable captcha."""
    w, h = 320, 100
    # light background for readability
    img = Image.new("RGB", (w, h), (245, 245, 250))
    draw = ImageDraw.Draw(img)
    font = _font(48)
    # light noise only (behind text)
    for _ in range(12):
        draw.line(
            (
                random.randint(0, w),
                random.randint(0, h),
                random.randint(0, w),
                random.randint(0, h),
            ),
            fill=(random.randint(200, 220),) * 3,
            width=1,
        )
    # bold dark letters, evenly spaced, slight y jitter only
    x = 28
    for ch in code:
        y = random.randint(18, 28)
        # shadow for contrast
        draw.text((x + 2, y + 2), ch, font=font, fill=(180, 180, 190))
        draw.text((x, y), ch, font=font, fill=(20, 20, 30))
        x += 55
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def random_code(n: int = CAPTCHA_LEN) -> str:
    # avoid ambiguous 0/O, 1/I
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(random.choice(alphabet) for _ in range(n))


# ---------------------------------------------------------------------------
# Obfuscation
# ---------------------------------------------------------------------------

def preset_flags(options: set[str]) -> list[str]:
    """Map panel options -> cli.lua flags."""
    args: list[str] = ["--preset", "executor"]

    if "LC_NO_VIRTUALIZE" in options:
        args = ["--preset", "minimum", "--no-vm"]
        # minimum may still rename/minify
        return args

    # default VM path
    args += ["--vm"]

    if "anti tamper off" in options:
        args += ["--no-anti-tamper"] if _cli_supports("--no-anti-tamper") else []
        # fallback: we'll pass via env / patch options in wrapper
    else:
        pass  # antiTamper default on for executor

    if "CFF MAX" in options:
        args += ["--control-flow"]
        # intensity via config if available

    if "VM MAX" in options or "JIT VM MAX" in options:
        args += ["--preset", "maximum"]
        if "JIT VM MAX" in options:
            # fatVM / high intensity if CLI supports
            pass

    return args


def _cli_supports(flag: str) -> bool:
    try:
        help_txt = subprocess.check_output(
            [LUA, str(CLI), "--help"],
            cwd=str(ROOT),
            stderr=subprocess.STDOUT,
            text=True,
            timeout=10,
        )
        return flag in help_txt
    except Exception:
        return False


def run_obfuscator(source: str, options: set[str]) -> tuple[Optional[str], Optional[str]]:
    """
    Returns (output_source, error_message).
    """
    with tempfile.TemporaryDirectory(prefix="lightcore_") as td:
        tin = Path(td) / "in.lua"
        tout = Path(td) / "out.lua"
        tin.write_text(source, encoding="utf-8")

        # Build options for Lua module
        anti = "anti tamper off" not in options
        use_vm = "LC_NO_VIRTUALIZE" not in options
        cff = "CFF MAX" in options
        fat = "JIT VM MAX" in options
        maximum = "VM MAX" in options or "JIT VM MAX" in options
        static_env = "Static Environment" in options
        vm_compress = "VM Compression" in options or True
        no_line = "Disable Line Info" in options
        use_debug = "Use Debug Library" in options
        hardcode_g = "Hardcode Globals" in options
        compat = "Compatibility Mode" in options
        gc_fixes = "Enable GC Fixes" in options
        if "Target: Lua 5.1" in options:
            target = "lua51"
        elif "Target: Luau" in options:
            target = "luau"
        else:
            target = "roblox"
        if "Opt Level 3" in options:
            opt_level = 3
        elif "Opt Level 1" in options:
            opt_level = 1
        else:
            opt_level = 2
        if "Node: beta" in options:
            node = "beta"
        elif "Node: v1.2" in options:
            node = "v1.2"
        elif "Node: v1" in options or "Node: main" in options:
            node = "v1"
        else:
            node = "v1"

        lua_script = f"""
package.path = [[{ROOT}/?.lua;{ROOT}/?/init.lua;]] .. package.path
local ok, L = pcall(require, "src.init")
if not ok then
  io.stderr:write("require failed: " .. tostring(L) .. "\\n")
  os.exit(2)
end
local f = io.open([[{tin}]], "r")
local src = f:read("*a")
f:close()
local opts = {{
  preset = {"'maximum'" if maximum else "'executor'"},
  target = "{target}",
  vm = {str(use_vm).lower()},
  antiTamper = {str(anti).lower()},
  fatVM = {str(fat).lower()},
  controlFlow = {str(cff).lower()},
  scrambleOps = true,
  superOps = true,
  encryptStrings = true,
  rollingXor = true,
  singleLine = true,
  base85 = {str(bool(vm_compress)).lower()},
  minify = true,
  rename = true,
  staticEnvironment = {str(static_env).lower()},
  disableLineInfo = {str(no_line).lower()},
  useDebugLibrary = {str(use_debug).lower()},
  hardcodeGlobals = {str(hardcode_g).lower()},
  compatibilityMode = {str(compat).lower()},
  enableGcFixes = {str(gc_fixes).lower()},
  optimizationLevel = {opt_level},
  obfuscationNode = "{node}",
  markerVersion = "{node}",
}}
if not opts.vm then
  opts.preset = "minimum"
  opts.antiTamper = false
end
local out, errs = L.obfuscate(src, opts)
if not out then
  local msg = "obfuscate failed"
  if type(errs) == "table" and errs[1] then
    msg = tostring(errs[1].message or errs[1])
  end
  io.stderr:write(msg .. "\\n")
  os.exit(1)
end
local o = io.open([[{tout}]], "w")
o:write(out)
o:close()
print("OK " .. #out)
"""
        runner = Path(td) / "run.lua"
        runner.write_text(lua_script, encoding="utf-8")
        try:
            proc = subprocess.run(
                [LUA, str(runner)],
                cwd=str(ROOT),
                capture_output=True,
                text=True,
                timeout=120,
            )
        except subprocess.TimeoutExpired:
            return None, "Obfuscation timed out (120s)."
        except FileNotFoundError:
            return None, f"Lua binary not found ({LUA}). Set LUA_BIN."

        if proc.returncode != 0:
            err = (proc.stderr or proc.stdout or "unknown error").strip()
            return None, err[:1500]

        if not tout.exists():
            return None, "No output produced."
        return tout.read_text(encoding="utf-8", errors="replace"), None


# ---------------------------------------------------------------------------
# Session state (in-memory)
# ---------------------------------------------------------------------------

class Session:
    def __init__(self, user_id: int, source: str, filename: str):
        self.user_id = user_id
        self.source = source
        self.filename = filename
        self.code = random_code()
        self.typed: list[str] = []
        self.verified = False
        self.options: set[str] = set()
        self.created = asyncio.get_event_loop().time()


SESSIONS: dict[int, Session] = {}


# ---------------------------------------------------------------------------
# UI: Captcha keyboard
# ---------------------------------------------------------------------------

class CaptchaView(View):
    def __init__(self, session: Session):
        super().__init__(timeout=float(CAPTCHA_TTL_SEC))
        self.session = session
        # Real captcha letters + fake decoys, shuffled together
        real = list(session.code)  # must all appear on the keyboard
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        decoys = [c for c in alphabet if c not in real]
        random.shuffle(decoys)
        # 5 real + ~10 fake = 15 buttons (3x5)
        n_fake = 10
        pool = list(real) + decoys[:n_fake]
        random.shuffle(pool)  # mix real and fake

        for i, ch in enumerate(pool):
            self.add_item(CaptchaButton(ch, session, row=i // 5))

        self.add_item(CaptchaClearButton(session, row=3))
        self.add_item(CaptchaSubmitButton(session, row=3))


class CaptchaButton(Button):
    def __init__(self, letter: str, session: Session, row: int):
        super().__init__(label=letter, style=discord.ButtonStyle.secondary, row=row)
        self.letter = letter
        self.session = session

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.session.user_id:
            return await interaction.response.send_message("Not your captcha.", ephemeral=False)
        if len(self.session.typed) >= CAPTCHA_LEN:
            return await interaction.response.defer()
        self.session.typed.append(self.letter)
        shown = "".join(self.session.typed)
        pad = "_" * max(0, CAPTCHA_LEN - len(shown))
        content = (
            f"**Captcha** — click letters in order, then **Submit**.\n"
            f"File: `{self.session.filename}`\n"
            f"**Entry:**\n```\n{shown}{pad}\n```"
        )
        await interaction.response.edit_message(content=content)


class CaptchaClearButton(Button):
    def __init__(self, session: Session, row: int):
        super().__init__(label="Clear", style=discord.ButtonStyle.danger, row=row)
        self.session = session

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.session.user_id:
            return await interaction.response.send_message("Not your captcha.", ephemeral=False)
        self.session.typed.clear()
        pad = "_" * CAPTCHA_LEN
        content = (
            f"**Captcha** — click letters in order, then **Submit**.\n"
            f"File: `{self.session.filename}`\n"
            f"**Entry:**\n```\n{pad}\n```"
        )
        await interaction.response.edit_message(content=content)


class CaptchaSubmitButton(Button):
    def __init__(self, session: Session, row: int):
        super().__init__(label="Submit", style=discord.ButtonStyle.success, row=row)
        self.session = session

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.session.user_id:
            return await interaction.response.send_message("Not your captcha.", ephemeral=False)
        got = "".join(self.session.typed)
        if got.upper() != self.session.code.upper():
            self.session.typed.clear()
            self.session.code = random_code()
            # new image
            png = generate_captcha(self.session.code)
            file = discord.File(io.BytesIO(png), filename="captcha.png")
            view = CaptchaView(self.session)
            await interaction.response.send_message(
                "Wrong captcha. Try again:", file=file, view=view, ephemeral=False
            )
            return

        self.session.verified = True
        view = OptionsView(self.session)
        await interaction.response.send_message(
            "**Captcha OK.** Choose obfuscation options, then press **Obfuscate**.\n"
            "Macros docs: use `/macros` or the Macros button.",
            view=view,
            ephemeral=False,
        )


# ---------------------------------------------------------------------------
# UI: Options panel
# ---------------------------------------------------------------------------


SECURITY_OPTIONS = [
    ("anti tamper off", "Disable Lightcore AT-VM"),
    ("CFF MAX", "Control-flow flattening (max)"),
    ("VM MAX", "Full VM + scramble + encrypt"),
    ("JIT VM MAX", "VM MAX + higher intensity"),
    ("LC_NO_VIRTUALIZE", "No VM — minify/rename only"),
]

ENV_OPTIONS = [
    ("Static Environment", "Assume _ENV never changes"),
    ("VM Compression", "Compress VM payload"),
    ("Disable Line Info", "Strip line info"),
    ("Use Debug Library", "Extra debug-library checks"),
    ("Hardcode Globals", "Inline global names"),
    ("Compatibility Mode", "Safer for broken clients"),
    ("Enable GC Fixes", "Fix __gc edge cases"),
]

TARGET_OPTIONS = [
    ("Target: Roblox", "Target Roblox / executor"),
    ("Target: Lua 5.1", "Target Lua 5.1"),
    ("Target: Luau", "Target Luau"),
]

NODE_OPTIONS = [
    ("Node: v1", "Obfuscation node v1 (stable)"),
    ("Node: v1.2", "Obfuscation node v1.2 (no loadstring leak on AT fail)"),
    ("Node: main", "Alias of v1 (recommended)"),
    ("Node: beta", "Experimental node"),
]

OPT_OPTIONS = [
    ("Opt Level 1", "Optimization level 1"),
    ("Opt Level 2", "Optimization level 2"),
    ("Opt Level 3", "Optimization level 3"),
]


def _opts(pairs):
    return [discord.SelectOption(label=l, description=d[:100]) for l, d in pairs]


class MultiSelect(Select):
    """One category of options; merges into session.options."""

    def __init__(self, session: Session, placeholder: str, pairs: list, custom_id: str):
        super().__init__(
            placeholder=placeholder,
            min_values=0,
            max_values=len(pairs),
            options=_opts(pairs),
            custom_id=custom_id,
        )
        self.session = session
        self._labels = {p[0] for p in pairs}

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.session.user_id:
            return await interaction.response.send_message("Not your session.", ephemeral=False)
        # drop previous picks from this category, add new
        self.session.options -= self._labels
        self.session.options |= set(self.values)
        await interaction.response.send_message(
            f"**{self.placeholder}** → `{', '.join(self.values) or '(none)'}`\n"
            f"All: `{', '.join(sorted(self.session.options)) or '(defaults)'}`",
            ephemeral=False,
        )


class OptionsSelect(Select):
    """Unused legacy — kept for import safety."""
    def __init__(self, session: Session):
        super().__init__(placeholder="legacy", options=[discord.SelectOption(label="x")])
        self.session = session

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_message("use the category menus", ephemeral=False)



class OptionsView(View):
    def __init__(self, session: Session):
        super().__init__(timeout=600.0)
        self.session = session
        # Discord max 5 rows: 4 selects + 1 button row
        self.add_item(MultiSelect(session, "Security / VM", SECURITY_OPTIONS, "sec"))
        self.add_item(MultiSelect(session, "Environment", ENV_OPTIONS, "env"))
        self.add_item(MultiSelect(session, "Target + Node", TARGET_OPTIONS + NODE_OPTIONS, "tgtnode"))
        self.add_item(MultiSelect(session, "Optimization", OPT_OPTIONS, "opt"))

    @discord.ui.button(label="Obfuscate", style=discord.ButtonStyle.primary, row=2)
    async def do_obfuscate(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != self.session.user_id:
            return await interaction.response.send_message("Not your session.", ephemeral=False)
        if not self.session.verified:
            return await interaction.response.send_message("Solve captcha first.", ephemeral=False)

        await interaction.response.defer(ephemeral=False, thinking=True)
        out, err = await asyncio.get_event_loop().run_in_executor(
            None, run_obfuscator, self.session.source, self.session.options
        )
        if err or not out:
            await interaction.followup.send(f"Obfuscation failed:\n```\n{(err or 'unknown')[:1500]}\n```", ephemeral=False)
            return

        name = Path(self.session.filename).stem + ".lightcore.lua"
        data = out.encode("utf-8")
        if len(data) > 7_500_000:
            await interaction.followup.send("Output too large for Discord upload.", ephemeral=False)
            return
        file = discord.File(io.BytesIO(data), filename=name)
        await interaction.followup.send(
            f"**Lightcore** done.\nOptions: `{', '.join(self.session.options) or 'defaults'}`\nSize: `{len(out)}` bytes",
            file=file,
            ephemeral=False,
        )
        SESSIONS.pop(self.session.user_id, None)

    @discord.ui.button(label="Macros docs", style=discord.ButtonStyle.secondary, row=2)
    async def macros_btn(self, interaction: discord.Interaction, button: Button):
        docs = (Path(__file__).parent / "macros_docs.md").read_text(encoding="utf-8")
        chunks = [docs[i : i + 1900] for i in range(0, len(docs), 1900)]
        await interaction.response.send_message(f"```md\n{chunks[0]}\n```", ephemeral=True)
        for ch in chunks[1:5]:
            await interaction.followup.send(f"```md\n{ch}\n```", ephemeral=True)


# ---------------------------------------------------------------------------
# Bot
# ---------------------------------------------------------------------------

intents = discord.Intents.default()
intents.message_content = True
intents.dm_messages = True

client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


@client.event
async def on_ready():
    await tree.sync()
    print(f"Lightcore bot ready as {client.user}")


@client.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return
    # DM only for file pipeline
    if message.guild is not None:
        return

    if not message.attachments:
        if message.content.strip().lower() in ("help", "!help", "/help"):
            await message.channel.send(
                "**Lightcore bot**\n"
                "1. DM me a `.lua` / `.luau` / `.txt` file\n"
                "2. Solve the captcha (letter keyboard)\n"
                "3. Pick options → **Obfuscate**\n"
                "4. `/macros` for macro documentation\n"
            )
        return

    att = message.attachments[0]
    if not att.filename.lower().endswith((".lua", ".luau", ".txt")):
        await message.channel.send("Send a `.lua`, `.luau`, or `.txt` file.")
        return
    if att.size and att.size > MAX_FILE_BYTES:
        await message.channel.send(f"File too large (max {MAX_FILE_BYTES} bytes).")
        return

    try:
        raw = await att.read()
        source = raw.decode("utf-8", errors="replace")
    except Exception as e:
        await message.channel.send(f"Could not read file: {e}")
        return

    session = Session(message.author.id, source, att.filename)
    SESSIONS[message.author.id] = session
    png = generate_captcha(session.code)
    file = discord.File(io.BytesIO(png), filename="captcha.png")
    view = CaptchaView(session)
    pad = "_" * CAPTCHA_LEN
    await message.channel.send(
        f"**Captcha** — click letters in order, then **Submit**.\n"
        f"File: `{att.filename}` ({len(source)} bytes)\n"
        f"**Entry:**\n```\n{pad}\n```",
        file=file,
        view=view,
    )


@tree.command(name="macros", description="Lightcore / LC macro documentation")
async def macros_cmd(interaction: discord.Interaction):
    docs = (Path(__file__).parent / "macros_docs.md").read_text(encoding="utf-8")
    chunks = [docs[i : i + 1900] for i in range(0, len(docs), 1900)]
    await interaction.response.send_message(f"```md\n{chunks[0]}\n```", ephemeral=True)
    for ch in chunks[1:5]:
        await interaction.followup.send(f"```md\n{ch}\n```", ephemeral=True)


@tree.command(name="ping", description="Health check")
async def ping_cmd(interaction: discord.Interaction):
    await interaction.response.send_message("Lightcore bot online.", ephemeral=False)


def main():
    if not TOKEN:
        print("ERROR: Discord bot token not found.")
        print(f"  Edit: {_CFG_PATH}")
        print('  IDK_TOKEN = "paste_token_from_discord_developer_portal"')
        print("  Token must be the bot token (not client secret).")
        raise SystemExit(1)
    print(f"Starting Lightcore bot (token length {len(TOKEN)})...")
    client.run(TOKEN)


if __name__ == "__main__":
    main()
