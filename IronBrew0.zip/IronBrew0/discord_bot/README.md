# Lightcore Discord Bot

DM a Lua file → captcha (letter keyboard) → option panel → obfuscated file back in DM.

## Setup

1. Create a Discord application + bot at https://discord.com/developers/applications  
2. Enable **Message Content Intent** and **Direct Messages**  
3. Invite bot with `bot` + `applications.commands` scopes  
4. Install deps:

```bash
cd discord_bot
pip install -r requirements.txt
```

5. Run (from machine that has Lua + Lightcore project):

```bash
export LIGHTCORE_BOT_TOKEN="your_bot_token"
export LUA_BIN="lua"   # or path to lua 5.4
python bot.py
```

`LUA_BIN` must be able to `require("src.init")` with cwd = project root (`IronBrew0/`).

## Flow

1. User DMs a `.lua` / `.luau` / `.txt` attachment  
2. Bot sends captcha image + letter buttons  
3. User taps letters → **Submit**  
4. Options (multi-select):
   - `anti tamper off`
   - `CFF MAX`
   - `VM MAX`
   - `JIT VM MAX`
   - `LC_NO_VIRTUALIZE`
5. **Obfuscate** → result file in DM  
6. `/macros` — macro documentation (LC + Lightcore presets)

## Notes

- Captcha TTL ~3 minutes  
- Max upload 512 KB  
- Sessions are in-memory (single process)  
- Note: `LC_LINE` is a **number**, not a function (`LC_LINE()` is wrong)
