# Lightcore Discord bot config
# 1) https://discord.com/developers/applications → Bot → Reset Token → Copy
# 2) Paste between the quotes below (no spaces)

IDK_TOKEN = ""

# Optional: path to lua binary
LUA_BIN = "lua"
