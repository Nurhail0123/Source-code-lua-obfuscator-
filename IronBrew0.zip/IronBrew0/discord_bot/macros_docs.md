# Lightcore v1.4 Macros (`LC_`)

Identifiers starting with `LC` are reserved. **Do not use `LPH_`.**

## Shims (required for unobfuscated runs)

```lua
if not LC_OBFUSCATED then
  LC_OBFUSCATED = false
  LC_LINE = 0
  function LC_ENCSTR(s) return s end
  function LC_ENCNUM(n) return n end
  function LC_OPAQUE(v) return v end
  function LC_CRASH() error("crash") end
  function LC_NO_VIRTUALIZE() end
  function LC_VM_MAX() end
  function LC_JIT_MAX() end
end
```

## Value macros

| Macro | Type | After obfuscation |
|-------|------|-------------------|
| `LC_OBFUSCATED` | boolean | `true` |
| `LC_LINE` | number | current line |

```lua
-- WRONG
LC_LINE()
LC_OBFUSCATED()

-- RIGHT
local line = LC_LINE
if LC_OBFUSCATED then ... end
```

## Callable macros

| Macro | Effect |
|-------|--------|
| `LC_ENCSTR(s)` | String marked for encryption (call removed, string kept) |
| `LC_ENCNUM(n)` | Number pass-through / encode pipeline |
| `LC_OPAQUE(v)` | Wraps value |
| `LC_CRASH()` | `error("e", 0)` |
| `LC_NO_VIRTUALIZE()` | Hint marker (use panel / preset too) |
| `LC_VM_MAX()` / `LC_JIT_MAX()` | Hint markers |

## Branch folding

```lua
if not LC_OBFUSCATED then
  -- stripped when obfuscating
else
  -- kept
end

if LC_OBFUSCATED then
  -- kept
end
```

## Nodes

| Node | Notes |
|------|-------|
| `v1` | Legacy, kept forever |
| `v1.4` | **Current** — new XOR schedule, dual blob, macro pass |

Migrate all production scripts to **v1.4**. Retire v1.3 builds.
