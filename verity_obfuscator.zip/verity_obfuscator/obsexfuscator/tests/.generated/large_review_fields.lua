package.path='./?.lua;./?/init.lua;'..package.path
local obfuscator=require('src.obfuscator')
local lexer=require('src.lexer')
local output=obfuscator.obfuscate('local f=function(x) return x+1 end; return f(41)',{profile='max',seed=1,main=false,minify=false,rename=false,debugBlocks=true,debugConstants=true,debugGuards=true,debug=true})
local tokens=lexer.lex(output)
local fields={}
for i,token in ipairs(tokens) do
 if token.value=='.' and tokens[i+1] then fields[tokens[i+1].value]=true end
end
local names={};for name in pairs(fields) do names[#names+1]=name end; table.sort(names)
print(table.concat(names,','))
