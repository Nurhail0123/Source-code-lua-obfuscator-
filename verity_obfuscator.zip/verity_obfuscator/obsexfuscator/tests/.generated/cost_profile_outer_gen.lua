package.path='./?.lua;'..package.path
local util=require('src.util')
local code=util.read('tests/.generated/cost_profile_main.luau')
local count
code,count=code:gsub('local environment=','local outerInstructions=0\nlocal environment=',1)
assert(count==1)
code,count=code:gsub('while true do','while true do outerInstructions+=1')
assert(count==1,'baseline must contain exactly one visible outer dispatcher')
code=code:gsub('row.maxString,row.cold%)','row.maxString,row.cold,outerInstructions)')
code=code:gsub('run%(1500%)','run(300)'):gsub('1130250','46050')
util.write('tests/.generated/cost_profile_outer.luau',code)
