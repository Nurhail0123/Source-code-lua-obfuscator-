package.path='./?.lua;'..package.path
local obfuscator=require('src.obfuscator')
local util=require('src.util')
local out=obfuscator.obfuscate(util.read('examples/demo.luau'),{profile='max',seed=12345,minify=false,debug=true,cooperative=false})
util.write('tests/.generated/hot_debug.luau',out)
