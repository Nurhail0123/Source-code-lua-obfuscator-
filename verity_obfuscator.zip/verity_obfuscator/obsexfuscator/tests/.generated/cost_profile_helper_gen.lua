package.path='./?.lua;'..package.path
local native=require('src.native')
local previousNew=native.new
native.new=function(...)
    local instance=previousNew(...)
    if instance.enabled then
        local previousSource=instance.source
        function instance:source()
            local labels={}
            for index,body in ipairs(self.helpers) do
                labels[index]=string.format('%q',body:match('local function (__ovm_[%w_]+)') or 'block_'..index)
            end
            return '(function() local helperTable='..previousSource(self)
                ..' local labels={'..table.concat(labels,',')..'} local counters=getfenv().__cost_calls '
                ..[=[
for index,factory in ipairs(helperTable) do
    local label=labels[index]
    local row={factories=0,calls=0}
    counters[label]=row
    helperTable[index]=function(...)
        row.factories+=1
        local results=table.pack(factory(...))
        if results.n==1 and type(results[1])=='function' then
            local implementation=results[1]
            results[1]=function(...)
                row.calls+=1
                return implementation(...)
            end
        end
        return table.unpack(results,1,results.n)
    end
end
return helperTable end)()
]=]
        end
    end
    return instance
end
local obfuscator=require('src.obfuscator')
local util=require('src.util')
local source=[=[
local function increment(value) return value+3 end
return function(count)
    local checksum=0
    for i=1,count do checksum+=increment(i) end
    return checksum
end
]=]
local output,stats=obfuscator.obfuscate(source,{profile='max',seed=12345,cooperative=false})
local template=[=[
local environment=setmetatable({__cost_calls={}}, {__index=getfenv()})
local function protected(...)
@OUTPUT@
end
setfenv(protected,environment)
local run=protected()
local before={}
for name,row in pairs(environment.__cost_calls) do before[name]={factories=row.factories,calls=row.calls} end
local started=os.clock()
assert(run(300)==46050)
print('elapsed',os.clock()-started)
local names={}
for name in pairs(environment.__cost_calls) do table.insert(names,name) end
table.sort(names)
for _,name in ipairs(names) do
    local row=environment.__cost_calls[name]
    print(name,row.factories-before[name].factories,row.calls-before[name].calls)
end
]=]
util.write('tests/.generated/cost_profile_helpers.luau',template:gsub('@OUTPUT@',function() return output end))
util.write('tests/.generated/cost_profile_helpers_stats.json',util.json(stats)..'\n')
print('helper profile generated')
