package.path='./?.lua;'..package.path
local parser=require('src.parser')
local compiler=require('src.compiler')
local build=require('src.build')
local optimizer=require('src.optimizer')
local util=require('src.util')
local options={seed=12345,profile='max',junk=.65,cff=true,opaque=true,antiTamper=true,antiHooks='identity',lazyInstructions=true,perPrototypeOpcodes=true,instructionBlockSize=16,compact=true,lazyConstants=true,compression=true,nativeHelpers=true,cooperative=false}
local user=compiler.compile(parser.parse(util.read('spintoupgrade.lua')),options)
local generated=build.render(user,util.rng(12345),options)
options.trustedRuntime=true
local outer=compiler.compile(parser.parse('return function(__ovm_accelerators,...)\n'..generated..'\nend'),options)
optimizer.apply(outer,options)
local bigrams,triples,ops,calls,total={},{},{},{},0
local function visit(p)
 for i,ins in ipairs(p.code) do
  total=total+1;ops[ins.op]=(ops[ins.op] or 0)+1
  if ins.op:find('CALLF',1,true) then local n=ins[ins.op=='CALLF0' and 3 or 4];calls[n]=(calls[n]or 0)+1 end
  if p.code[i+1] then local key=ins.op..' '..p.code[i+1].op;bigrams[key]=(bigrams[key]or 0)+1 end
  if p.code[i+2] then local key=ins.op..' '..p.code[i+1].op..' '..p.code[i+2].op;triples[key]=(triples[key]or 0)+1 end
 end
 for _,child in ipairs(p.children)do visit(child)end
end
visit(outer)
local function rows(t)
 local x={}for k,v in pairs(t)do x[#x+1]={k,v}end
 table.sort(x,function(a,b)return a[2]>b[2]or(a[2]==b[2]and a[1]<b[1])end)
 return x
end
print('total',total)
for _,category in ipairs({{'opcodes',ops},{'pairs',bigrams},{'triples',triples},{'calls',calls}})do
 print(category[1]);for i,row in ipairs(rows(category[2]))do if i<=30 then print(row[1],row[2])end end
end
