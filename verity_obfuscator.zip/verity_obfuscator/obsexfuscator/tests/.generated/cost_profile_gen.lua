package.path='./?.lua;'..package.path
local obfuscator=require('src.obfuscator')
local util=require('src.util')
local program=[=[
local function increment(value) return value+3 end
local function run(count)
    local checksum=0
    for i=1,count do checksum+=increment(i) end
    return checksum
end
local function cold() return @COLD@ end
return run,cold
]=]
program=program:gsub('@COLD@',function() return string.format('%q',string.rep('cold_data_marker',4096)) end)
local template=[=[
local environment=setmetatable({}, {__index=getfenv()})
local phases={}
local counts={{constants=0,blocks=0,constantRepeats=0,blockRepeats=0,maxString=0,cold=0},
    {constants=0,blocks=0,constantRepeats=0,blockRepeats=0,maxString=0,cold=0}}
local seenConstants={{},{}}
local seenBlocks={{},{}}
environment.__verity_constant=function(layer,prototype,index,value)
    local row=counts[layer]
    row.constants+=1
    local key=tostring(prototype)..':'..tostring(index)
    if seenConstants[layer][key] then row.constantRepeats+=1 end
    seenConstants[layer][key]=true
    if type(value)=='string' then
        row.maxString=math.max(row.maxString,#value)
        if #value==65536 and value:sub(1,16)=='cold_data_marker' then row.cold+=1 end
    end
end
environment.__verity_block=function(layer,prototype,index,data)
    local row=counts[layer]
    row.blocks+=1
    local key=tostring(prototype)..':'..tostring(index)
    if seenBlocks[layer][key] then row.blockRepeats+=1 end
    seenBlocks[layer][key]=true
end
local function protected(...)
@OUTPUT@
end
setfenv(protected,environment)
local function snapshot(label,elapsed)
    for layer=1,2 do
        local row=counts[layer]
        print(label,layer,elapsed,row.constants,row.blocks,row.constantRepeats,row.blockRepeats,row.maxString,row.cold)
    end
end
local started=os.clock()
local run,cold=protected()
snapshot('entry',os.clock()-started)
started=os.clock()
assert(run(1500)==1130250)
snapshot('first',os.clock()-started)
started=os.clock()
assert(run(1500)==1130250)
snapshot('second',os.clock()-started)
assert(counts[1].cold==0 and counts[1].constantRepeats==0 and counts[1].blockRepeats==0)
assert(counts[2].constantRepeats==0 and counts[2].blockRepeats==0)
]=]
for _,variant in ipairs({{name='main',main=true},{name='single',main=false}}) do
    local code,stats=obfuscator.obfuscate(program,{profile='max',seed=12345,main=variant.main,
        debugConstants=true,debugBlocks=true,cooperative=false})
    local output=template:gsub('@OUTPUT@',function() return code end)
    util.write('tests/.generated/cost_profile_'..variant.name..'.luau',output)
    util.write('tests/.generated/cost_profile_'..variant.name..'_stats.json',util.json(stats)..'\n')
end
print('cost profiles generated')
