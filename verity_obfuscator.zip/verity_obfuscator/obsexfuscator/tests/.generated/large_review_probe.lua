package.path='./?.lua;./?/init.lua;'..package.path
local obfuscator=require('src.obfuscator')
for _,n in ipairs({8192,65536}) do
 local source='local function cold() return "'..string.rep('abcdefghijklmnopqrstuvwxyz',math.ceil(n/26)):sub(1,n)..'" end\n print("large review '..n..' OK")'
 for _,main in ipairs({false,true}) do
  local output,stats=obfuscator.obfuscate(source,{profile='max',seed=12345,main=main})
  local name='tests/.generated/large_review_'..n..'_'..(main and 'double' or 'single')..'.luau'
  local f=assert(io.open(name,'wb'));f:write(output);f:close()
  print(name,#output,stats.payloadBytes,stats.main and stats.main.payloadBytes or 0)
 end
end
