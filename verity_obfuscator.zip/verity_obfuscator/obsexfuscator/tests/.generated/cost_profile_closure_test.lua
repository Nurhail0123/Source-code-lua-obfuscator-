package.path='./?.lua;'..package.path
local closure=require('src.closure')
local native=require('src.native')
local util=require('src.util')
local disabled=native.new(false)
assert(closure.render({nativeHelpers=true},disabled)=='')
assert(closure.render({nativeHelpers=false},native.new(true))=='')
local registry=native.new(true)
local helper=closure.render({nativeHelpers=true},registry)
local prefix=[=[
local __ovm_protos={{upvalues={{kind=1,index=2},{kind=2,index=1}}}}
local __ovm_ipairs,__ovm_pack=ipairs,table.pack
local __ovm_getfenv,__ovm_setfenv=getfenv,setfenv
local __ovm_accelerators=@FACTORIES@
]=]
prefix=prefix:gsub('@FACTORIES@',function() return registry:source() end)
local tests=[=[
local owner={children={1}}
local locals={[2]={1}}
local upvalues={{10}}
local initialCell=locals[2]
local nativeEnv=getfenv()
local firstEnv=setmetatable({marker='first'}, {__index=nativeEnv})
local secondEnv=setmetatable({marker='second'}, {__index=nativeEnv})
local captured
local run=function(child,cells,args,environment)
    assert(child==__ovm_protos[1])
    captured=cells
    return environment.marker,cells[1][1],cells[2][1],table.unpack(args,1,args.n)
end
local first=__ovm_makeclosure(owner,locals,upvalues,1,firstEnv,run)
local second=__ovm_makeclosure(owner,locals,upvalues,1,secondEnv,run)
local results=table.pack(first(nil,'argument',nil,false))
assert(results.n==7 and results[1]=='first' and results[2]==1 and results[3]==10)
assert(results[4]==nil and results[5]=='argument' and results[6]==nil and results[7]==false)
assert(captured[1]==initialCell and captured[2]==upvalues[1])
initialCell[1],upvalues[1][1]=2,20
assert(select(2,first())==2 and select(3,second())==20)
locals[2]={30}
local later=__ovm_makeclosure(owner,locals,upvalues,1,firstEnv,run)
initialCell[1]=5
assert(select(2,first())==5 and select(2,later())==30,'captured cells rebound')
setfenv(first,secondEnv)
assert(first()=='second' and later()=='first','wrapper environment not independent')

__ovm_protos[2]={upvalues={{kind=1,index=1}}}
local selfCell={}
local recursiveRun=function(_,cells,args)
    if args[1]==0 then return 0 end
    return 1+cells[1][1](args[1]-1)
end
local recursive=__ovm_makeclosure({children={2}},{selfCell},{},1,firstEnv,recursiveRun)
selfCell[1]=recursive
assert(recursive(6)==6,'recursive capture broken')

local yieldingRun=function(_,_,args,environment)
    coroutine.yield(environment.marker,args[1])
    return args[2],nil,args[3]
end
local yielding=__ovm_makeclosure(owner,locals,upvalues,1,firstEnv,yieldingRun)
local thread=coroutine.create(yielding)
local begun=table.pack(coroutine.resume(thread,'yield',false,'tail'))
assert(begun.n==3 and begun[1]==true and begun[2]=='first' and begun[3]=='yield')
local resumed=table.pack(coroutine.resume(thread))
assert(resumed.n==4 and resumed[1]==true and resumed[2]==false and resumed[3]==nil and resumed[4]=='tail')
print('native closure cells/env/recursion/yield OK')
]=]
local complete=prefix..helper..tests
util.write('tests/.generated/cost_profile_closure_test.luau',complete)
util.write('tests/.generated/cost_profile_closure_test_min.luau',require('src.minify').compact(complete,{rng=util.rng(12345)}))
local compiler=require('src.compiler')
local parser=require('src.parser')
local prototype=compiler.compile(parser.parse('return '..registry:source()))
local function inspect(p)
    for _,instruction in ipairs(p.code) do
        if instruction.op=='GETGLOBAL' then
            local name=p.constants[instruction[2]].value
            assert(not name:match('^__ovm_'),'missing closure capture '..name)
        end
    end
    for _,child in ipairs(p.children) do inspect(child) end
end
inspect(prototype)
print('native closure host/capture checks OK')
