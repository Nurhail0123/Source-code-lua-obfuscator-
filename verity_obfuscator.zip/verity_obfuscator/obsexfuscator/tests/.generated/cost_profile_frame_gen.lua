package.path='./?.lua;'..package.path
local util=require('src.util')
local code=util.read('tests/.generated/cost_profile_main.luau')
local loop=assert(code:find('while true do',1,true))
local firstParam,position
for start,parameters in code:sub(1,loop):gmatch('()=%s*function%(([%w_,%.]+)%)') do
    local arguments={}
    for name in parameters:gmatch('[%w_]+') do arguments[#arguments+1]=name end
    if #arguments==4 then firstParam,position=arguments[1],start end
end
assert(firstParam,'four-parameter outer run frame not found')
local prefix=code:sub(position,loop)
local idField=assert(prefix:match(firstParam..'%.([%w_]+)%*5153'),'prototype ID salt field not found')
local paramsField=assert(prefix:match('#'..firstParam..'%.([%w_]+)'),'prototype params field not found')
code=code:gsub('local environment=','local frameCosts={}\nlocal environment=',1)
local increment='while true do local costid='..firstParam..'.'..idField
    ..' local costrow=frameCosts[costid] if not costrow then costrow={ops=0,parameters=#'
    ..firstParam..'.'..paramsField..'} frameCosts[costid]=costrow end costrow.ops+=1 '
code=code:gsub('while true do',increment,1)
code=code:gsub('run%(1500%)','run(300)'):gsub('1130250','46050')
code=code..[=[
local ids={}
for id in pairs(frameCosts) do table.insert(ids,id) end
table.sort(ids)
for _,id in ipairs(ids) do
    local row=frameCosts[id]
    print('frame',id,row.parameters,row.ops)
end
]=]
util.write('tests/.generated/cost_profile_frames.luau',code)
print('frame instrumentation',firstParam,idField,paramsField)
