package.path='./?.lua;'..package.path
local scheduler=require('src.scheduler')
local util=require('src.util')
local generated=scheduler.render({cooperative=true,yieldInterval=256,yieldBudgetMs=8})
util.write('tests/.generated/scheduler_cost.luau',[[
local runningCalls,clockCalls=0,0
local thread={}
local env={task={wait=function() error('unexpected wait') end},os={clock=function() clockCalls+=1; return 0 end},coroutine={isyieldable=function() return true end,running=function() runningCalls+=1; return thread end}}
local fn,bind=(function(__ovm_entryenv)
]]..generated.setup..[[
return __ovm_checkpoint,__ovm_bindcheckpoint end)(env)
local started=os.clock()
for i=1,1000000 do fn() end
print('lookup',os.clock()-started,runningCalls,clockCalls)
runningCalls,clockCalls=0,0
local bound=bind()
started=os.clock()
for i=1,1000000 do bound() end
print('bound',os.clock()-started,runningCalls,clockCalls)
]])
