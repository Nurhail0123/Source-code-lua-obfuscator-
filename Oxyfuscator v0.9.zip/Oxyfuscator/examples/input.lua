local message = "Hello from Oxyfuscator"
local number = 67

local function greet(name)
    print(message, name, number + 3)
end

greet("larpcorrupt")
return number
