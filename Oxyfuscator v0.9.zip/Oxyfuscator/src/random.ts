import type { RandomSource } from "./types.js";

export class XorShift32 implements RandomSource {
  private state: number;

  constructor(seed: number) {
    let value = seed | 0;
    if (value === 0) value = 0x6d2b79f5;
    this.state = value;
  }

  next(): number {
    let x = this.state | 0;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.state = x | 0;
    return (x >>> 0) / 0x100000000;
  }

  int(min: number, max: number): number {
    if (max < min) [min, max] = [max, min];
    return min + Math.floor(this.next() * (max - min + 1));
  }

  pick<T>(values: readonly T[]): T {
    if (values.length === 0) throw new Error("Cannot pick from an empty array.");
    return values[this.int(0, values.length - 1)]!;
  }
}
