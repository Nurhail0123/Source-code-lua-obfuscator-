import { tokenize } from "../tokenizer.js";
import type { TransformContext, TransformPass } from "../types.js";

export class StripCommentsPass implements TransformPass {
  readonly name = "strip-comments";
  run(source: string, _context: TransformContext): string {
    return tokenize(source).map(token => {
      if (token.kind !== "comment") return token.text;
      const newlines = (token.text.match(/\n/g) ?? []).length;
      return "\n".repeat(newlines);
    }).join("");
  }
}
