# Oxyfuscator v0.9

TypeScript Lua/Luau obfuscator focused on polymorphic builds and VM-style protection.

## Presets

```text
minimum  local/parameter renaming
balanced renaming + strings + comment removal
maximum  balanced + numeric transforms + two independent VM layers
swear    maximum + swear-word local naming
```

## v0.7 maximum hardening

- two separately randomized loader-VM layers
- only the inner layer performs the 1.1s timing self-check
- each layer has its own opcode layout, numeric function bank, payload encoding and integrity state
- 28-50-ish fake opcodes per layer depending on the generated build
- expanded shadow/fake VM programs with randomized arithmetic/register traffic
- fake opcode state is verified later, so deleting the fake paths changes execution
- program, function-bank, per-chunk and full-payload integrity checks
- corrupt-and-halt tamper path
- `loadstring` / `load` names are assembled dynamically rather than emitted as plaintext identifiers
- deterministic polymorphism through `--seed`

## Usage

```bash
npm install
npm run build
node dist/cli.js input.lua -o output.lua --preset maximum
```

Cursed naming preset:

```bash
node dist/cli.js input.lua -o output.lua --preset swear
```

## Important limitation

The current maximum preset is a layered loader VM. At some point the protected Lua source must still be reconstructed for the runtime compiler. A runtime that intercepts that compilation boundary can therefore recover a later-stage representation. The next major security milestone is real function/instruction virtualization so protected logic executes directly in Oxyfuscator bytecode instead of becoming ordinary Lua source again.


## v0.9

`maximum` and `swear` automatically compress every VM layer before transport.

- LZ-style back-reference compression
- randomized Base85 alphabet per VM layer
- compression occurs before stream encryption
- encoded payload is chunked only after compression
- the tamper payload uses the same compressed transport
- no extra CLI flag is required

The runtime order is: Base85 decode -> stream decrypt -> LZ decompress -> VM stage.

## v0.9 function-object wrapper

`maximum` and `swear` now emit a MoonVeil-style returned function object instead of an outer IIFE:

```lua
return({
  g=function(q,k,p,...)
    -- installs randomized aliases and dispatches into the entry method
  end,
  A=function(...) ... end,
  m=function(...) ... end,
  V=function(...) ... end,
  -- many more generated helpers
}):g({"A","m","V",...},"V",...)
```

The function bank is shuffled per build and helper names are randomized. The current v0.9 inner protection still uses the existing layered loader VM; replacing the innermost runtime compilation boundary with full instruction virtualization is a separate step.
