import hmac
import json
import os
import subprocess
import tempfile
import time
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
CLI = ROOT / "cli.lua"
LUA_BIN = os.getenv("LUA_BIN", "lua5.4")
API_SECRET = os.getenv("CLAUDIUM_INTERNAL_SECRET", "")
MAX_SOURCE_BYTES = int(os.getenv("MAX_SOURCE_BYTES", "2000000"))
OBFUSCATION_TIMEOUT = int(os.getenv("OBFUSCATION_TIMEOUT", "45"))
ALLOWED_PRESETS = {"minimum", "maximum", "lua51", "lua53", "luajit", "roblox", "luau", "executor"}

app = FastAPI(
    title="Claudium API",
    version="2.5.4",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)

class ObfuscateRequest(BaseModel):
    source: str = Field(min_length=1)
    preset: str = "executor"
    antiTamper: bool = True


def check_auth(authorization: str | None) -> None:
    if not API_SECRET:
        raise HTTPException(status_code=503, detail="server_not_configured")
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="unauthorized")
    supplied = authorization[7:]
    if not hmac.compare_digest(supplied.encode(), API_SECRET.encode()):
        raise HTTPException(status_code=401, detail="unauthorized")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


@app.get("/health")
def health():
    return {
        "ok": True,
        "service": "claudium",
        "version": "2.5.4",
    }


@app.post("/obfuscate")
def obfuscate(payload: ObfuscateRequest, authorization: str | None = Header(default=None)):
    check_auth(authorization)

    encoded = payload.source.encode("utf-8")
    if len(encoded) > MAX_SOURCE_BYTES:
        raise HTTPException(status_code=413, detail="source_too_large")

    preset = payload.preset.lower().strip()
    if preset not in ALLOWED_PRESETS:
        raise HTTPException(status_code=400, detail="invalid_preset")

    effective_anti_tamper = payload.antiTamper or preset in {"executor", "roblox", "luau"}

    started = time.perf_counter()

    with tempfile.TemporaryDirectory(prefix="claudium_") as tmp:
        tmp_path = Path(tmp)
        input_path = tmp_path / "input.lua"
        output_path = tmp_path / "output.lua"
        input_path.write_text(payload.source, encoding="utf-8")

        cmd = [
            LUA_BIN,
            str(CLI),
            str(input_path),
            "--preset",
            preset,
            "--anti-tamper" if effective_anti_tamper else "--no-anti-tamper",
            "-o",
            str(output_path),
        ]

        try:
            proc = subprocess.run(
                cmd,
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=OBFUSCATION_TIMEOUT,
                env={**os.environ, "HOME": "/tmp"},
            )
        except subprocess.TimeoutExpired:
            raise HTTPException(status_code=504, detail="obfuscation_timeout")
        except FileNotFoundError:
            raise HTTPException(status_code=503, detail="lua_runtime_missing")

        if proc.returncode != 0 or not output_path.exists():
            err = (proc.stderr or proc.stdout or "obfuscation_failed").strip()
            raise HTTPException(status_code=422, detail={
                "error": "obfuscation_failed",
                "message": err[-4000:],
            })

        output = output_path.read_text(encoding="utf-8")

    elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
    return JSONResponse({
        "success": True,
        "output": output,
        "preset": preset,
        "antiTamper": effective_anti_tamper,
        "elapsedMs": elapsed_ms,
        "inputBytes": len(encoded),
        "outputBytes": len(output.encode("utf-8")),
    })
