# Claudium 2.5 Railway API

This package contains Claudium plus a private HTTP wrapper for Railway.

## Deploy

1. Create a Railway service from this folder/repository.
2. Railway will use the included `Dockerfile`.
3. Add this environment variable:

```env
CLAUDIUM_INTERNAL_SECRET=<long-random-secret>
```

4. Generate a public Railway domain for the service.
5. In Claudmor/Vercel set:

```env
CLAUDIUM_INTERNAL_URL=https://YOUR-RAILWAY-DOMAIN.up.railway.app/obfuscate
CLAUDIUM_INTERNAL_SECRET=<the-exact-same-secret>
```

Do not expose `CLAUDIUM_INTERNAL_SECRET` in browser JavaScript.

## Health

```http
GET /health
```

Returns:

```json
{"ok":true,"service":"claudium","version":"2.5.4"}
```

## Obfuscate

```http
POST /obfuscate
Authorization: Bearer YOUR_SECRET
Content-Type: application/json
```

Example body:

```json
{
  "source": "print('hello from claudium')",
  "preset": "executor",
  "antiTamper": true
}
```

Example response:

```json
{
  "success": true,
  "output": "...",
  "preset": "executor",
  "antiTamper": true,
  "elapsedMs": 123.45,
  "inputBytes": 28,
  "outputBytes": 123456
}
```

Allowed presets:

- `minimum`
- `maximum`
- `lua51`
- `lua53`
- `luajit`
- `roblox`
- `luau`
- `executor`

For your intended Roblox/executor use, use `executor`.

## PowerShell test

```powershell
$headers = @{
    Authorization = "Bearer YOUR_SECRET"
    "Content-Type" = "application/json"
}

$body = @{
    source = 'print("hi claudium")'
    preset = "executor"
    antiTamper = $true
} | ConvertTo-Json

Invoke-RestMethod `
    -Uri "https://YOUR-RAILWAY-DOMAIN.up.railway.app/obfuscate" `
    -Method POST `
    -Headers $headers `
    -Body $body
```

## Security behavior

- API requires a bearer secret.
- API docs/OpenAPI endpoints are disabled.
- Temporary source/output files are deleted after every request.
- Request size is limited to 2 MB by default.
- Obfuscation is killed after 45 seconds by default.
- API responses use `Cache-Control: no-store`.
- The Claudium source is never returned except for the generated obfuscated output.

The Railway service should be called by Claudmor server-side, not directly by browser code.
