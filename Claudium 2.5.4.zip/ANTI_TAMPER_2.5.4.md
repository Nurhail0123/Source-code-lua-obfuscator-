# Claudium 2.5.4 anti-tamper

- Anti-tamper remains VM-resident through the `IB_AT` virtual opcode.
- No standalone readable host-side checksum guard is emitted.
- Base85 VM payloads now use short quoted chunks instead of Lua long-bracket strings.
- This avoids OxyEnv-style `Malformed string` parser failures while preserving the same encrypted payload bytes.
