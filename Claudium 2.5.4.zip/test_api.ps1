param(
    [Parameter(Mandatory=$true)][string]$Url,
    [Parameter(Mandatory=$true)][string]$Secret
)

$headers = @{
    Authorization = "Bearer $Secret"
    "Content-Type" = "application/json"
}

$body = @{
    source = 'print("hi claudium")'
    preset = "executor"
    antiTamper = $true
} | ConvertTo-Json

Invoke-RestMethod -Uri "$($Url.TrimEnd('/'))/obfuscate" -Method POST -Headers $headers -Body $body
