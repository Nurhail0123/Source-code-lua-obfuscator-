# Claudium 2.5.4

Lua/Luau obfuscation framework with a custom bytecode VM and Railway API wrapper.

## Executor protection

```bash
lua cli.lua yourscript.lua --preset executor --anti-tamper -o protected.lua
```

The executor preset uses the VM path by default. With anti-tamper enabled, integrity now runs through the reserved `IB_AT` virtual opcode as the first encrypted trampoline instruction. The old readable host-side anti-tamper prelude is no longer emitted.

## CLI

```text
lua cli.lua <input.lua> [options]

  -o, --output <file>
  --preset <name>     minimum|maximum|lua51|lua53|luajit|roblox|luau|executor
  --minify / --no-minify
  --rename / --no-rename
  --control-flow
  --vm / --no-vm
  --anti-tamper / --no-anti-tamper
  --single-line
  --ir
  --config <file.json>
  --verbose
```

## VM path

```text
Source -> Lexer -> Parser -> AST -> Rename -> IR -> custom bytecode
       -> encrypted/compressed prototype blob -> randomized VM dispatcher
```

Anti-tamper protection in 2.5.4:

- `IB_AT` is stored in the encrypted bytecode stream.
- It executes before the user entry closure.
- The expected full-VM checksum is split across protected byte constants.
- Every prototype's logical instruction stream is reconstructed from the runtime PC permutation before validation.
- There is no standalone plaintext guarded-source block or host anti-format probe.


## OxyEnv compatibility

2.5.4 no longer emits Base85 payloads using Lua long-bracket strings. Payloads are emitted as short quoted chunks, avoiding malformed-string errors in source loggers that mis-tokenize `[==[...]==]`.
