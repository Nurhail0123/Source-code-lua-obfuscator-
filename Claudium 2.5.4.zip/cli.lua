#!/usr/bin/env lua
--[[
Claudium v2.5 CLI

Usage examples:
  lua cli.lua input.lua
  lua cli.lua input.lua -o out.lua
  lua cli.lua input.lua --preset roblox --control-flow
  lua cli.lua input.lua --minify --rename --control-flow --single-line
  lua cli.lua input.lua --ir
  lua cli.lua input.lua --config config.json
]]

local function scriptDir()
    local src = debug.getinfo(1, "S").source
    if src:sub(1, 1) == "@" then
        return src:sub(2):match("(.*/)") or "./"
    end
    return "./"
end

package.path = scriptDir() .. "?.lua;" .. scriptDir() .. "?/init.lua;" .. package.path

local Claudium = require("src.init")

local function usage()
    io.stderr:write(string.format([[
Claudium v%s

Usage:
  claudium <input.lua> [options]

Options:
  -o, --output <file>     Write result to file (default: stdout)
  --preset <name>         Apply a preset:
                            minimum | maximum | lua51 | lua53 | luajit
                            roblox | luau | executor
  --minify / --no-minify  Enable/disable minification (default: on)
  --rename / --no-rename  Enable/disable identifier renaming (default: on)
  --control-flow          Enable control-flow flattening
  --no-control-flow       Disable control-flow flattening
  --anti-tamper           Enable full Claudium anti-tamper suite
  --no-anti-tamper        Disable anti-tamper
  --single-line           Force a single-line output
  --no-single-line        Keep parser-safe line breaks
  --ir                    Dump intermediate representation instead of Lua
  --config <file.json>    Load options from a JSON-like config file
  --verbose               Print progress info
  -h, --help              Show this help

Config file example:
  {
    "preset": "roblox",
    "minify": true,
    "rename": true,
    "controlFlow": true,
    "singleLine": true
  }
]], Claudium.version))
end

-- Minimal JSON-ish config reader (supports the simple format we document)
local function loadConfig(path)
    local f, err = io.open(path, "r")
    if not f then return nil, err end
    local data = f:read("*a")
    f:close()
    local cfg = {}
    -- very small key/value extractor (good enough for our documented format)
    for key, val in data:gmatch('"([%w_]+)"%s*:%s*([^,}]+)') do
        val = val:match("^%s*(.-)%s*$")
        if val == "true" then
            cfg[key] = true
        elseif val == "false" then
            cfg[key] = false
        elseif val:match('^".*"$') then
            cfg[key] = val:sub(2, -2)
        else
            local n = tonumber(val)
            cfg[key] = n or val
        end
    end
    -- normalize camelCase → our option names
    if cfg.controlFlow ~= nil then cfg.controlFlow = cfg.controlFlow end
    if cfg.singleLine ~= nil then cfg.singleLine = cfg.singleLine end
    return cfg
end

local args = { ... }
if #args == 0 then
    usage()
    os.exit(0)
end

local input, output
local options = {
    -- Defaults; left nil where presets should be able to enable features
    rename      = true,
    minify      = true,
    singleLine  = nil,
    controlFlow = nil,  -- preset may enable (e.g. maximum / roblox)
    verbose     = false,
    dumpIR      = false,
    vm          = nil,
}

local i = 1
while i <= #args do
    local a = args[i]
    if a == "-h" or a == "--help" then
        usage()
        os.exit(0)
    elseif a == "-o" or a == "--output" then
        i = i + 1
        output = args[i]
        if not output then
            io.stderr:write("Error: --output requires a file path\n")
            os.exit(1)
        end
    elseif a == "--preset" then
        i = i + 1
        options.preset = args[i]
        if not options.preset then
            io.stderr:write("Error: --preset requires a name\n")
            os.exit(1)
        end
    elseif a == "--config" then
        i = i + 1
        local path = args[i]
        if not path then
            io.stderr:write("Error: --config requires a file path\n")
            os.exit(1)
        end
        local cfg, err = loadConfig(path)
        if not cfg then
            io.stderr:write("Error loading config: " .. tostring(err) .. "\n")
            os.exit(1)
        end
        for k, v in pairs(cfg) do
            options[k] = v
        end
    elseif a == "--minify" then
        options.minify = true
    elseif a == "--no-minify" then
        options.minify = false
    elseif a == "--rename" then
        options.rename = true
    elseif a == "--no-rename" then
        options.rename = false
    elseif a == "--control-flow" then
        options.controlFlow = true
    elseif a == "--no-control-flow" then
        options.controlFlow = false
    elseif a == "--vm" then
        options.vm = true
    elseif a == "--no-vm" then
        options.vm = false
    elseif a == "--anti-tamper" then
        options.antiTamper = true
    elseif a == "--no-anti-tamper" then
        options.antiTamper = false
    elseif a == "--single-line" then
        options.singleLine = true
    elseif a == "--no-single-line" then
        options.singleLine = false
    elseif a == "--ir" then
        options.dumpIR = true
    elseif a == "--verbose" then
        options.verbose = true
    elseif a:sub(1, 1) == "-" then
        io.stderr:write("Unknown option: " .. a .. "\n")
        usage()
        os.exit(1)
    else
        if input then
            io.stderr:write("Error: multiple input files not supported\n")
            os.exit(1)
        end
        input = a
    end
    i = i + 1
end

if not input then
    io.stderr:write("Error: no input file specified\n")
    usage()
    os.exit(1)
end

-- Resolve preset defaults (CLI flags already set override preset)
if options.preset then
    local preset = Claudium.Presets.get(options.preset)
    for k, v in pairs(preset) do
        if options[k] == nil then
            options[k] = v
        end
    end
end
-- Final defaults for anything still unset
if options.controlFlow == nil then options.controlFlow = false end
if options.vm == nil then options.vm = false end
if options.singleLine == nil then options.singleLine = true end

local f, err = io.open(input, "r")
if not f then
    io.stderr:write("Error: cannot open '" .. input .. "': " .. tostring(err) .. "\n")
    os.exit(1)
end
local source = f:read("*a")
f:close()

if options.verbose then
    io.stderr:write(string.format("Claudium v%s\n", Claudium.version))
    io.stderr:write("Input:  " .. input .. "\n")
    if options.preset then
        io.stderr:write("Preset: " .. tostring(options.preset) .. "\n")
    end
    io.stderr:write(string.format("Flags:  rename=%s minify=%s controlFlow=%s vm=%s antiTamper=%s singleLine=%s\n",
        tostring(options.rename), tostring(options.minify),
        tostring(options.controlFlow), tostring(options.vm), tostring(options.antiTamper), tostring(options.singleLine)))
end

local result = Claudium.parse(source, options)
if #result.errors > 0 then
    for _, e in ipairs(result.errors) do
        io.stderr:write(string.format("Parse error %d:%d: %s\n",
            e.line or 0, e.column or 0, e.message or "?"))
    end
    os.exit(1)
end

if options.dumpIR then
    if options.controlFlow then
        Claudium.controlFlow(result.ast, options)
    end
    if options.rename then
        Claudium.rename(result.ast, options)
    end
    local mod = Claudium.compileIR(result.ast, options)
    local dump = Claudium.IR.dump(mod.main)
    if output then
        local of = assert(io.open(output, "w"))
        of:write(dump)
        of:close()
        if options.verbose then io.stderr:write("Wrote IR to " .. output .. "\n") end
    else
        io.write(dump)
        if dump:sub(-1) ~= "\n" then io.write("\n") end
    end
    os.exit(0)
end

local out, errors = Claudium.obfuscate(source, options)
if not out then
    io.stderr:write("Obfuscation failed\n")
    if errors then
        for _, e in ipairs(errors) do
            io.stderr:write(string.format("  %s\n", e.message or tostring(e)))
        end
    end
    os.exit(1)
end

if output then
    local of, oerr = io.open(output, "w")
    if not of then
        io.stderr:write("Error writing '" .. output .. "': " .. tostring(oerr) .. "\n")
        os.exit(1)
    end
    of:write(out)
    if out:sub(-1) ~= "\n" then of:write("\n") end
    of:close()
    if options.verbose then
        io.stderr:write("Wrote " .. output .. " (" .. #out .. " bytes)\n")
    end
else
    io.write(out)
    if out:sub(-1) ~= "\n" then io.write("\n") end
end
