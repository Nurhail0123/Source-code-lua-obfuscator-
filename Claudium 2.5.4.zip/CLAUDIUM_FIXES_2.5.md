# Claudium 2.5 fixes

- Fixed VM IR register lifetime corruption: temporary registers can no longer reclaim live local/parameter registers.
- Removed AstraSource injection from the user AST. Anti-tamper is emitted by the VM generator instead.
- Wired the full AntiTamper.emitPrelude() suite into VM output when antiTamper is enabled.
- Enabled bytecode integrity hashing for anti-tamper builds.
- Fixed SUPER_MOVE2 folding so it only folds an actual MOVE chain.
- Fixed SUPER_CALLG so one-result calls preserve their return value.
- Added CLI flags: --anti-tamper and --no-anti-tamper.
- Updated CLI usage branding to `claudium` and bumped core version to 2.5.

Suggested regression input:

```lua
print("hi claudium if u see ts u env logged it")
local x = 10
local function f(v)
    return v + 2
end
print(f(x))
```

Recommended command for the Roblox/executor profile:

```text
lua cli.lua input.lua --preset executor --vm --anti-tamper -o output.lua
```
