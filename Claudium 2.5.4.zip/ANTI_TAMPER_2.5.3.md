# Claudium 2.5.3 anti-tamper

The anti-tamper check is no longer emitted as a readable host-side prelude.

- `IB_AT` (virtual opcode 33) is inserted as the first instruction of the encrypted trampoline.
- The expected integrity value is split into four protected byte constants in the trampoline constant table.
- At runtime the VM dispatcher reconstructs the logical instruction order for every prototype and validates the full wire-code stream.
- The previous readable guarded-source block and host anti-format probe are removed.
- The integrity value is reduced to a positive 31-bit value before storage so it is not confused with Claudium's negative string-pool references.

This keeps the anti-tamper path inside the virtualized execution flow instead of exposing a standalone plaintext guard.
